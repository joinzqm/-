if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudyPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    courseList?: CourseItem[];
    onNavigate?: (page: string) => void;
    currentTab?: number;
    currentWeek?: number;
    gradeSortAsc?: boolean;
    tabs?: string[];
    tabColors?: string[];
}
import { CommonCard } from "@bundle:com.campusassistant.app/entry/ets/components/CommonCard";
import type { CourseItem, GradeItem } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class StudyPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__courseList = new SynchedPropertyObjectOneWayPU(params.courseList, this, "courseList");
        this.onNavigate = undefined;
        this.__currentTab = new ObservedPropertySimplePU(0, this, "currentTab");
        this.__currentWeek = new ObservedPropertySimplePU(8, this, "currentWeek");
        this.__gradeSortAsc = new ObservedPropertySimplePU(true, this, "gradeSortAsc");
        this.tabs = ['课程表', '成绩查询', '图书馆'];
        this.tabColors = ['#1677FF', '#00B42A', '#722ED1'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudyPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.courseList === undefined) {
            this.__courseList.set([]);
        }
        if (params.onNavigate !== undefined) {
            this.onNavigate = params.onNavigate;
        }
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
        if (params.currentWeek !== undefined) {
            this.currentWeek = params.currentWeek;
        }
        if (params.gradeSortAsc !== undefined) {
            this.gradeSortAsc = params.gradeSortAsc;
        }
        if (params.tabs !== undefined) {
            this.tabs = params.tabs;
        }
        if (params.tabColors !== undefined) {
            this.tabColors = params.tabColors;
        }
    }
    updateStateVars(params: StudyPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__courseList.reset(params.courseList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
        this.__currentWeek.purgeDependencyOnElmtId(rmElmtId);
        this.__gradeSortAsc.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__currentTab.aboutToBeDeleted();
        this.__currentWeek.aboutToBeDeleted();
        this.__gradeSortAsc.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __courseList: SynchedPropertySimpleOneWayPU<CourseItem[]>;
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue: CourseItem[]) {
        this.__courseList.set(newValue);
    }
    private onNavigate?: (page: string) => void;
    private __currentTab: ObservedPropertySimplePU<number>;
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: number) {
        this.__currentTab.set(newValue);
    }
    private __currentWeek: ObservedPropertySimplePU<number>;
    get currentWeek() {
        return this.__currentWeek.get();
    }
    set currentWeek(newValue: number) {
        this.__currentWeek.set(newValue);
    }
    private __gradeSortAsc: ObservedPropertySimplePU<boolean>;
    get gradeSortAsc() {
        return this.__gradeSortAsc.get();
    }
    set gradeSortAsc(newValue: boolean) {
        this.__gradeSortAsc.set(newValue);
    }
    private tabs: string[];
    private tabColors: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/StudyPage.ets(19:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor(this.pageBackground());
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(20:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 18, bottom: 20 });
        }, Column);
        this.buildHeader.bind(this)();
        this.buildTabBar.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTab === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildCourseSection.bind(this)();
                });
            }
            else if (this.currentTab === 1) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.buildGradeSection.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.buildLibrarySection.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Scroll.pop();
    }
    private buildHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(42:5)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('学习助手');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(43:7)", "entry");
            Text.fontSize(24 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程表、成绩查询与图书馆入口');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(47:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildTabBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(57:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item);
                    Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(59:9)", "entry");
                    Text.fontSize(14 * this.fontScale);
                    Text.fontColor(this.currentTab === index ? Color.White : this.primaryText());
                    Text.textAlign(TextAlign.Center);
                    Text.layoutWeight(1);
                    Text.padding({ top: 10, bottom: 10 });
                    Text.backgroundColor(this.currentTab === index ? this.tabColors[index] : this.cardBgColor());
                    Text.borderRadius(12);
                    Text.onClick(() => {
                        this.currentTab = index;
                    });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabs, forEachItemGenFunction, (item: string, index: number) => index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    private buildCourseSection(parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.courseBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudyPage.ets", line: 77, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.courseBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
    }
    private courseBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 14 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(82:5)", "entry");
        }, Column);
        this.buildWeekSelector.bind(this)();
        this.buildWeekSchedule.bind(this)();
        this.buildEditCourseButton.bind(this)();
        Column.pop();
    }
    private buildWeekSelector(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(91:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('上一周');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(92:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.currentWeek > 1 ? AppTheme.BRAND_BLUE : this.secondaryText());
            Text.onClick(() => {
                if (this.currentWeek > 1) {
                    this.currentWeek--;
                }
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudyPage.ets(101:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(103:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`第 ${this.currentWeek} 周`);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(104:9)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2026春季学期');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(108:9)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudyPage.ets(113:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('下一周');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(115:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.currentWeek < 20 ? AppTheme.BRAND_BLUE : this.secondaryText());
            Text.onClick(() => {
                if (this.currentWeek < 20) {
                    this.currentWeek++;
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildWeekSchedule(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 4 });
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(129:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, dayIndex: number) => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 6 });
                    Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(131:9)", "entry");
                    Column.layoutWeight(1);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(day);
                    Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(132:11)", "entry");
                    Text.fontSize(12 * this.fontScale);
                    Text.fontColor(this.secondaryText());
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 4 });
                    Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(137:11)", "entry");
                    Column.width('100%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const course = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create({ space: 2 });
                            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(139:15)", "entry");
                            Column.width('100%');
                            Column.padding({ left: 4, right: 4, top: 6, bottom: 6 });
                            Column.borderRadius(6);
                            Column.backgroundColor(course.color);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(course.title);
                            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(140:17)", "entry");
                            Text.fontSize(10 * this.fontScale);
                            Text.fontColor(Color.White);
                            Text.maxLines(2);
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(course.location);
                            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(146:17)", "entry");
                            Text.fontSize(9 * this.fontScale);
                            Text.fontColor(Color.White);
                            Text.opacity(0.85);
                            Text.maxLines(1);
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        Column.pop();
                    };
                    this.forEachUpdateFunction(elmtId, this.getCoursesByWeekday(dayIndex + 1), forEachItemGenFunction, (course: CourseItem) => course.id, false, false);
                }, ForEach);
                ForEach.pop();
                Column.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, AppData.weekdays, forEachItemGenFunction, (day: string, index: number) => index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    private buildEditCourseButton(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(170:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 10, bottom: 10 });
            Row.justifyContent(FlexAlign.Center);
            Row.onClick(() => {
                if (this.onNavigate) {
                    this.onNavigate('courseEdit');
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('编辑课程表');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(171:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(' →');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(174:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildGradeSection(parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.gradeBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudyPage.ets", line: 190, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.gradeBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
    }
    private gradeBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 14 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(195:5)", "entry");
        }, Column);
        this.buildGradeHeader.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(197:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.buildGradeItem.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.getSortedGrades(), forEachItemGenFunction, (item: GradeItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        Column.pop();
    }
    private buildGradeHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(207:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('成绩查询');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(208:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudyPage.ets(212:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 4 });
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(213:7)", "entry");
            Row.onClick(() => {
                this.gradeSortAsc = !this.gradeSortAsc;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.gradeSortAsc ? '绩点升序' : '绩点降序');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(214:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.gradeSortAsc ? '↑' : '↓');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(217:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
    }
    private buildGradeItem(item: GradeItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(230:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(231:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.courseName);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(232:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.semester);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(238:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(245:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.score.toString());
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(246:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.getScoreColor(item.score));
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`绩点 ${item.gpa.toFixed(1)}`);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(251:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildLibrarySection(parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.libraryBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/StudyPage.ets", line: 265, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.libraryBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
    }
    private libraryBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(270:5)", "entry");
        }, Column);
        this.buildSectionHeader.bind(this)('图书馆', '进入');
        this.buildLibraryContent.bind(this)();
        this.buildLibraryButton.bind(this)();
        Column.pop();
    }
    private buildLibraryContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 16 });
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(279:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(280:7)", "entry");
            Column.width(80);
            Column.height(80);
            Column.borderRadius(16);
            Column.backgroundColor('#722ED115');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📚');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(281:9)", "entry");
            Text.fontSize(48);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/StudyPage.ets(290:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校图书馆');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(291:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('藏书100万册，共6层，支持按书名、作者、ISBN 检索，并可收藏图书。');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(295:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.lineHeight(20);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildLibraryButton(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(308:5)", "entry");
            Row.width('100%');
            Row.height(48);
            Row.borderRadius(24);
            Row.backgroundColor('#722ED1');
            Row.justifyContent(FlexAlign.Center);
            Row.onClick(() => {
                if (this.onNavigate) {
                    this.onNavigate('library');
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('进入图书馆');
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(309:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildSectionHeader(title: string, action: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudyPage.ets(328:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(329:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/StudyPage.ets(333:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(action);
            Text.debugLine("entry/src/main/ets/pages/StudyPage.ets(334:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private getCoursesByWeekday(weekday: number): CourseItem[] {
        const list = this.courseList.length > 0 ? this.courseList : AppData.courses;
        return list.filter(item => item.weekday === weekday && item.weeks.includes(this.currentWeek));
    }
    private getSortedGrades(): GradeItem[] {
        const grades = AppData.grades.slice();
        if (this.gradeSortAsc) {
            return grades.sort((a, b) => a.gpa - b.gpa);
        }
        else {
            return grades.sort((a, b) => b.gpa - a.gpa);
        }
    }
    private getScoreColor(score: number): string {
        if (score >= 90)
            return AppTheme.SUCCESS_GREEN;
        if (score >= 80)
            return AppTheme.BRAND_BLUE;
        if (score >= 60)
            return AppTheme.WARN_ORANGE;
        return AppTheme.BRAND_BLUE;
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBgColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
