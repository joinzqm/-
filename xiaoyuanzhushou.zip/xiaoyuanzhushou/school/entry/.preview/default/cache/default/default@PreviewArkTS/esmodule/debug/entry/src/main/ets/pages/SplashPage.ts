if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SplashPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onFinish?: () => void;
    progress?: number;
    splashTimer?: number;
}
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class SplashPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onFinish = undefined;
        this.__progress = new ObservedPropertySimplePU(0, this, "progress");
        this.splashTimer = -1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SplashPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onFinish !== undefined) {
            this.onFinish = params.onFinish;
        }
        if (params.progress !== undefined) {
            this.progress = params.progress;
        }
        if (params.splashTimer !== undefined) {
            this.splashTimer = params.splashTimer;
        }
    }
    updateStateVars(params: SplashPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__progress.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__progress.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onFinish?: () => void;
    private __progress: ObservedPropertySimplePU<number>;
    get progress() {
        return this.__progress.get();
    }
    set progress(newValue: number) {
        this.__progress.set(newValue);
    }
    private splashTimer: number;
    aboutToAppear(): void {
        this.startProgress();
    }
    aboutToDisappear(): void {
        if (this.splashTimer !== -1) {
            clearInterval(this.splashTimer);
            this.splashTimer = -1;
        }
    }
    private startProgress(): void {
        let count = 0;
        const total = 30;
        this.splashTimer = setInterval(() => {
            count++;
            this.progress = (count / total) * 100;
            if (count >= total) {
                clearInterval(this.splashTimer);
                this.splashTimer = -1;
                if (this.onFinish) {
                    this.onFinish();
                }
            }
        }, 100);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SplashPage.ets(40:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(AppTheme.BRAND_BLUE);
            Column.onClick(() => {
                if (this.onFinish) {
                    this.onFinish();
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/SplashPage.ets(41:7)", "entry");
            Column.layoutWeight(1);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🎓');
            Text.debugLine("entry/src/main/ets/pages/SplashPage.ets(42:9)", "entry");
            Text.fontSize(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('高校校园助手');
            Text.debugLine("entry/src/main/ets/pages/SplashPage.ets(45:9)", "entry");
            Text.fontSize(32 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('HarmonyOS NEXT 版');
            Text.debugLine("entry/src/main/ets/pages/SplashPage.ets(50:9)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontColor('#E6F0FF');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/SplashPage.ets(57:7)", "entry");
            Column.margin({ bottom: 40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Progress.create({ value: this.progress, total: 100, type: ProgressType.Ring });
            Progress.debugLine("entry/src/main/ets/pages/SplashPage.ets(58:9)", "entry");
            Progress.width(40);
            Progress.height(40);
            Progress.color(Color.White);
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园助手开发团队');
            Text.debugLine("entry/src/main/ets/pages/SplashPage.ets(63:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor('#E6F0FF');
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
