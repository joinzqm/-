if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface GuidePage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onFinish?: () => void;
    currentIndex?: number;
    guideItems?: GuideItem[];
}
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
interface GuideItem {
    icon: string;
    title: string;
    desc: string;
}
export class GuidePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onFinish = undefined;
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.guideItems = [
            {
                icon: '🏫',
                title: '校园信息，实时掌握',
                desc: '校园公告、资讯、地图，一手了解校园动态'
            },
            {
                icon: '📚',
                title: '学习助手，高效备考',
                desc: '课程表、成绩查询、图书馆检索，助力学业提升'
            },
            {
                icon: '❤️',
                title: '生活服务，贴心相伴',
                desc: '失物招领、校园美食、音乐播放，丰富校园生活'
            }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: GuidePage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onFinish !== undefined) {
            this.onFinish = params.onFinish;
        }
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.guideItems !== undefined) {
            this.guideItems = params.guideItems;
        }
    }
    updateStateVars(params: GuidePage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onFinish?: () => void;
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private readonly guideItems: GuideItem[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/GuidePage.ets(36:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/pages/GuidePage.ets(37:7)", "entry");
            Swiper.width('100%');
            Swiper.layoutWeight(1);
            Swiper.indicator(false);
            Swiper.index(this.currentIndex);
            Swiper.onChange((index: number) => {
                this.currentIndex = index;
            });
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.buildGuideItem.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.guideItems, forEachItemGenFunction, (item: GuideItem) => item.title, true, false);
        }, ForEach);
        ForEach.pop();
        Swiper.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 24 });
            Column.debugLine("entry/src/main/ets/pages/GuidePage.ets(50:7)", "entry");
            Column.padding({ bottom: 60, top: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/GuidePage.ets(51:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const _ = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Circle.create({ width: 8, height: 8 });
                    Circle.debugLine("entry/src/main/ets/pages/GuidePage.ets(53:13)", "entry");
                    Circle.fill(this.currentIndex === index ? AppTheme.BRAND_BLUE : AppTheme.BORDER);
                    Circle.onClick(() => {
                        this.currentIndex = index;
                    });
                }, Circle);
            };
            this.forEachUpdateFunction(elmtId, this.guideItems, forEachItemGenFunction, (_: GuideItem, index: number) => index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentIndex === this.guideItems.length - 1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('立即进入');
                        Button.debugLine("entry/src/main/ets/pages/GuidePage.ets(62:11)", "entry");
                        Button.width('80%');
                        Button.height(48);
                        Button.borderRadius(12);
                        Button.fontSize(16 * this.fontScale);
                        Button.fontColor(Color.White);
                        Button.backgroundColor(AppTheme.BRAND_BLUE);
                        Button.onClick(() => {
                            if (this.onFinish) {
                                this.onFinish();
                            }
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Column.pop();
    }
    private buildGuideItem(item: GuideItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 24 });
            Column.debugLine("entry/src/main/ets/pages/GuidePage.ets(85:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.icon);
            Text.debugLine("entry/src/main/ets/pages/GuidePage.ets(86:7)", "entry");
            Text.fontSize(120);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/GuidePage.ets(89:7)", "entry");
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/GuidePage.ets(90:9)", "entry");
            Text.fontSize(28 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.desc);
            Text.debugLine("entry/src/main/ets/pages/GuidePage.ets(95:9)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontColor(this.primaryText());
            Text.textAlign(TextAlign.Center);
            Text.lineHeight(24);
            Text.width('80%');
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
