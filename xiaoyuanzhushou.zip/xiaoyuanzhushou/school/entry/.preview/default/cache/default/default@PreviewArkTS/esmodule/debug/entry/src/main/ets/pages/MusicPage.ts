if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MusicPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onBack?: () => void;
    isPlaying?: boolean;
    currentIndex?: number;
    progress?: number;
    showList?: boolean;
    rotateAngle?: number;
    musicList?: MusicItem[];
    rotateTimer?: number;
}
import { PageHeader } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { MusicItem } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class MusicPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onBack = undefined;
        this.__isPlaying = new ObservedPropertySimplePU(false, this, "isPlaying");
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__progress = new ObservedPropertySimplePU(0, this, "progress");
        this.__showList = new ObservedPropertySimplePU(true, this, "showList");
        this.__rotateAngle = new ObservedPropertySimplePU(0, this, "rotateAngle");
        this.musicList = AppData.musics;
        this.rotateTimer = -1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MusicPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.isPlaying !== undefined) {
            this.isPlaying = params.isPlaying;
        }
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.progress !== undefined) {
            this.progress = params.progress;
        }
        if (params.showList !== undefined) {
            this.showList = params.showList;
        }
        if (params.rotateAngle !== undefined) {
            this.rotateAngle = params.rotateAngle;
        }
        if (params.musicList !== undefined) {
            this.musicList = params.musicList;
        }
        if (params.rotateTimer !== undefined) {
            this.rotateTimer = params.rotateTimer;
        }
    }
    updateStateVars(params: MusicPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__isPlaying.purgeDependencyOnElmtId(rmElmtId);
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__progress.purgeDependencyOnElmtId(rmElmtId);
        this.__showList.purgeDependencyOnElmtId(rmElmtId);
        this.__rotateAngle.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__isPlaying.aboutToBeDeleted();
        this.__currentIndex.aboutToBeDeleted();
        this.__progress.aboutToBeDeleted();
        this.__showList.aboutToBeDeleted();
        this.__rotateAngle.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onBack?: () => void;
    private __isPlaying: ObservedPropertySimplePU<boolean>;
    get isPlaying() {
        return this.__isPlaying.get();
    }
    set isPlaying(newValue: boolean) {
        this.__isPlaying.set(newValue);
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private __progress: ObservedPropertySimplePU<number>;
    get progress() {
        return this.__progress.get();
    }
    set progress(newValue: number) {
        this.__progress.set(newValue);
    }
    private __showList: ObservedPropertySimplePU<boolean>;
    get showList() {
        return this.__showList.get();
    }
    set showList(newValue: boolean) {
        this.__showList.set(newValue);
    }
    private __rotateAngle: ObservedPropertySimplePU<number>;
    get rotateAngle() {
        return this.__rotateAngle.get();
    }
    set rotateAngle(newValue: number) {
        this.__rotateAngle.set(newValue);
    }
    private musicList: MusicItem[];
    private rotateTimer: number;
    aboutToAppear(): void {
        if (this.isPlaying) {
            this.startRotate();
        }
    }
    aboutToDisappear(): void {
        this.stopRotate();
    }
    private startRotate(): void {
        if (this.rotateTimer !== -1) {
            return;
        }
        this.rotateTimer = setInterval(() => {
            this.rotateAngle = (this.rotateAngle + 2) % 360;
            // 模拟播放进度推进
            const totalSeconds = this.parseDuration(this.currentMusic.duration);
            if (totalSeconds > 0) {
                this.progress = Math.min(100, this.progress + (100 * 0.05 / totalSeconds));
                if (this.progress >= 100) {
                    this.playNext();
                }
            }
        }, 50);
    }
    private stopRotate(): void {
        if (this.rotateTimer !== -1) {
            clearInterval(this.rotateTimer);
            this.rotateTimer = -1;
        }
    }
    private togglePlay(): void {
        this.isPlaying = !this.isPlaying;
        if (this.isPlaying) {
            this.startRotate();
        }
        else {
            this.stopRotate();
        }
    }
    private playPrev(): void {
        if (this.currentIndex === 0) {
            this.currentIndex = this.musicList.length - 1;
        }
        else {
            this.currentIndex--;
        }
        this.progress = 0;
    }
    private playNext(): void {
        if (this.currentIndex === this.musicList.length - 1) {
            this.currentIndex = 0;
        }
        else {
            this.currentIndex++;
        }
        this.progress = 0;
    }
    private selectMusic(index: number): void {
        this.currentIndex = index;
        this.progress = 0;
        if (!this.isPlaying) {
            this.isPlaying = true;
            this.startRotate();
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(95:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '音乐播放',
                        rightAction: this.showList ? '收起' : '列表',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.showList = !this.showList;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MusicPage.ets", line: 96, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '音乐播放',
                            rightAction: this.showList ? '收起' : '列表',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.showList = !this.showList;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(111:7)", "entry");
            Column.width('100%');
            Column.height('60%');
            Column.justifyContent(FlexAlign.Center);
            Column.padding({ left: 24, right: 24, top: 16, bottom: 16 });
        }, Column);
        this.buildAlbumCover.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(114:9)", "entry");
            Column.margin({ top: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.currentMusic.title);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(115:11)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.currentMusic.artist);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(120:11)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.buildProgressBar.bind(this)();
        this.buildControlButtons.bind(this)();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showList) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(136:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.padding({ left: 16, right: 16, top: 12, bottom: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/MusicPage.ets(137:11)", "entry");
                        Row.width('100%');
                        Row.padding({ left: 4, bottom: 12 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('本地音乐');
                        Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(138:13)", "entry");
                        Text.fontSize(16 * this.fontScale);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(this.primaryText());
                        Text.layoutWeight(1);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.musicList.length} 首`);
                        Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(144:13)", "entry");
                        Text.fontSize(12 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 8 });
                        List.debugLine("entry/src/main/ets/pages/MusicPage.ets(151:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/MusicPage.ets(153:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildMusicItem.bind(this)(item, index);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.musicList, forEachItemGenFunction, (item: MusicItem) => item.id, true, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private buildAlbumCover(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MusicPage.ets(173:5)", "entry");
            Context.animation({ duration: 100, curve: Curve.Linear });
            Stack.width(200);
            Stack.height(200);
            Stack.rotate({ angle: this.rotateAngle });
            Context.animation(null);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create();
            Circle.debugLine("entry/src/main/ets/pages/MusicPage.ets(174:7)", "entry");
            Circle.width(200);
            Circle.height(200);
            Circle.fill(this.albumGradient());
            Circle.shadow({ radius: 20, color: '#40000000', offsetX: 0, offsetY: 8 });
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create();
            Circle.debugLine("entry/src/main/ets/pages/MusicPage.ets(180:7)", "entry");
            Circle.width(60);
            Circle.height(60);
            Circle.fill(this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE);
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🎵');
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(185:7)", "entry");
            Text.fontSize(48);
        }, Text);
        Text.pop();
        Stack.pop();
    }
    private buildProgressBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(196:5)", "entry");
            Column.width('100%');
            Column.margin({ top: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Progress.create({ value: this.progress, total: 100, type: ProgressType.Linear });
            Progress.debugLine("entry/src/main/ets/pages/MusicPage.ets(197:7)", "entry");
            Progress.width('100%');
            Progress.height(4);
            Progress.color(AppTheme.BRAND_BLUE);
            Progress.backgroundColor(this.surfaceColor());
            Progress.style({ strokeWidth: 4 });
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MusicPage.ets(204:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.formatTime(this.progress));
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(205:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.currentMusic.duration);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(210:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    private buildControlButtons(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 32 });
            Row.debugLine("entry/src/main/ets/pages/MusicPage.ets(222:5)", "entry");
            Row.margin({ top: 24 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('⏮');
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(223:7)", "entry");
            Text.fontSize(32);
            Text.fontColor(this.primaryText());
            Text.padding(12);
            Text.onClick(() => {
                this.playPrev();
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MusicPage.ets(231:7)", "entry");
            Stack.width(64);
            Stack.height(64);
            Stack.onClick(() => {
                this.togglePlay();
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create();
            Circle.debugLine("entry/src/main/ets/pages/MusicPage.ets(232:9)", "entry");
            Circle.width(64);
            Circle.height(64);
            Circle.fill(AppTheme.BRAND_BLUE);
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isPlaying ? '⏸' : '▶');
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(237:9)", "entry");
            Text.fontSize(28);
            Text.fontColor(Color.White);
            Text.margin({ left: this.isPlaying ? 0 : 4 });
        }, Text);
        Text.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('⏭');
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(248:7)", "entry");
            Text.fontSize(32);
            Text.fontColor(this.primaryText());
            Text.padding(12);
            Text.onClick(() => {
                this.playNext();
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildMusicItem(item: MusicItem, index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/MusicPage.ets(261:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor(index === this.currentIndex ? this.surfaceColor() : this.cardBackground());
            Row.borderRadius(10);
            Row.onClick(() => {
                this.selectMusic(index);
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MusicPage.ets(262:7)", "entry");
            Stack.width(40);
            Stack.height(40);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create();
            Circle.debugLine("entry/src/main/ets/pages/MusicPage.ets(263:9)", "entry");
            Circle.width(40);
            Circle.height(40);
            Circle.fill(this.itemCoverColor(index));
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🎵');
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(268:9)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MusicPage.ets(274:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(275:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(index === this.currentIndex ? AppTheme.BRAND_BLUE : this.primaryText());
            Text.fontWeight(index === this.currentIndex ? FontWeight.Medium : FontWeight.Normal);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.artist + ' · ' + item.album);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(282:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.duration);
            Text.debugLine("entry/src/main/ets/pages/MusicPage.ets(291:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
    }
    private albumGradient(): string {
        const colors = [
            ['#FF6B6B', '#FF8E8E'],
            ['#4ECDC4', '#7EDDD6'],
            ['#45B7D1', '#7BC9E0'],
            ['#96CEB4', '#B8DFCD'],
            ['#FFEAA7', '#FFF3C9']
        ];
        const colorPair = colors[this.currentIndex % colors.length];
        return colorPair[0];
    }
    private itemCoverColor(index: number): string {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#722ED1', '#F7BA1E'];
        return colors[index % colors.length];
    }
    private formatTime(percent: number): string {
        const totalSeconds = this.parseDuration(this.currentMusic.duration);
        const currentSeconds = Math.floor(totalSeconds * percent / 100);
        const mins = Math.floor(currentSeconds / 60);
        const secs = currentSeconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    private parseDuration(duration: string): number {
        const parts = duration.split(':');
        if (parts.length === 2) {
            return parseInt(parts[0]) * 60 + parseInt(parts[1]);
        }
        return 0;
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
