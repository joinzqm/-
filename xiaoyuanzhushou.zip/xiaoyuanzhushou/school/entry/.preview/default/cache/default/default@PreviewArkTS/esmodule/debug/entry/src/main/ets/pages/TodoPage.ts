if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TodoPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    todoList?: TodoItem[];
    onBack?: () => void;
    onTodoChange?: (list: TodoItem[]) => void;
    currentCategory?: string;
    showAddDialog?: boolean;
    newTodoTitle?: string;
    newTodoCategory?: string;
    categories?: string[];
}
import { PageHeader, TagButton, EmptyView } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { TodoItem } from '../model/AppModels';
import { AppTheme, AppState } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class TodoPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__todoList = new SynchedPropertyObjectOneWayPU(params.todoList, this, "todoList");
        this.onBack = undefined;
        this.onTodoChange = undefined;
        this.__currentCategory = new ObservedPropertySimplePU('全部', this, "currentCategory");
        this.__showAddDialog = new ObservedPropertySimplePU(false, this, "showAddDialog");
        this.__newTodoTitle = new ObservedPropertySimplePU('', this, "newTodoTitle");
        this.__newTodoCategory = new ObservedPropertySimplePU('学习', this, "newTodoCategory");
        this.categories = ['全部', '学习', '生活', '其他'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TodoPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.todoList === undefined) {
            this.__todoList.set([]);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.onTodoChange !== undefined) {
            this.onTodoChange = params.onTodoChange;
        }
        if (params.currentCategory !== undefined) {
            this.currentCategory = params.currentCategory;
        }
        if (params.showAddDialog !== undefined) {
            this.showAddDialog = params.showAddDialog;
        }
        if (params.newTodoTitle !== undefined) {
            this.newTodoTitle = params.newTodoTitle;
        }
        if (params.newTodoCategory !== undefined) {
            this.newTodoCategory = params.newTodoCategory;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
    }
    updateStateVars(params: TodoPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__todoList.reset(params.todoList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__showAddDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__newTodoTitle.purgeDependencyOnElmtId(rmElmtId);
        this.__newTodoCategory.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__todoList.aboutToBeDeleted();
        this.__currentCategory.aboutToBeDeleted();
        this.__showAddDialog.aboutToBeDeleted();
        this.__newTodoTitle.aboutToBeDeleted();
        this.__newTodoCategory.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __todoList: SynchedPropertySimpleOneWayPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    private onBack?: () => void;
    private onTodoChange?: (list: TodoItem[]) => void;
    private __currentCategory: ObservedPropertySimplePU<string>;
    get currentCategory() {
        return this.__currentCategory.get();
    }
    set currentCategory(newValue: string) {
        this.__currentCategory.set(newValue);
    }
    private __showAddDialog: ObservedPropertySimplePU<boolean>;
    get showAddDialog() {
        return this.__showAddDialog.get();
    }
    set showAddDialog(newValue: boolean) {
        this.__showAddDialog.set(newValue);
    }
    private __newTodoTitle: ObservedPropertySimplePU<string>;
    get newTodoTitle() {
        return this.__newTodoTitle.get();
    }
    set newTodoTitle(newValue: string) {
        this.__newTodoTitle.set(newValue);
    }
    private __newTodoCategory: ObservedPropertySimplePU<string>;
    get newTodoCategory() {
        return this.__newTodoCategory.get();
    }
    set newTodoCategory(newValue: string) {
        this.__newTodoCategory.set(newValue);
    }
    private categories: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/TodoPage.ets(28:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(29:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '待办事项',
                        rightAction: '新增',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.newTodoTitle = '';
                            this.newTodoCategory = '学习';
                            this.showAddDialog = true;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/TodoPage.ets", line: 30, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '待办事项',
                            rightAction: '新增',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.newTodoTitle = '';
                                this.newTodoCategory = '学习';
                                this.showAddDialog = true;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.buildCategoryTabs.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.filteredTodos.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new EmptyView(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    icon: '📝',
                                    text: '暂无待办事项'
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/TodoPage.ets", line: 50, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        icon: '📝',
                                        text: '暂无待办事项'
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "EmptyView" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 10 });
                        List.debugLine("entry/src/main/ets/pages/TodoPage.ets(57:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, top: 12, bottom: 12 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/TodoPage.ets(59:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildTodoItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.filteredTodos, forEachItemGenFunction, (item: TodoItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showAddDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildDialogMask.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildDialogMask(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/TodoPage.ets(83:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(84:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0, 0, 0, 0.5)');
            Column.onClick(() => {
                this.showAddDialog = false;
            });
        }, Column);
        Column.pop();
        this.buildAddDialog.bind(this)();
        Stack.pop();
    }
    private buildCategoryTabs(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/TodoPage.ets(101:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 12, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: category,
                                active: this.currentCategory === category,
                                onTap: () => {
                                    this.currentCategory = category;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/TodoPage.ets", line: 103, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: category,
                                    active: this.currentCategory === category,
                                    onTap: () => {
                                        this.currentCategory = category;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (category: string) => category, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    private buildTodoItem(item: TodoItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/TodoPage.ets(120:5)", "entry");
            Row.width('100%');
            Row.padding(14);
            Row.backgroundColor(this.cardBackground());
            Row.borderRadius(12);
        }, Row);
        this.buildCheckbox.bind(this)(item.finished, () => {
            this.toggleTodo(item.id);
        });
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(125:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(126:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(item.finished ? this.secondaryText() : this.primaryText());
            Text.decoration({ type: item.finished ? TextDecorationType.LineThrough : TextDecorationType.None });
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/TodoPage.ets(134:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.category);
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(135:11)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
            Text.backgroundColor(this.surfaceColor());
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (item.remindTime) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(item.remindTime);
                        Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(143:13)", "entry");
                        Text.fontSize(11 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🗑️');
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(152:7)", "entry");
            Text.fontSize(18);
            Text.padding(8);
            Text.onClick(() => {
                this.deleteTodo(item.id);
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildCheckbox(checked: boolean, onChange: () => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(checked ? '☑️' : '⬜');
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(167:5)", "entry");
            Text.fontSize(22);
            Text.onClick(() => {
                onChange();
            });
        }, Text);
        Text.pop();
    }
    private buildAddDialog(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(176:5)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 16, bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('新增待办');
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(177:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(185:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('待办标题');
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(186:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入待办内容', text: this.newTodoTitle });
            TextInput.debugLine("entry/src/main/ets/pages/TodoPage.ets(190:9)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => {
                this.newTodoTitle = value;
            });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/TodoPage.ets(206:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择分类');
            Text.debugLine("entry/src/main/ets/pages/TodoPage.ets(207:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/TodoPage.ets(211:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: category,
                                active: this.newTodoCategory === category,
                                onTap: () => {
                                    this.newTodoCategory = category;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/TodoPage.ets", line: 213, col: 13 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: category,
                                    active: this.newTodoCategory === category,
                                    onTap: () => {
                                        this.newTodoCategory = category;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, ['学习', '生活', '其他'], forEachItemGenFunction, (category: string) => category, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/TodoPage.ets(228:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8, bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/TodoPage.ets(229:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(this.surfaceColor());
            Button.fontColor(this.primaryText());
            Button.borderRadius(22);
            Button.onClick(() => {
                this.showAddDialog = false;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('确定');
            Button.debugLine("entry/src/main/ets/pages/TodoPage.ets(240:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.fontColor(Color.White);
            Button.borderRadius(22);
            Button.onClick(() => {
                this.addTodo();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    private addTodo(): void {
        if (!this.newTodoTitle.trim()) {
            return;
        }
        const newTodo: TodoItem = {
            id: AppState.generateId(),
            title: this.newTodoTitle.trim(),
            category: this.newTodoCategory,
            finished: false
        };
        const updatedList: TodoItem[] = this.todoList.concat([newTodo]);
        this.todoList = updatedList;
        if (this.onTodoChange) {
            this.onTodoChange(updatedList);
        }
        this.showAddDialog = false;
    }
    private toggleTodo(id: string): void {
        const updatedList: TodoItem[] = this.todoList.map((item: TodoItem) => {
            if (item.id === id) {
                const newItem: TodoItem = {
                    id: item.id,
                    title: item.title,
                    category: item.category,
                    finished: !item.finished
                };
                if (item.remindTime) {
                    newItem.remindTime = item.remindTime;
                }
                return newItem;
            }
            return item;
        });
        this.todoList = updatedList;
        if (this.onTodoChange) {
            this.onTodoChange(updatedList);
        }
    }
    private deleteTodo(id: string): void {
        const updatedList = this.todoList.filter(item => item.id !== id);
        this.todoList = updatedList;
        if (this.onTodoChange) {
            this.onTodoChange(updatedList);
        }
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
