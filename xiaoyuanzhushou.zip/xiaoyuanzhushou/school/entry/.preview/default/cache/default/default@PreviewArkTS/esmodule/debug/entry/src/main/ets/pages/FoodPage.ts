if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FoodPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    foodList?: FoodItem[];
    onBack?: () => void;
    onFoodsChange?: (list: FoodItem[]) => void;
    currentCategory?: string;
    filteredList?: FoodItem[];
    categories?: string[];
}
import { PageHeader, TagButton, StarRating } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { FoodItem } from '../model/AppModels';
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class FoodPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__foodList = new SynchedPropertyObjectOneWayPU(params.foodList, this, "foodList");
        this.onBack = undefined;
        this.onFoodsChange = undefined;
        this.__currentCategory = new ObservedPropertySimplePU('全部', this, "currentCategory");
        this.__filteredList = new ObservedPropertyObjectPU([], this, "filteredList");
        this.categories = ['全部', '第一食堂', '第二食堂', '校外周边'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FoodPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.foodList === undefined) {
            this.__foodList.set([]);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.onFoodsChange !== undefined) {
            this.onFoodsChange = params.onFoodsChange;
        }
        if (params.currentCategory !== undefined) {
            this.currentCategory = params.currentCategory;
        }
        if (params.filteredList !== undefined) {
            this.filteredList = params.filteredList;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
    }
    updateStateVars(params: FoodPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__foodList.reset(params.foodList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__foodList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__filteredList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__foodList.aboutToBeDeleted();
        this.__currentCategory.aboutToBeDeleted();
        this.__filteredList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __foodList: SynchedPropertySimpleOneWayPU<FoodItem[]>;
    get foodList() {
        return this.__foodList.get();
    }
    set foodList(newValue: FoodItem[]) {
        this.__foodList.set(newValue);
    }
    private onBack?: () => void;
    private onFoodsChange?: (list: FoodItem[]) => void;
    private __currentCategory: ObservedPropertySimplePU<string>;
    get currentCategory() {
        return this.__currentCategory.get();
    }
    set currentCategory(newValue: string) {
        this.__currentCategory.set(newValue);
    }
    private __filteredList: ObservedPropertyObjectPU<FoodItem[]>;
    get filteredList() {
        return this.__filteredList.get();
    }
    set filteredList(newValue: FoodItem[]) {
        this.__filteredList.set(newValue);
    }
    private categories: string[];
    aboutToAppear() {
        this.filteredList = this.foodList.slice();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(23:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '校园美食',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FoodPage.ets", line: 24, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '校园美食',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(35:7)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.padding({ left: 16, right: 16, top: 12, bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
            Flex.debugLine("entry/src/main/ets/pages/FoodPage.ets(36:9)", "entry");
            Flex.width('100%');
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: category,
                                active: this.currentCategory === category,
                                onTap: () => {
                                    this.currentCategory = category;
                                    this.filterFoods();
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FoodPage.ets", line: 38, col: 13 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: category,
                                    active: this.currentCategory === category,
                                    onTap: () => {
                                        this.currentCategory = category;
                                        this.filterFoods();
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (category: string) => category, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.filteredList.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/FoodPage.ets(53:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/FoodPage.ets(55:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildFoodItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.filteredList, forEachItemGenFunction, (item: FoodItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.buildEmptyView.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Column.pop();
    }
    private buildFoodItem(item: FoodItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 0 });
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(78:5)", "entry");
            Column.width('100%');
            Column.borderRadius(12);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(79:7)", "entry");
            Column.width('100%');
            Column.height(100);
            Column.backgroundColor(item.imageColor);
            Column.borderRadius({ topLeft: 12, topRight: 12 });
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.name.charAt(0));
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(80:9)", "entry");
            Text.fontSize(28 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(91:7)", "entry");
            Column.width('100%');
            Column.padding(12);
            Column.backgroundColor(this.cardColor());
            Column.borderRadius({ bottomLeft: 12, bottomRight: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/FoodPage.ets(92:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(93:11)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.name);
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(94:13)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.shop);
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(100:13)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.favorite ? '♥' : '♡');
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(109:11)", "entry");
            Text.fontSize(22 * this.fontScale);
            Text.fontColor(item.favorite ? '#F53F3F' : this.secondaryText());
            Text.onClick(() => {
                this.toggleFavorite(item.id);
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/FoodPage.ets(118:9)", "entry");
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new StarRating(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        rating: item.rating,
                        starSize: 14
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FoodPage.ets", line: 119, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            rating: item.rating,
                            starSize: 14
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "StarRating" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.rating.toFixed(1));
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(125:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 6 });
            Row.debugLine("entry/src/main/ets/pages/FoodPage.ets(130:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('特色:');
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(131:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.specialDish);
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(134:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    private buildEmptyView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/FoodPage.ets(152:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🍜');
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(153:7)", "entry");
            Text.fontSize(60);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('暂无美食');
            Text.debugLine("entry/src/main/ets/pages/FoodPage.ets(155:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private filterFoods() {
        if (this.currentCategory === '全部') {
            this.filteredList = this.foodList;
        }
        else {
            this.filteredList = this.foodList.filter((food: FoodItem) => {
                return food.location === this.currentCategory;
            });
        }
    }
    private toggleFavorite(foodId: string) {
        const index: number = this.foodList.findIndex((f: FoodItem) => f.id === foodId);
        if (index !== -1) {
            const newList: FoodItem[] = [];
            for (let i: number = 0; i < this.foodList.length; i++) {
                const f: FoodItem = this.foodList[i];
                if (i === index) {
                    newList.push({
                        id: f.id,
                        name: f.name,
                        shop: f.shop,
                        location: f.location,
                        rating: f.rating,
                        specialDish: f.specialDish,
                        imageColor: f.imageColor,
                        favorite: !f.favorite
                    });
                }
                else {
                    newList.push(f);
                }
            }
            this.foodList = newList;
            this.filterFoods();
            if (this.onFoodsChange) {
                this.onFoodsChange(this.foodList);
            }
        }
    }
    private pageBackground(): string {
        return this.darkMode ? '#101214' : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private primaryText(): string {
        return this.darkMode ? '#F2F3F5' : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? '#C9CDD4' : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
