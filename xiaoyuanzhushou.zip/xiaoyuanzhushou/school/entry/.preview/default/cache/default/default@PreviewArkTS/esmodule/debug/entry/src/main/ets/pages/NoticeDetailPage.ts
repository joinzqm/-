if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface NoticeDetailPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    notice?: NoticeItem;
    onBack?: () => void;
    onFavoriteChange?: (notice: NoticeItem) => void;
    isFavorite?: boolean;
    showToast?: boolean;
    toastMessage?: string;
    toastTimer?: number;
}
import { PageHeader } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { NoticeItem } from '../model/AppModels';
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class NoticeDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.notice = {
            id: '',
            title: '',
            summary: '',
            content: '',
            time: '',
            category: ''
        };
        this.onBack = undefined;
        this.onFavoriteChange = undefined;
        this.__isFavorite = new ObservedPropertySimplePU(false, this, "isFavorite");
        this.__showToast = new ObservedPropertySimplePU(false, this, "showToast");
        this.__toastMessage = new ObservedPropertySimplePU('', this, "toastMessage");
        this.toastTimer = -1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: NoticeDetailPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.notice !== undefined) {
            this.notice = params.notice;
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.onFavoriteChange !== undefined) {
            this.onFavoriteChange = params.onFavoriteChange;
        }
        if (params.isFavorite !== undefined) {
            this.isFavorite = params.isFavorite;
        }
        if (params.showToast !== undefined) {
            this.showToast = params.showToast;
        }
        if (params.toastMessage !== undefined) {
            this.toastMessage = params.toastMessage;
        }
        if (params.toastTimer !== undefined) {
            this.toastTimer = params.toastTimer;
        }
    }
    updateStateVars(params: NoticeDetailPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__isFavorite.purgeDependencyOnElmtId(rmElmtId);
        this.__showToast.purgeDependencyOnElmtId(rmElmtId);
        this.__toastMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__isFavorite.aboutToBeDeleted();
        this.__showToast.aboutToBeDeleted();
        this.__toastMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private notice: NoticeItem;
    private onBack?: () => void;
    private onFavoriteChange?: (notice: NoticeItem) => void;
    private __isFavorite: ObservedPropertySimplePU<boolean>;
    get isFavorite() {
        return this.__isFavorite.get();
    }
    set isFavorite(newValue: boolean) {
        this.__isFavorite.set(newValue);
    }
    private __showToast: ObservedPropertySimplePU<boolean>;
    get showToast() {
        return this.__showToast.get();
    }
    set showToast(newValue: boolean) {
        this.__showToast.set(newValue);
    }
    private __toastMessage: ObservedPropertySimplePU<string>;
    get toastMessage() {
        return this.__toastMessage.get();
    }
    set toastMessage(newValue: string) {
        this.__toastMessage.set(newValue);
    }
    private toastTimer: number;
    aboutToAppear() {
        this.isFavorite = this.notice.favorite ?? false;
    }
    aboutToDisappear() {
        if (this.toastTimer !== -1) {
            clearTimeout(this.toastTimer);
            this.toastTimer = -1;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(37:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(38:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '公告详情',
                        rightAction: this.isFavorite ? '★ 已收藏' : '☆ 收藏',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.toggleFavorite();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/NoticeDetailPage.ets", line: 39, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '公告详情',
                            rightAction: this.isFavorite ? '★ 已收藏' : '☆ 收藏',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.toggleFavorite();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(54:9)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(55:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 20, bottom: 100 });
        }, Column);
        this.buildNoticeContent.bind(this)();
        Column.pop();
        Scroll.pop();
        this.buildBottomBar.bind(this)();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showToast) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.toastMessage);
                        Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(71:9)", "entry");
                        Text.fontSize(14 * this.fontScale);
                        Text.fontColor(Color.White);
                        Text.padding({ left: 20, right: 20, top: 12, bottom: 12 });
                        Text.backgroundColor('rgba(0, 0, 0, 0.7)');
                        Text.borderRadius(8);
                        Text.margin({ bottom: 120 });
                        Text.transition(TransitionEffect.OPACITY.animation({ duration: 200 }));
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildNoticeContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(87:5)", "entry");
            Column.width('100%');
            Column.padding(20);
            Column.backgroundColor(this.cardColor());
            Column.borderRadius(16);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.notice.title);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(88:7)", "entry");
            Text.fontSize(22 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
            Text.lineHeight(30);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(94:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.notice.time);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(95:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.notice.category);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(99:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
            Text.padding({ left: 10, right: 10, top: 4, bottom: 4 });
            Text.backgroundColor(this.darkMode ? 'rgba(22, 119, 255, 0.15)' : 'rgba(22, 119, 255, 0.08)');
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(108:7)", "entry");
            Divider.color(this.dividerColor());
            Divider.margin({ top: 8, bottom: 8 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.notice.content);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(112:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
            Text.lineHeight(26);
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildBottomBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(127:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 20, right: 20, top: 12, bottom: 12 });
            Row.backgroundColor(this.cardColor());
            Row.border({ width: { top: 1 }, color: this.dividerColor() });
        }, Row);
        this.buildBottomButton.bind(this)('分享', '📤', () => {
            this.handleShare();
        });
        this.buildBottomButton.bind(this)(this.isFavorite ? '已收藏' : '收藏', this.isFavorite ? '★' : '☆', () => {
            this.toggleFavorite();
        }, this.isFavorite ? AppTheme.WARN_ORANGE : this.primaryText());
        Row.pop();
    }
    private buildBottomButton(label: string, icon: string, onClick: () => void, color?: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(149:5)", "entry");
            Column.layoutWeight(1);
            Column.padding({ top: 8, bottom: 8 });
            Column.onClick(() => {
                onClick();
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(icon);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(150:7)", "entry");
            Text.fontSize(20 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/NoticeDetailPage.ets(152:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(color ?? this.primaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private toggleFavorite() {
        this.isFavorite = !this.isFavorite;
        this.notice.favorite = this.isFavorite;
        if (this.onFavoriteChange) {
            this.onFavoriteChange(this.notice);
        }
        this.showToastMessage(this.isFavorite ? '收藏成功' : '已取消收藏');
    }
    private handleShare() {
        this.showToastMessage('链接已复制到剪贴板');
    }
    private showToastMessage(message: string) {
        this.toastMessage = message;
        this.showToast = true;
        if (this.toastTimer !== -1) {
            clearTimeout(this.toastTimer);
        }
        this.toastTimer = setTimeout(() => {
            this.showToast = false;
            this.toastTimer = -1;
        }, 2000);
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    private dividerColor(): string {
        return this.darkMode ? 'rgba(255, 255, 255, 0.08)' : AppTheme.BORDER;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
