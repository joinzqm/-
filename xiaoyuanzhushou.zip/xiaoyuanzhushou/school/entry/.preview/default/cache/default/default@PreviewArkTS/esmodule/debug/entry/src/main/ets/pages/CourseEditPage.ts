if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CourseEditPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    courseList?: CourseItem[];
    onBack?: () => void;
    onCoursesChange?: (list: CourseItem[]) => void;
    currentWeekday?: number;
    showAddDialog?: boolean;
    newCourseName?: string;
    newCourseTeacher?: string;
    newCourseLocation?: string;
    newStartSection?: number;
    newEndSection?: number;
    newCourseCredit?: number;
    weekdays?: string[];
}
import { PageHeader, TagButton, EmptyView } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { CourseItem } from '../model/AppModels';
import { AppTheme, AppData, AppState } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class CourseEditPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__courseList = new SynchedPropertyObjectOneWayPU(params.courseList, this, "courseList");
        this.onBack = undefined;
        this.onCoursesChange = undefined;
        this.__currentWeekday = new ObservedPropertySimplePU(1, this, "currentWeekday");
        this.__showAddDialog = new ObservedPropertySimplePU(false, this, "showAddDialog");
        this.__newCourseName = new ObservedPropertySimplePU('', this, "newCourseName");
        this.__newCourseTeacher = new ObservedPropertySimplePU('', this, "newCourseTeacher");
        this.__newCourseLocation = new ObservedPropertySimplePU('', this, "newCourseLocation");
        this.__newStartSection = new ObservedPropertySimplePU(1, this, "newStartSection");
        this.__newEndSection = new ObservedPropertySimplePU(2, this, "newEndSection");
        this.__newCourseCredit = new ObservedPropertySimplePU(2, this, "newCourseCredit");
        this.weekdays = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CourseEditPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.courseList === undefined) {
            this.__courseList.set([]);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.onCoursesChange !== undefined) {
            this.onCoursesChange = params.onCoursesChange;
        }
        if (params.currentWeekday !== undefined) {
            this.currentWeekday = params.currentWeekday;
        }
        if (params.showAddDialog !== undefined) {
            this.showAddDialog = params.showAddDialog;
        }
        if (params.newCourseName !== undefined) {
            this.newCourseName = params.newCourseName;
        }
        if (params.newCourseTeacher !== undefined) {
            this.newCourseTeacher = params.newCourseTeacher;
        }
        if (params.newCourseLocation !== undefined) {
            this.newCourseLocation = params.newCourseLocation;
        }
        if (params.newStartSection !== undefined) {
            this.newStartSection = params.newStartSection;
        }
        if (params.newEndSection !== undefined) {
            this.newEndSection = params.newEndSection;
        }
        if (params.newCourseCredit !== undefined) {
            this.newCourseCredit = params.newCourseCredit;
        }
        if (params.weekdays !== undefined) {
            this.weekdays = params.weekdays;
        }
    }
    updateStateVars(params: CourseEditPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__courseList.reset(params.courseList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentWeekday.purgeDependencyOnElmtId(rmElmtId);
        this.__showAddDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__newCourseName.purgeDependencyOnElmtId(rmElmtId);
        this.__newCourseTeacher.purgeDependencyOnElmtId(rmElmtId);
        this.__newCourseLocation.purgeDependencyOnElmtId(rmElmtId);
        this.__newStartSection.purgeDependencyOnElmtId(rmElmtId);
        this.__newEndSection.purgeDependencyOnElmtId(rmElmtId);
        this.__newCourseCredit.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__currentWeekday.aboutToBeDeleted();
        this.__showAddDialog.aboutToBeDeleted();
        this.__newCourseName.aboutToBeDeleted();
        this.__newCourseTeacher.aboutToBeDeleted();
        this.__newCourseLocation.aboutToBeDeleted();
        this.__newStartSection.aboutToBeDeleted();
        this.__newEndSection.aboutToBeDeleted();
        this.__newCourseCredit.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __courseList: SynchedPropertySimpleOneWayPU<CourseItem[]>;
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue: CourseItem[]) {
        this.__courseList.set(newValue);
    }
    private onBack?: () => void;
    private onCoursesChange?: (list: CourseItem[]) => void;
    private __currentWeekday: ObservedPropertySimplePU<number>;
    get currentWeekday() {
        return this.__currentWeekday.get();
    }
    set currentWeekday(newValue: number) {
        this.__currentWeekday.set(newValue);
    }
    private __showAddDialog: ObservedPropertySimplePU<boolean>;
    get showAddDialog() {
        return this.__showAddDialog.get();
    }
    set showAddDialog(newValue: boolean) {
        this.__showAddDialog.set(newValue);
    }
    private __newCourseName: ObservedPropertySimplePU<string>;
    get newCourseName() {
        return this.__newCourseName.get();
    }
    set newCourseName(newValue: string) {
        this.__newCourseName.set(newValue);
    }
    private __newCourseTeacher: ObservedPropertySimplePU<string>;
    get newCourseTeacher() {
        return this.__newCourseTeacher.get();
    }
    set newCourseTeacher(newValue: string) {
        this.__newCourseTeacher.set(newValue);
    }
    private __newCourseLocation: ObservedPropertySimplePU<string>;
    get newCourseLocation() {
        return this.__newCourseLocation.get();
    }
    set newCourseLocation(newValue: string) {
        this.__newCourseLocation.set(newValue);
    }
    private __newStartSection: ObservedPropertySimplePU<number>;
    get newStartSection() {
        return this.__newStartSection.get();
    }
    set newStartSection(newValue: number) {
        this.__newStartSection.set(newValue);
    }
    private __newEndSection: ObservedPropertySimplePU<number>;
    get newEndSection() {
        return this.__newEndSection.get();
    }
    set newEndSection(newValue: number) {
        this.__newEndSection.set(newValue);
    }
    private __newCourseCredit: ObservedPropertySimplePU<number>;
    get newCourseCredit() {
        return this.__newCourseCredit.get();
    }
    set newCourseCredit(newValue: number) {
        this.__newCourseCredit.set(newValue);
    }
    private weekdays: string[];
    private getTimeRange(start: number, end: number): string {
        const sections = AppData.sections;
        if (start >= 1 && start <= sections.length && end >= 1 && end <= sections.length && start <= end) {
            return sections[start - 1].start + '-' + sections[end - 1].end;
        }
        return '';
    }
    private getRandomColor(): string {
        const colors = AppTheme.COURSE_COLORS;
        return colors[Math.floor(Math.random() * colors.length)];
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(43:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(44:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '课程管理',
                        rightAction: '添加',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.resetForm();
                            this.showAddDialog = true;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 45, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '课程管理',
                            rightAction: '添加',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.resetForm();
                                this.showAddDialog = true;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.buildWeekdayTabs.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.filteredCourses.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new EmptyView(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    icon: '📚',
                                    text: '暂无课程'
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 64, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        icon: '📚',
                                        text: '暂无课程'
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "EmptyView" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 10 });
                        List.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(71:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, top: 12, bottom: 12 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(73:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildCourseItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.filteredCourses, forEachItemGenFunction, (item: CourseItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showAddDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildDialogMask.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildDialogMask(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(97:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(98:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0, 0, 0, 0.5)');
            Column.onClick(() => {
                this.showAddDialog = false;
                this.resetForm();
            });
        }, Column);
        Column.pop();
        this.buildAddDialog.bind(this)();
        Stack.pop();
    }
    private buildWeekdayTabs(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(116:5)", "entry");
            Scroll.width('100%');
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(117:7)", "entry");
            Row.padding({ left: 16, right: 16, top: 12, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const day = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: day,
                                active: this.currentWeekday === index + 1,
                                onTap: () => {
                                    this.currentWeekday = index + 1;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 119, col: 11 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: day,
                                    active: this.currentWeekday === index + 1,
                                    onTap: () => {
                                        this.currentWeekday = index + 1;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.weekdays, forEachItemGenFunction, (day: string, index: number) => day + index, true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
    }
    private buildCourseItem(item: CourseItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(140:5)", "entry");
            Row.width('100%');
            Row.padding(14);
            Row.backgroundColor(this.cardBackground());
            Row.borderRadius(12);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create({ width: 10, height: 10 });
            Circle.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(141:7)", "entry");
            Circle.fill(item.color);
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(144:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(145:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
            Text.fontWeight(FontWeight.Medium);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(153:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.timeRange);
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(154:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('·');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(158:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.location);
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(162:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(169:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.teacher);
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(170:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.credit + '学分');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(174:11)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.padding({ left: 6, right: 6, top: 1, bottom: 1 });
            Text.backgroundColor(this.surfaceColor());
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🗑️');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(185:7)", "entry");
            Text.fontSize(18);
            Text.padding(8);
            Text.onClick(() => {
                this.deleteCourse(item.id);
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildAddDialog(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(200:5)", "entry");
            Column.width('100%');
            Column.height(480);
            Column.padding({ left: 20, right: 20, top: 16, bottom: 16 });
            Column.backgroundColor(this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG);
            Column.borderRadius({ topLeft: 16, topRight: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('添加课程');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(201:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(209:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollable(ScrollDirection.Vertical);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 14 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(210:9)", "entry");
            Column.width('100%');
            Column.padding({ bottom: 8 });
        }, Column);
        this.buildInputField.bind(this)('课程名称', '请输入课程名称', this.newCourseName, (value: string) => {
            this.newCourseName = value;
        });
        this.buildInputField.bind(this)('授课老师', '请输入老师姓名', this.newCourseTeacher, (value: string) => {
            this.newCourseTeacher = value;
        });
        this.buildInputField.bind(this)('上课地点', '请输入上课地点', this.newCourseLocation, (value: string) => {
            this.newCourseLocation = value;
        });
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(223:11)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('开始节次');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(224:13)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
            Flex.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(228:13)", "entry");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const section = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: '第' + section + '节',
                                active: this.newStartSection === section,
                                onTap: () => {
                                    this.newStartSection = section;
                                    if (this.newEndSection < section) {
                                        this.newEndSection = section;
                                    }
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 230, col: 17 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: '第' + section + '节',
                                    active: this.newStartSection === section,
                                    onTap: () => {
                                        this.newStartSection = section;
                                        if (this.newEndSection < section) {
                                            this.newEndSection = section;
                                        }
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => 'start' + section, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(248:11)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('结束节次');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(249:13)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
            Flex.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(253:13)", "entry");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const section = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: '第' + section + '节',
                                active: this.newEndSection === section,
                                onTap: () => {
                                    if (section >= this.newStartSection) {
                                        this.newEndSection = section;
                                    }
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 255, col: 17 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: '第' + section + '节',
                                    active: this.newEndSection === section,
                                    onTap: () => {
                                        if (section >= this.newStartSection) {
                                            this.newEndSection = section;
                                        }
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], forEachItemGenFunction, (section: number) => 'end' + section, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(272:11)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('学分');
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(273:13)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
            Flex.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(277:13)", "entry");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const credit = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: credit + '学分',
                                active: this.newCourseCredit === credit,
                                onTap: () => {
                                    this.newCourseCredit = credit;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CourseEditPage.ets", line: 279, col: 17 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: credit + '学分',
                                    active: this.newCourseCredit === credit,
                                    onTap: () => {
                                        this.newCourseCredit = credit;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6], forEachItemGenFunction, (credit: number) => 'credit' + credit, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        Column.pop();
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(301:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 8, bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(302:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(this.surfaceColor());
            Button.fontColor(this.primaryText());
            Button.borderRadius(22);
            Button.onClick(() => {
                this.showAddDialog = false;
                this.resetForm();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('确定');
            Button.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(314:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.fontColor(Color.White);
            Button.borderRadius(22);
            Button.onClick(() => {
                this.addCourse();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    private buildInputField(label: string, placeholder: string, value: string, onChange: (val: string) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(337:5)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(338:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: placeholder, text: value });
            TextInput.debugLine("entry/src/main/ets/pages/CourseEditPage.ets(342:7)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((val: string) => {
                onChange(val);
            });
        }, TextInput);
        Column.pop();
    }
    private resetForm(): void {
        this.newCourseName = '';
        this.newCourseTeacher = '';
        this.newCourseLocation = '';
        this.newStartSection = 1;
        this.newEndSection = 2;
        this.newCourseCredit = 2;
    }
    private addCourse(): void {
        if (!this.newCourseName.trim()) {
            return;
        }
        const newCourse: CourseItem = {
            id: AppState.generateId(),
            title: this.newCourseName.trim(),
            teacher: this.newCourseTeacher.trim() || '待定',
            location: this.newCourseLocation.trim() || '待定',
            weekday: this.currentWeekday,
            timeRange: this.getTimeRange(this.newStartSection, this.newEndSection),
            startSection: this.newStartSection,
            endSection: this.newEndSection,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: this.newCourseCredit,
            color: this.getRandomColor()
        };
        const updatedList: CourseItem[] = this.courseList.concat([newCourse]);
        this.courseList = updatedList;
        if (this.onCoursesChange) {
            this.onCoursesChange(updatedList);
        }
        this.showAddDialog = false;
    }
    private deleteCourse(id: string): void {
        const updatedList = this.courseList.filter(item => item.id !== id);
        this.courseList = updatedList;
        if (this.onCoursesChange) {
            this.onCoursesChange(updatedList);
        }
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
