import preferences from "@ohos:data.preferences";
import type common from "@ohos:app.ability.common";
export class PrefKeys {
    static readonly AUTH_LOGGED_IN: string = 'auth_logged_in';
    static readonly USER_STUDENT_ID: string = 'user_student_id';
    static readonly USER_NICKNAME: string = 'user_nickname';
    static readonly USER_COLLEGE: string = 'user_college';
    static readonly USER_MAJOR: string = 'user_major';
    static readonly USER_AVATAR_COLOR: string = 'user_avatar_color';
    static readonly SETTING_DARK_MODE: string = 'setting_dark_mode';
    static readonly SETTING_FONT_SCALE: string = 'setting_font_scale';
    static readonly SETTING_COURSE_REMINDER: string = 'setting_course_reminder';
    static readonly SETTING_NOTICE_REMINDER: string = 'setting_notice_reminder';
    static readonly SETTING_TODO_REMINDER: string = 'setting_todo_reminder';
    static readonly FIRST_LAUNCH: string = 'first_launch';
    static readonly REMEMBER_PASSWORD: string = 'remember_password';
    static readonly SAVED_PASSWORD: string = 'saved_password';
}
export class PreferencesStore {
    private static store: preferences.Preferences | null = null;
    private static initPromise: Promise<void> | null = null;
    private static readonly STORE_NAME: string = 'campus_assistant';
    static init(context: common.UIAbilityContext): Promise<void> {
        if (PreferencesStore.store || PreferencesStore.initPromise) {
            return PreferencesStore.initPromise ?? Promise.resolve();
        }
        PreferencesStore.initPromise = PreferencesStore.doInit(context);
        return PreferencesStore.initPromise;
    }
    private static async doInit(context: common.UIAbilityContext): Promise<void> {
        try {
            PreferencesStore.store = await preferences.getPreferences(context, PreferencesStore.STORE_NAME);
        }
        catch (e) {
            console.error(`PreferencesStore init error: ${JSON.stringify(e)}`);
            PreferencesStore.initPromise = null;
        }
    }
    static async getBoolean(key: string, defaultValue: boolean = false): Promise<boolean> {
        if (!PreferencesStore.store) {
            return defaultValue;
        }
        try {
            const val = await PreferencesStore.store.get(key, defaultValue);
            return typeof val === 'boolean' ? val : defaultValue;
        }
        catch (e) {
            console.error(`PreferencesStore getBoolean error: ${JSON.stringify(e)}`);
            return defaultValue;
        }
    }
    static async setBoolean(key: string, value: boolean): Promise<void> {
        if (!PreferencesStore.store) {
            return;
        }
        try {
            await PreferencesStore.store.put(key, value);
            await PreferencesStore.store.flush();
        }
        catch (e) {
            console.error(`PreferencesStore setBoolean error: ${JSON.stringify(e)}`);
        }
    }
    static async getString(key: string, defaultValue: string = ''): Promise<string> {
        if (!PreferencesStore.store) {
            return defaultValue;
        }
        try {
            const val = await PreferencesStore.store.get(key, defaultValue);
            return typeof val === 'string' ? val : defaultValue;
        }
        catch (e) {
            console.error(`PreferencesStore getString error: ${JSON.stringify(e)}`);
            return defaultValue;
        }
    }
    static async setString(key: string, value: string): Promise<void> {
        if (!PreferencesStore.store) {
            return;
        }
        try {
            await PreferencesStore.store.put(key, value);
            await PreferencesStore.store.flush();
        }
        catch (e) {
            console.error(`PreferencesStore setString error: ${JSON.stringify(e)}`);
        }
    }
    static async getNumber(key: string, defaultValue: number = 0): Promise<number> {
        if (!PreferencesStore.store) {
            return defaultValue;
        }
        try {
            const val = await PreferencesStore.store.get(key, defaultValue);
            return typeof val === 'number' ? val : defaultValue;
        }
        catch (e) {
            console.error(`PreferencesStore getNumber error: ${JSON.stringify(e)}`);
            return defaultValue;
        }
    }
    static async setNumber(key: string, value: number): Promise<void> {
        if (!PreferencesStore.store) {
            return;
        }
        try {
            await PreferencesStore.store.put(key, value);
            await PreferencesStore.store.flush();
        }
        catch (e) {
            console.error(`PreferencesStore setNumber error: ${JSON.stringify(e)}`);
        }
    }
    static async delete(key: string): Promise<void> {
        if (!PreferencesStore.store) {
            return;
        }
        try {
            await PreferencesStore.store.delete(key);
            await PreferencesStore.store.flush();
        }
        catch (e) {
            console.error(`PreferencesStore delete error: ${JSON.stringify(e)}`);
        }
    }
    static async clearAll(): Promise<void> {
        if (!PreferencesStore.store) {
            return;
        }
        try {
            await PreferencesStore.store.clear();
            await PreferencesStore.store.flush();
        }
        catch (e) {
            console.error(`PreferencesStore clearAll error: ${JSON.stringify(e)}`);
        }
    }
}
