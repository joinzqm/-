if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CampusPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    noticeList?: NoticeItem[];
    onNoticeClick?: (notice: NoticeItem) => void;
    onNavigate?: (page: string) => void;
    currentCategory?: number;
    categories?: string[];
    categoryIcons?: string[];
    categoryColors?: string[];
    scroller?: Scroller;
}
import { CommonCard } from "@bundle:com.campusassistant.app/entry/ets/components/CommonCard";
import { TagButton } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { NoticeItem } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class CampusPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__noticeList = new SynchedPropertyObjectOneWayPU(params.noticeList, this, "noticeList");
        this.onNoticeClick = undefined;
        this.onNavigate = undefined;
        this.__currentCategory = new ObservedPropertySimplePU(0, this, "currentCategory");
        this.categories = ['校园公告', '校园资讯', '社团活动', '学术讲座'];
        this.categoryIcons = ['📢', '📰', '🎭', '🎓'];
        this.categoryColors = ['#1677FF', '#00B42A', '#722ED1', '#FF7D00'];
        this.scroller = new Scroller();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CampusPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.noticeList === undefined) {
            this.__noticeList.set([]);
        }
        if (params.onNoticeClick !== undefined) {
            this.onNoticeClick = params.onNoticeClick;
        }
        if (params.onNavigate !== undefined) {
            this.onNavigate = params.onNavigate;
        }
        if (params.currentCategory !== undefined) {
            this.currentCategory = params.currentCategory;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
        if (params.categoryIcons !== undefined) {
            this.categoryIcons = params.categoryIcons;
        }
        if (params.categoryColors !== undefined) {
            this.categoryColors = params.categoryColors;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
    }
    updateStateVars(params: CampusPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__noticeList.reset(params.noticeList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__noticeList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentCategory.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__noticeList.aboutToBeDeleted();
        this.__currentCategory.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __noticeList: SynchedPropertySimpleOneWayPU<NoticeItem[]>;
    get noticeList() {
        return this.__noticeList.get();
    }
    set noticeList(newValue: NoticeItem[]) {
        this.__noticeList.set(newValue);
    }
    private onNoticeClick?: (notice: NoticeItem) => void;
    private onNavigate?: (page: string) => void;
    private __currentCategory: ObservedPropertySimplePU<number>;
    get currentCategory() {
        return this.__currentCategory.get();
    }
    set currentCategory(newValue: number) {
        this.__currentCategory.set(newValue);
    }
    private categories: string[];
    private categoryIcons: string[];
    private categoryColors: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/CampusPage.ets(20:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor(this.pageBackground());
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(21:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 18, bottom: 20 });
        }, Column);
        this.buildHeader.bind(this)();
        this.buildCategoryBar.bind(this)();
        this.buildNoticeList.bind(this)();
        this.buildMapEntry.bind(this)();
        Column.pop();
        Scroll.pop();
    }
    private buildHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(38:5)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园信息');
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(39:7)", "entry");
            Text.fontSize(24 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('公告、资讯、讲座与校园地图');
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(43:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildCategoryBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create(this.scroller);
            Scroll.debugLine("entry/src/main/ets/pages/CampusPage.ets(53:5)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/CampusPage.ets(54:7)", "entry");
            Row.padding({ right: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: item,
                                active: this.currentCategory === index,
                                activeColor: this.categoryColors[index],
                                onTap: () => {
                                    this.currentCategory = index;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CampusPage.ets", line: 56, col: 11 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: item,
                                    active: this.currentCategory === index,
                                    activeColor: this.categoryColors[index],
                                    onTap: () => {
                                        this.currentCategory = index;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (item: string, index: number) => index.toString(), true, true);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
    }
    private buildNoticeList(parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.noticeListBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CampusPage.ets", line: 77, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.noticeListBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
    }
    private noticeListBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(82:5)", "entry");
        }, Column);
        this.buildSectionHeader.bind(this)(this.categories[this.currentCategory], '查看全部');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(84:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.buildNoticeItem.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.getFilteredNotices(), forEachItemGenFunction, (item: NoticeItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        Column.pop();
    }
    private buildNoticeItem(item: NoticeItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/CampusPage.ets(94:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
            Row.onClick(() => {
                if (this.onNoticeClick) {
                    this.onNoticeClick(item);
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(95:7)", "entry");
            Column.width(56);
            Column.height(56);
            Column.borderRadius(12);
            Column.backgroundColor(this.categoryColors[this.currentCategory] + '15');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.categoryIcons[this.currentCategory]);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(96:9)", "entry");
            Text.fontSize(24);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(105:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(106:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.summary);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(112:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.lineHeight(20);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.time);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(118:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildMapEntry(parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.mapEntryBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CampusPage.ets", line: 138, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.mapEntryBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
    }
    private mapEntryBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CampusPage.ets(143:5)", "entry");
            Row.width('100%');
            Row.onClick(() => {
                if (this.onNavigate) {
                    this.onNavigate('map');
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(144:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园地图');
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(145:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('快速查找教学楼、图书馆、食堂等位置');
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(149:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(2);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CampusPage.ets(157:7)", "entry");
            Column.width(72);
            Column.height(72);
            Column.borderRadius(16);
            Column.backgroundColor(AppTheme.BRAND_BLUE + '15');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📍');
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(158:9)", "entry");
            Text.fontSize(36);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildSectionHeader(title: string, action: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CampusPage.ets(177:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(178:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/CampusPage.ets(182:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(action);
            Text.debugLine("entry/src/main/ets/pages/CampusPage.ets(183:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private getFilteredNotices(): NoticeItem[] {
        const list = this.noticeList.length > 0 ? this.noticeList : AppData.notices;
        const categoryMap: Record<number, string[]> = {
            0: ['学校通知'],
            1: ['社团活动', '学术讲座'],
            2: ['社团活动'],
            3: ['学术讲座']
        };
        const targetCategories = categoryMap[this.currentCategory] || [];
        return list.filter(item => targetCategories.includes(item.category));
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    private scroller: Scroller;
    rerender() {
        this.updateDirtyElements();
    }
}
