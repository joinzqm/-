if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    isLoggedIn?: boolean;
    darkMode?: boolean;
    fontScale?: number;
    onLoginSuccess?: () => void;
    isRegister?: boolean;
    studentId?: string;
    password?: string;
    nickname?: string;
    confirmPassword?: string;
}
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import { PrefKeys, PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
export class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isLoggedIn = new SynchedPropertySimpleTwoWayPU(params.isLoggedIn, this, "isLoggedIn");
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onLoginSuccess = undefined;
        this.__isRegister = new ObservedPropertySimplePU(false, this, "isRegister");
        this.__studentId = new ObservedPropertySimplePU('', this, "studentId");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__nickname = new ObservedPropertySimplePU('', this, "nickname");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onLoginSuccess !== undefined) {
            this.onLoginSuccess = params.onLoginSuccess;
        }
        if (params.isRegister !== undefined) {
            this.isRegister = params.isRegister;
        }
        if (params.studentId !== undefined) {
            this.studentId = params.studentId;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.nickname !== undefined) {
            this.nickname = params.nickname;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
    }
    updateStateVars(params: LoginPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__isRegister.purgeDependencyOnElmtId(rmElmtId);
        this.__studentId.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__nickname.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isLoggedIn.aboutToBeDeleted();
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__isRegister.aboutToBeDeleted();
        this.__studentId.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__nickname.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isLoggedIn: SynchedPropertySimpleTwoWayPU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onLoginSuccess?: () => void;
    private __isRegister: ObservedPropertySimplePU<boolean>;
    get isRegister() {
        return this.__isRegister.get();
    }
    set isRegister(newValue: boolean) {
        this.__isRegister.set(newValue);
    }
    private __studentId: ObservedPropertySimplePU<string>;
    get studentId() {
        return this.__studentId.get();
    }
    set studentId(newValue: string) {
        this.__studentId.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __nickname: ObservedPropertySimplePU<string>;
    get nickname() {
        return this.__nickname.get();
    }
    set nickname(newValue: string) {
        this.__nickname.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(18:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 18 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(19:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 24, right: 24, top: 40, bottom: 24 });
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.buildBrandBlock.bind(this)();
        this.buildTabSwitch.bind(this)();
        this.buildForm.bind(this)();
        Column.pop();
        Column.pop();
    }
    private buildBrandBlock(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(35:5)", "entry");
            Column.width('100%');
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('高校校园助手');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(36:7)", "entry");
            Text.fontSize(30 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('HarmonyOS NEXT 校园生活、学习与服务一体化助手');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(41:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.textAlign(TextAlign.Center);
            Text.lineHeight(22);
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildTabSwitch(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(53:5)", "entry");
            Row.width('100%');
            Row.padding(4);
            Row.backgroundColor(this.cardColor());
            Row.borderRadius(16);
        }, Row);
        this.buildTabItem.bind(this)('登录', !this.isRegister);
        this.buildTabItem.bind(this)('注册', this.isRegister);
        Row.pop();
    }
    private buildTabItem(label: string, active: boolean, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(65:5)", "entry");
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
            Text.fontSize(16 * this.fontScale);
            Text.fontWeight(active ? FontWeight.Medium : FontWeight.Regular);
            Text.fontColor(active ? Color.White : this.secondaryText());
            Text.padding({ top: 12, bottom: 12 });
            Text.backgroundColor(active ? AppTheme.BRAND_BLUE : Color.Transparent);
            Text.borderRadius(12);
            Text.onClick(() => {
                this.isRegister = label === '注册';
            });
        }, Text);
        Text.pop();
    }
    private buildForm(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 14 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(81:5)", "entry");
            Column.width('100%');
            Column.padding(20);
            Column.margin({ top: 18 });
            Column.backgroundColor(this.cardColor());
            Column.borderRadius(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isRegister) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildInput.bind(this)('请输入昵称', this.nickname, (value: string) => {
                        this.nickname = value;
                    });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.buildInput.bind(this)('请输入学号', this.studentId, (value: string) => {
            this.studentId = value;
        });
        this.buildInput.bind(this)('请输入密码', this.password, (value: string) => {
            this.password = value;
        });
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isRegister) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildInput.bind(this)('请再次输入密码', this.confirmPassword, (value: string) => {
                        this.confirmPassword = value;
                    });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isRegister ? '注册并进入' : '登录进入');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(102:7)", "entry");
            Button.width('100%');
            Button.height(48);
            Button.borderRadius(12);
            Button.fontSize(16 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(this.canSubmit() ? AppTheme.BRAND_BLUE : '#C6E2FF');
            Button.enabled(this.canSubmit());
            Button.onClick(async () => {
                await PreferencesStore.setString(PrefKeys.USER_STUDENT_ID, this.studentId);
                if (this.isRegister) {
                    await PreferencesStore.setString(PrefKeys.USER_NICKNAME, this.nickname);
                }
                await PreferencesStore.setBoolean(PrefKeys.AUTH_LOGGED_IN, true);
                this.isLoggedIn = true;
                if (this.onLoginSuccess) {
                    this.onLoginSuccess();
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isRegister ? '已有账号？切换到登录即可进入首页。' : '暂无账号？切换到注册即可完成模拟注册。');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(122:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.textAlign(TextAlign.Center);
            Text.width('100%');
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildInput(placeholder: string, value: string, onChangeEvent: (value: string) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder, text: value });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(137:5)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(12);
            TextInput.padding({ left: 16, right: 16 });
            TextInput.onChange((input: string) => {
                onChangeEvent(input);
            });
        }, TextInput);
    }
    private canSubmit(): boolean {
        if (!this.studentId || !this.password) {
            return false;
        }
        if (!this.isRegister) {
            return true;
        }
        return !!this.nickname && this.confirmPassword === this.password;
    }
    private pageBackground(): string {
        return this.darkMode ? '#101214' : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? '#171A1F' : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? '#1F2329' : '#F7F8FA';
    }
    private primaryText(): string {
        return this.darkMode ? '#F2F3F5' : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? '#C9CDD4' : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
