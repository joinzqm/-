if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface HomePage_Params {
    darkMode?: boolean;
    fontScale?: number;
    todoList?: TodoItem[];
    courseList?: CourseItem[];
    noticeList?: NoticeItem[];
    onNavigate?: (page: string) => void;
    onNoticeClick?: (notice: NoticeItem) => void;
}
import { CommonCard } from "@bundle:com.campusassistant.app/entry/ets/components/CommonCard";
import type { CourseItem, NoticeItem, QuickEntry, TodoItem, WeatherItem } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class HomePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__todoList = new SynchedPropertyObjectOneWayPU(params.todoList, this, "todoList");
        this.__courseList = new SynchedPropertyObjectOneWayPU(params.courseList, this, "courseList");
        this.__noticeList = new SynchedPropertyObjectOneWayPU(params.noticeList, this, "noticeList");
        this.onNavigate = undefined;
        this.onNoticeClick = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: HomePage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.todoList === undefined) {
            this.__todoList.set([]);
        }
        if (params.courseList === undefined) {
            this.__courseList.set([]);
        }
        if (params.noticeList === undefined) {
            this.__noticeList.set([]);
        }
        if (params.onNavigate !== undefined) {
            this.onNavigate = params.onNavigate;
        }
        if (params.onNoticeClick !== undefined) {
            this.onNoticeClick = params.onNoticeClick;
        }
    }
    updateStateVars(params: HomePage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__todoList.reset(params.todoList);
        this.__courseList.reset(params.courseList);
        this.__noticeList.reset(params.noticeList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__noticeList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__todoList.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__noticeList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __todoList: SynchedPropertySimpleOneWayPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    private __courseList: SynchedPropertySimpleOneWayPU<CourseItem[]>;
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue: CourseItem[]) {
        this.__courseList.set(newValue);
    }
    private __noticeList: SynchedPropertySimpleOneWayPU<NoticeItem[]>;
    get noticeList() {
        return this.__noticeList.get();
    }
    set noticeList(newValue: NoticeItem[]) {
        this.__noticeList.set(newValue);
    }
    private onNavigate?: (page: string) => void;
    private onNoticeClick?: (notice: NoticeItem) => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/HomePage.ets(16:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor(this.pageBackground());
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/HomePage.ets(17:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 18, bottom: 20 });
        }, Column);
        this.buildHeader.bind(this)();
        this.buildSearchBar.bind(this)();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.quickEntryBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/HomePage.ets", line: 20, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.quickEntryBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.weatherBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/HomePage.ets", line: 21, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.weatherBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.noticeBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/HomePage.ets", line: 22, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.noticeBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.courseBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/HomePage.ets", line: 23, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.courseBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.todoBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/HomePage.ets", line: 24, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.todoBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        Column.pop();
        Scroll.pop();
    }
    private buildHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/HomePage.ets(37:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/HomePage.ets(38:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园助手');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(39:9)", "entry");
            Text.fontSize(24 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('校园公告、课程提醒与待办概览');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(43:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/HomePage.ets(48:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🔔');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(49:7)", "entry");
            Text.fontSize(20 * this.fontScale);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildSearchBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/HomePage.ets(57:5)", "entry");
            Row.width('100%');
            Row.padding({ left: 16, right: 16, top: 14, bottom: 14 });
            Row.backgroundColor(this.cardColor());
            Row.borderRadius(24);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🔍');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(58:7)", "entry");
            Text.fontSize(14 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('搜索校园信息 / 课程 / 美食');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(60:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/HomePage.ets(63:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🎤');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(64:7)", "entry");
            Text.fontSize(14 * this.fontScale);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private quickEntryBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('核心功能', '更多');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.SpaceBetween });
            Flex.debugLine("entry/src/main/ets/pages/HomePage.ets(76:5)", "entry");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 8 });
                    Column.debugLine("entry/src/main/ets/pages/HomePage.ets(78:9)", "entry");
                    Column.width('22%');
                    Column.margin({ bottom: 12 });
                    Column.onClick(() => {
                        if (this.onNavigate) {
                            this.onNavigate(item.id);
                        }
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.icon);
                    Text.debugLine("entry/src/main/ets/pages/HomePage.ets(79:11)", "entry");
                    Text.width(44);
                    Text.height(44);
                    Text.borderRadius(22);
                    Text.textAlign(TextAlign.Center);
                    Text.fontSize(22 * this.fontScale);
                    Text.backgroundColor(AppTheme.BRAND_BLUE + '15');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/pages/HomePage.ets(86:11)", "entry");
                    Text.fontSize(12 * this.fontScale);
                    Text.fontColor(this.primaryText());
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, AppData.quickEntries, forEachItemGenFunction, (item: QuickEntry) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
    }
    private weatherBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('今日天气', '详情');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (AppData.weatherForecast.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/HomePage.ets(105:7)", "entry");
                        Row.width('100%');
                        Row.padding(12);
                        Row.borderRadius(12);
                        Row.backgroundColor(this.surfaceColor());
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 4 });
                        Column.debugLine("entry/src/main/ets/pages/HomePage.ets(106:9)", "entry");
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/HomePage.ets(107:9)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(AppData.weatherForecast[0].icon);
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(108:11)", "entry");
                        Text.fontSize(40);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 2 });
                        Column.debugLine("entry/src/main/ets/pages/HomePage.ets(110:11)", "entry");
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(AppData.weatherForecast[0].temperature);
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(111:13)", "entry");
                        Text.fontSize(20 * this.fontScale);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(this.primaryText());
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(AppData.weatherForecast[0].weather);
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(115:13)", "entry");
                        Text.fontSize(13 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(AppData.weatherForecast[0].wind);
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(121:9)", "entry");
                        Text.fontSize(12 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/HomePage.ets(126:7)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 6 });
                        Column.debugLine("entry/src/main/ets/pages/HomePage.ets(127:7)", "entry");
                        Column.alignItems(HorizontalAlign.End);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create({ space: 8 });
                                Row.debugLine("entry/src/main/ets/pages/HomePage.ets(129:11)", "entry");
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.date);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(130:13)", "entry");
                                Text.fontSize(12 * this.fontScale);
                                Text.fontColor(this.secondaryText());
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.icon);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(133:13)", "entry");
                                Text.fontSize(16);
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.temperature.split('~')[1]);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(135:13)", "entry");
                                Text.fontSize(12 * this.fontScale);
                                Text.fontColor(this.primaryText());
                            }, Text);
                            Text.pop();
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, AppData.weatherForecast.slice(1, 3), forEachItemGenFunction, (item: WeatherItem) => item.date, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    private noticeBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('校园公告', '更多');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/HomePage.ets(153:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 6 });
                    Column.debugLine("entry/src/main/ets/pages/HomePage.ets(155:9)", "entry");
                    Column.alignItems(HorizontalAlign.Start);
                    Column.width('100%');
                    Column.padding(12);
                    Column.borderRadius(12);
                    Column.backgroundColor(this.surfaceColor());
                    Column.onClick(() => {
                        if (this.onNoticeClick) {
                            this.onNoticeClick(item);
                        }
                        else if (this.onNavigate) {
                            this.onNavigate('notice');
                        }
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/pages/HomePage.ets(156:11)", "entry");
                    Text.fontSize(16 * this.fontScale);
                    Text.fontWeight(FontWeight.Medium);
                    Text.fontColor(this.primaryText());
                    Text.maxLines(1);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.summary);
                    Text.debugLine("entry/src/main/ets/pages/HomePage.ets(161:11)", "entry");
                    Text.fontSize(13 * this.fontScale);
                    Text.fontColor(this.secondaryText());
                    Text.lineHeight(20);
                    Text.maxLines(2);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.time);
                    Text.debugLine("entry/src/main/ets/pages/HomePage.ets(166:11)", "entry");
                    Text.fontSize(12 * this.fontScale);
                    Text.fontColor(this.secondaryText());
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.noticeList.slice(0, 3), forEachItemGenFunction, (item: NoticeItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    private getToday(): number {
        const jsDay = new Date().getDay();
        return jsDay === 0 ? 7 : jsDay;
    }
    private getTodayCourses(): CourseItem[] {
        const today = this.getToday();
        return this.courseList.filter((c: CourseItem) => c.weekday === today);
    }
    private courseBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('今日课程', '学习助手');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.getTodayCourses().length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('今日无课程，好好休息吧～');
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(200:7)", "entry");
                        Text.fontSize(14 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding({ top: 20, bottom: 20 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 12 });
                        Column.debugLine("entry/src/main/ets/pages/HomePage.ets(207:7)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Row.create();
                                Row.debugLine("entry/src/main/ets/pages/HomePage.ets(209:11)", "entry");
                                Row.width('100%');
                                Row.padding(12);
                                Row.borderRadius(12);
                                Row.backgroundColor(this.surfaceColor());
                            }, Row);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Column.create({ space: 4 });
                                Column.debugLine("entry/src/main/ets/pages/HomePage.ets(210:13)", "entry");
                                Column.alignItems(HorizontalAlign.Start);
                            }, Column);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(item.title);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(211:15)", "entry");
                                Text.fontSize(16 * this.fontScale);
                                Text.fontWeight(FontWeight.Medium);
                                Text.fontColor(this.primaryText());
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${item.timeRange}  ${item.location}`);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(215:15)", "entry");
                                Text.fontSize(13 * this.fontScale);
                                Text.fontColor(this.secondaryText());
                            }, Text);
                            Text.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create(`${item.teacher} · ${AppData.weekdays[item.weekday - 1]}`);
                                Text.debugLine("entry/src/main/ets/pages/HomePage.ets(218:15)", "entry");
                                Text.fontSize(12 * this.fontScale);
                                Text.fontColor(this.secondaryText());
                            }, Text);
                            Text.pop();
                            Column.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Blank.create();
                                Blank.debugLine("entry/src/main/ets/pages/HomePage.ets(223:13)", "entry");
                            }, Blank);
                            Blank.pop();
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Circle.create({ width: 8, height: 8 });
                                Circle.debugLine("entry/src/main/ets/pages/HomePage.ets(224:13)", "entry");
                                Circle.fill(item.color);
                            }, Circle);
                            Row.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.getTodayCourses(), forEachItemGenFunction, (item: CourseItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
    }
    private todoBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('待办提醒', '全部');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/HomePage.ets(239:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.buildTodoRow.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.todoList.slice(0, 3), forEachItemGenFunction, (item: TodoItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.todoList.length > 3) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('查看全部待办');
                        Text.debugLine("entry/src/main/ets/pages/HomePage.ets(245:9)", "entry");
                        Text.fontSize(13 * this.fontScale);
                        Text.fontColor(AppTheme.BRAND_BLUE);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding({ top: 8 });
                        Text.onClick(() => {
                            if (this.onNavigate) {
                                this.onNavigate('todo');
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private buildTodoRow(item: TodoItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/HomePage.ets(262:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.finished ? '✓' : '○');
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(263:7)", "entry");
            Text.width(28);
            Text.height(28);
            Text.borderRadius(14);
            Text.textAlign(TextAlign.Center);
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(Color.White);
            Text.backgroundColor(item.finished ? AppTheme.SUCCESS_GREEN : AppTheme.WARN_ORANGE);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/HomePage.ets(271:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(272:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(item.finished ? this.secondaryText() : this.primaryText());
            Text.decoration({ type: item.finished ? TextDecorationType.LineThrough : TextDecorationType.None });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.category);
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(276:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildSectionHeader(title: string, action: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/HomePage.ets(290:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(291:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/HomePage.ets(295:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(action);
            Text.debugLine("entry/src/main/ets/pages/HomePage.ets(296:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
            Text.onClick(() => {
                if (title === '校园公告' && this.onNavigate) {
                    this.onNavigate('notice');
                }
                else if (title === '待办提醒' && this.onNavigate) {
                    this.onNavigate('todo');
                }
                else if (title === '今日课程' && this.onNavigate) {
                    this.onNavigate('schedule');
                }
                else if (title === '核心功能' && this.onNavigate) {
                    this.onNavigate('more');
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
