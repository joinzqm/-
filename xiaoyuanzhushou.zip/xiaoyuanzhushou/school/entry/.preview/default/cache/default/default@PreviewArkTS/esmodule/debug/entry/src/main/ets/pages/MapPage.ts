if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MapPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onBack?: () => void;
    searchText?: string;
    selectedBuilding?: CampusBuilding | null;
    showDetailDialog?: boolean;
    scroller?: Scroller;
}
import { PageHeader, SearchBar } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { CampusBuilding } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class MapPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onBack = undefined;
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__selectedBuilding = new ObservedPropertyObjectPU(null, this, "selectedBuilding");
        this.__showDetailDialog = new ObservedPropertySimplePU(false, this, "showDetailDialog");
        this.scroller = new Scroller();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MapPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.selectedBuilding !== undefined) {
            this.selectedBuilding = params.selectedBuilding;
        }
        if (params.showDetailDialog !== undefined) {
            this.showDetailDialog = params.showDetailDialog;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
    }
    updateStateVars(params: MapPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedBuilding.purgeDependencyOnElmtId(rmElmtId);
        this.__showDetailDialog.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__selectedBuilding.aboutToBeDeleted();
        this.__showDetailDialog.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onBack?: () => void;
    private __searchText: ObservedPropertySimplePU<string>;
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue: string) {
        this.__searchText.set(newValue);
    }
    private __selectedBuilding: ObservedPropertyObjectPU<CampusBuilding | null>;
    get selectedBuilding() {
        return this.__selectedBuilding.get();
    }
    set selectedBuilding(newValue: CampusBuilding | null) {
        this.__selectedBuilding.set(newValue);
    }
    private __showDetailDialog: ObservedPropertySimplePU<boolean>;
    get showDetailDialog() {
        return this.__showDetailDialog.get();
    }
    set showDetailDialog(newValue: boolean) {
        this.__showDetailDialog.set(newValue);
    }
    private scroller: Scroller;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MapPage.ets(17:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(18:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '校园地图',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MapPage.ets", line: 19, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '校园地图',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(30:9)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.padding({ left: 16, right: 16, top: 12, bottom: 16 });
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SearchBar(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        placeholder: '搜索建筑名称',
                        searchText: this.__searchText
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/MapPage.ets", line: 31, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            placeholder: '搜索建筑名称',
                            searchText: this.searchText
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "SearchBar" });
        }
        this.buildMapArea.bind(this)();
        this.buildBuildingList.bind(this)();
        Column.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showDetailDialog && this.selectedBuilding) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildDetailMask.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildMapArea(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/MapPage.ets(60:5)", "entry");
            Stack.width('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(61:7)", "entry");
            Column.width('100%');
            Column.height(320);
            Column.borderRadius(20);
            Column.backgroundColor(this.mapBackground());
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(67:7)", "entry");
            Column.width('100%');
            Column.height(320);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 4 });
                    Column.debugLine("entry/src/main/ets/pages/MapPage.ets(69:11)", "entry");
                    Column.alignItems(HorizontalAlign.Center);
                    Column.position({ x: this.calculateX(item.x), y: this.calculateY(item.y) });
                    Column.translate({ x: -50, y: -100 });
                    Column.onClick(() => {
                        this.selectedBuilding = item;
                        this.showDetailDialog = true;
                    });
                    Column.zIndex(this.isSelected(item) ? 2 : 1);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MapPage.ets(70:13)", "entry");
                    Column.width(32);
                    Column.height(32);
                    Column.borderRadius(16);
                    Column.backgroundColor(this.isSelected(item) ? '#FFFFFF' : '#FFFFFFCC');
                    Column.justifyContent(FlexAlign.Center);
                    Column.shadow({ radius: this.isSelected(item) ? 8 : 4, color: '#00000033' });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('📍');
                    Text.debugLine("entry/src/main/ets/pages/MapPage.ets(71:15)", "entry");
                    Text.fontSize(20);
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.name);
                    Text.debugLine("entry/src/main/ets/pages/MapPage.ets(81:13)", "entry");
                    Text.fontSize(11 * this.fontScale);
                    Text.fontColor(this.isSelected(item) ? AppTheme.BRAND_BLUE : '#1D2129');
                    Text.fontWeight(this.isSelected(item) ? FontWeight.Medium : FontWeight.Normal);
                    Text.backgroundColor('#FFFFFFE6');
                    Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
                    Text.borderRadius(8);
                    Text.maxLines(1);
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.getFilteredBuildings(), forEachItemGenFunction, (item: CampusBuilding) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
        Stack.pop();
    }
    private buildBuildingList(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(108:5)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MapPage.ets(109:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('快捷入口');
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(110:9)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/MapPage.ets(114:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`共${AppData.campusBuildings.length}个`);
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(115:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create(this.scroller);
            Scroll.debugLine("entry/src/main/ets/pages/MapPage.ets(121:7)", "entry");
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
            Scroll.width('100%');
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/MapPage.ets(122:9)", "entry");
            Row.padding({ right: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 6 });
                    Column.debugLine("entry/src/main/ets/pages/MapPage.ets(124:13)", "entry");
                    Column.alignItems(HorizontalAlign.Center);
                    Column.onClick(() => {
                        this.selectedBuilding = item;
                        this.showDetailDialog = true;
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/MapPage.ets(125:15)", "entry");
                    Column.width(56);
                    Column.height(56);
                    Column.borderRadius(14);
                    Column.backgroundColor(this.buildingItemBg());
                    Column.justifyContent(FlexAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('🏛️');
                    Text.debugLine("entry/src/main/ets/pages/MapPage.ets(126:17)", "entry");
                    Text.fontSize(24);
                }, Text);
                Text.pop();
                Column.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.name);
                    Text.debugLine("entry/src/main/ets/pages/MapPage.ets(135:15)", "entry");
                    Text.fontSize(12 * this.fontScale);
                    Text.fontColor(this.primaryText());
                    Text.maxLines(1);
                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    Text.width(72);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.getFilteredBuildings(), forEachItemGenFunction, (item: CampusBuilding) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
        Column.pop();
    }
    private buildDetailMask(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/MapPage.ets(161:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(162:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#00000050');
            Column.onClick(() => {
                this.showDetailDialog = false;
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(170:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 20, bottom: 28 });
            Column.backgroundColor(this.cardColor());
            Column.borderRadius({ topLeft: 24, topRight: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MapPage.ets(171:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(172:11)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.selectedBuilding!.name);
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(173:13)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.selectedBuilding!.location);
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(177:13)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('✕');
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(184:11)", "entry");
            Text.fontSize(18);
            Text.fontColor(this.secondaryText());
            Text.width(32);
            Text.height(32);
            Text.textAlign(TextAlign.Center);
            Text.onClick(() => {
                this.showDetailDialog = false;
            });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(196:9)", "entry");
            Column.width('100%');
            Column.padding(14);
            Column.backgroundColor(this.surfaceColor());
            Column.borderRadius(12);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('建筑介绍');
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(197:11)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.selectedBuilding!.description);
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(201:11)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.lineHeight(20);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MapPage.ets(212:9)", "entry");
            Column.width('100%');
            Column.height(48);
            Column.borderRadius(24);
            Column.backgroundColor(AppTheme.BRAND_BLUE);
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(() => {
                this.showDetailDialog = false;
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('导航到这里');
            Text.debugLine("entry/src/main/ets/pages/MapPage.ets(213:11)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
        Stack.pop();
    }
    private getFilteredBuildings(): CampusBuilding[] {
        if (!this.searchText || this.searchText.trim().length === 0) {
            return AppData.campusBuildings;
        }
        return AppData.campusBuildings.filter((item: CampusBuilding) => {
            return item.name.includes(this.searchText) ||
                item.location.includes(this.searchText) ||
                item.description.includes(this.searchText);
        });
    }
    private isSelected(item: CampusBuilding): boolean {
        return this.selectedBuilding !== null && this.selectedBuilding.id === item.id;
    }
    private calculateX(percent: number): number {
        const totalWidth = 300;
        return totalWidth * percent / 100 + 16;
    }
    private calculateY(percent: number): number {
        const totalHeight = 280;
        return totalHeight * percent / 100 + 20;
    }
    private mapGradientColors(): string[] {
        return this.darkMode
            ? ['#1F2937', '#111827', '#0F172A']
            : ['#E0F2FE', '#BAE6FD', '#7DD3FC'];
    }
    private mapBackground(): string {
        return this.darkMode ? '#1F2937' : '#E0F2FE';
    }
    private buildingItemBg(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
