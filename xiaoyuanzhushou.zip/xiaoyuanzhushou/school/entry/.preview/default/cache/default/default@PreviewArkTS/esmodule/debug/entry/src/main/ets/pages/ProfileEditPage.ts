if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProfileEditPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onBack?: () => void;
    nickname?: string;
    studentId?: string;
    college?: string;
    major?: string;
    avatarColor?: string;
    passwordTip?: string;
    avatarColors?: string[];
}
import { PageHeader } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import { PrefKeys, PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
export class ProfileEditPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onBack = undefined;
        this.__nickname = new ObservedPropertySimplePU('', this, "nickname");
        this.__studentId = new ObservedPropertySimplePU('', this, "studentId");
        this.__college = new ObservedPropertySimplePU('', this, "college");
        this.__major = new ObservedPropertySimplePU('', this, "major");
        this.__avatarColor = new ObservedPropertySimplePU(AppTheme.BRAND_BLUE, this, "avatarColor");
        this.__passwordTip = new ObservedPropertySimplePU('', this, "passwordTip");
        this.avatarColors = [
            '#1677FF', '#FF7D00', '#00B42A', '#722ED1',
            '#F53F3F', '#14C9C9', '#F7BA1E', '#F5A94B'
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProfileEditPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.nickname !== undefined) {
            this.nickname = params.nickname;
        }
        if (params.studentId !== undefined) {
            this.studentId = params.studentId;
        }
        if (params.college !== undefined) {
            this.college = params.college;
        }
        if (params.major !== undefined) {
            this.major = params.major;
        }
        if (params.avatarColor !== undefined) {
            this.avatarColor = params.avatarColor;
        }
        if (params.passwordTip !== undefined) {
            this.passwordTip = params.passwordTip;
        }
        if (params.avatarColors !== undefined) {
            this.avatarColors = params.avatarColors;
        }
    }
    updateStateVars(params: ProfileEditPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__nickname.purgeDependencyOnElmtId(rmElmtId);
        this.__studentId.purgeDependencyOnElmtId(rmElmtId);
        this.__college.purgeDependencyOnElmtId(rmElmtId);
        this.__major.purgeDependencyOnElmtId(rmElmtId);
        this.__avatarColor.purgeDependencyOnElmtId(rmElmtId);
        this.__passwordTip.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__nickname.aboutToBeDeleted();
        this.__studentId.aboutToBeDeleted();
        this.__college.aboutToBeDeleted();
        this.__major.aboutToBeDeleted();
        this.__avatarColor.aboutToBeDeleted();
        this.__passwordTip.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onBack?: () => void;
    private __nickname: ObservedPropertySimplePU<string>;
    get nickname() {
        return this.__nickname.get();
    }
    set nickname(newValue: string) {
        this.__nickname.set(newValue);
    }
    private __studentId: ObservedPropertySimplePU<string>;
    get studentId() {
        return this.__studentId.get();
    }
    set studentId(newValue: string) {
        this.__studentId.set(newValue);
    }
    private __college: ObservedPropertySimplePU<string>;
    get college() {
        return this.__college.get();
    }
    set college(newValue: string) {
        this.__college.set(newValue);
    }
    private __major: ObservedPropertySimplePU<string>;
    get major() {
        return this.__major.get();
    }
    set major(newValue: string) {
        this.__major.set(newValue);
    }
    private __avatarColor: ObservedPropertySimplePU<string>;
    get avatarColor() {
        return this.__avatarColor.get();
    }
    set avatarColor(newValue: string) {
        this.__avatarColor.set(newValue);
    }
    private __passwordTip: ObservedPropertySimplePU<string>;
    get passwordTip() {
        return this.__passwordTip.get();
    }
    set passwordTip(newValue: string) {
        this.__passwordTip.set(newValue);
    }
    private avatarColors: string[];
    aboutToAppear(): void {
        this.loadUserInfo();
    }
    private async loadUserInfo(): Promise<void> {
        const savedNickname = await PreferencesStore.getString(PrefKeys.USER_NICKNAME, '');
        const savedStudentId = await PreferencesStore.getString(PrefKeys.USER_STUDENT_ID, '');
        const savedCollege = await PreferencesStore.getString(PrefKeys.USER_COLLEGE, '');
        const savedMajor = await PreferencesStore.getString(PrefKeys.USER_MAJOR, '');
        const savedAvatarColor = await PreferencesStore.getString(PrefKeys.USER_AVATAR_COLOR, AppTheme.BRAND_BLUE);
        this.nickname = savedNickname || '张同学';
        this.studentId = savedStudentId || '20260001';
        this.college = savedCollege || '计算机学院';
        this.major = savedMajor || '软件工程';
        this.avatarColor = savedAvatarColor || AppTheme.BRAND_BLUE;
    }
    private async saveUserInfo(): Promise<void> {
        await PreferencesStore.setString(PrefKeys.USER_NICKNAME, this.nickname);
        await PreferencesStore.setString(PrefKeys.USER_STUDENT_ID, this.studentId);
        await PreferencesStore.setString(PrefKeys.USER_COLLEGE, this.college);
        await PreferencesStore.setString(PrefKeys.USER_MAJOR, this.major);
        await PreferencesStore.setString(PrefKeys.USER_AVATAR_COLOR, this.avatarColor);
        if (this.onBack) {
            this.onBack();
        }
    }
    private changeAvatarColor(): void {
        const currentIndex = this.avatarColors.indexOf(this.avatarColor);
        const nextIndex = (currentIndex + 1) % this.avatarColors.length;
        this.avatarColor = this.avatarColors[nextIndex];
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(60:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '编辑资料',
                        rightAction: '保存',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.saveUserInfo();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfileEditPage.ets", line: 61, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '编辑资料',
                            rightAction: '保存',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.saveUserInfo();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(76:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(77:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 20, bottom: 30 });
        }, Column);
        this.buildAvatarSection.bind(this)();
        this.buildFormSection.bind(this)();
        this.buildPasswordSection.bind(this)();
        this.buildSaveButton.bind(this)();
        Column.pop();
        Scroll.pop();
        Column.pop();
    }
    private buildAvatarSection(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(96:5)", "entry");
            Column.width('100%');
            Column.padding({ top: 16, bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.nickname ? this.nickname.charAt(0).toUpperCase() : 'U');
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(97:7)", "entry");
            Text.width(80);
            Text.height(80);
            Text.borderRadius(40);
            Text.textAlign(TextAlign.Center);
            Text.fontSize(28 * this.fontScale);
            Text.fontColor(Color.White);
            Text.backgroundColor(this.avatarColor);
            Text.onClick(() => {
                this.changeAvatarColor();
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点击更换头像颜色');
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(109:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildFormSection(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(119:5)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(12);
        }, Column);
        this.buildInputField.bind(this)('昵称', '请输入昵称', this.nickname, (value: string) => {
            this.nickname = value;
        });
        this.buildInputField.bind(this)('学号', '请输入学号', this.studentId, (value: string) => {
            this.studentId = value;
        });
        this.buildInputField.bind(this)('学院', '请输入学院名称', this.college, (value: string) => {
            this.college = value;
        });
        this.buildInputField.bind(this)('专业', '请输入专业名称', this.major, (value: string) => {
            this.major = value;
        });
        Column.pop();
    }
    private buildPasswordSection(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(144:5)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(12);
            Column.onClick(() => {
                this.passwordTip = '密码修改功能暂未开放';
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(145:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(146:9)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('修改密码');
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(147:11)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('点击进入密码修改页面');
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(150:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('›');
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(157:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.passwordTip) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.passwordTip);
                        Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(164:9)", "entry");
                        Text.fontSize(12 * this.fontScale);
                        Text.fontColor(AppTheme.WARN_ORANGE);
                        Text.width('100%');
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private buildSaveButton(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(181:5)", "entry");
            Button.width('100%');
            Button.height(48);
            Button.fontSize(16 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.borderRadius(24);
            Button.margin({ top: 10 });
            Button.onClick(() => {
                this.saveUserInfo();
            });
        }, Button);
        Button.pop();
    }
    private buildInputField(label: string, placeholder: string, value: string, onChange: (val: string) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(196:5)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(197:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: placeholder, text: value });
            TextInput.debugLine("entry/src/main/ets/pages/ProfileEditPage.ets(202:7)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((val: string) => {
                onChange(val);
            });
        }, TextInput);
        Column.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
