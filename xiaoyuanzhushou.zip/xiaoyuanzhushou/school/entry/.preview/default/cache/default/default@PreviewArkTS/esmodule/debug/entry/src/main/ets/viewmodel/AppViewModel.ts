import type { BookItem, CampusBuilding, CourseItem, CourseSection, FoodItem, GradeItem, LostFoundItem, MusicItem, NoticeItem, QuickEntry, ServiceCard, SettingItem, TodoItem, WeatherItem } from '../model/AppModels';
export class AppTheme {
    static readonly BRAND_BLUE: string = '#1677FF';
    static readonly WARN_ORANGE: string = '#FF7D00';
    static readonly SUCCESS_GREEN: string = '#00B42A';
    static readonly PAGE_BG: string = '#F5F7FA';
    static readonly CARD_BG: string = '#FFFFFF';
    static readonly PRIMARY_TEXT: string = '#1D2129';
    static readonly SECONDARY_TEXT: string = '#86909C';
    static readonly BORDER: string = '#E5E6EB';
    static readonly SURFACE: string = '#F7F8FA';
    static readonly DARK_PAGE_BG: string = '#101214';
    static readonly DARK_CARD_BG: string = '#171A1F';
    static readonly DARK_SURFACE: string = '#1F2329';
    static readonly DARK_PRIMARY_TEXT: string = '#F2F3F5';
    static readonly DARK_SECONDARY_TEXT: string = '#C9CDD4';
    static readonly COURSE_COLORS: string[] = [
        '#1677FF', '#FF7D00', '#00B42A', '#722ED1',
        '#F53F3F', '#14C9C9', '#F7BA1E', '#F5A94B'
    ];
}
export class AppData {
    static readonly quickEntries: QuickEntry[] = [
        { id: 'notice', title: '校园公告', icon: '📢' },
        { id: 'schedule', title: '课程表', icon: '📅' },
        { id: 'grade', title: '成绩查询', icon: '📊' },
        { id: 'lost', title: '失物招领', icon: '🎒' },
        { id: 'map', title: '校园地图', icon: '📍' },
        { id: 'library', title: '图书馆', icon: '📚' },
        { id: 'food', title: '校园美食', icon: '🍜' },
        { id: 'music', title: '音乐播放', icon: '🎵' },
        { id: 'todo', title: '待办提醒', icon: '✅' },
        { id: 'more', title: '更多功能', icon: '🔧' }
    ];
    static readonly notices: NoticeItem[] = [
        {
            id: 'n1',
            title: '期末考试安排公布',
            summary: '教务处已发布 2026 学年春季学期期末考试安排，请及时查看考场信息。',
            content: '各位同学：\n\n2026学年春季学期期末考试安排已公布，请登录教务系统查看详细考场信息。\n\n考试时间：2026年7月10日-7月22日\n考试地点：各教学楼教室\n\n注意事项：\n1. 请携带学生证、身份证参加考试\n2. 提前30分钟到达考场\n3. 严禁携带手机等电子设备进入考场\n\n教务处\n2026年7月3日',
            time: '今天 09:30',
            category: '学校通知',
            favorite: false
        },
        {
            id: 'n2',
            title: '校园创新大赛报名开启',
            summary: '面向全校学生开放报名，提交项目简介后即可参加初赛评审。',
            content: '为培养学生创新精神和实践能力，学校决定举办第十届校园创新大赛。\n\n报名时间：2026年7月1日-7月15日\n报名方式：线上提交项目简介\n参赛对象：全校本科生、研究生\n\n奖项设置：\n- 一等奖：3名，奖金5000元\n- 二等奖：6名，奖金3000元\n- 三等奖：10名，奖金1000元\n\n欢迎同学们积极参与！\n\n校团委\n2026年7月1日',
            time: '昨天 16:10',
            category: '社团活动',
            favorite: false
        },
        {
            id: 'n3',
            title: '图书馆暑期开放时间调整',
            summary: '暑期图书馆开放时间调整为 08:30-21:00，请合理安排借阅计划。',
            content: '各位读者：\n\n根据学校暑期工作安排，图书馆开放时间调整如下：\n\n开放时间：08:30-21:00\n开放区域：\n- 一层：自习区、借阅处\n- 二层：文学借阅区\n- 三层：科技借阅区\n\n注意事项：\n1. 进入图书馆请携带校园卡\n2. 保持安静，文明借阅\n3. 暑期闭馆时间：8月1日-8月10日\n\n图书馆\n2026年6月30日',
            time: '06-30 14:20',
            category: '学校通知',
            favorite: false
        },
        {
            id: 'n4',
            title: '学术讲座：人工智能前沿技术',
            summary: '特邀清华大学张教授来校作学术报告，欢迎广大师生参加。',
            content: '学术讲座通知\n\n主题：人工智能前沿技术与应用\n主讲人：清华大学 张明教授\n时间：2026年7月8日 14:00-16:00\n地点：学术报告厅\n\n讲座内容：\n1. 大语言模型最新进展\n2. AI在教育领域的应用\n3. 未来技术发展趋势\n\n欢迎广大师生参加！\n\n计算机学院\n2026年6月28日',
            time: '06-28 10:00',
            category: '学术讲座',
            favorite: false
        },
        {
            id: 'n5',
            title: '校园文化节即将开幕',
            summary: '第二十届校园文化节将于7月10日开幕，精彩活动等你来参与。',
            content: '第二十届校园文化节即将开幕！\n\n时间：2026年7月10日-7月20日\n地点：校园文化广场\n\n活动安排：\n- 开幕式文艺晚会：7月10日 19:00\n- 社团招新展示：7月11日-12日\n- 校园歌手大赛：7月15日\n- 书法绘画展览：7月10日-20日\n\n欢迎同学们积极参与！\n\n学生会\n2026年6月25日',
            time: '06-25 09:00',
            category: '社团活动',
            favorite: false
        }
    ];
    static readonly courses: CourseItem[] = [
        {
            id: 'c1',
            title: '移动开发技术',
            teacher: '姜老师',
            location: '信工楼 A302',
            weekday: 1,
            timeRange: '10:00-11:35',
            startSection: 3,
            endSection: 4,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 3,
            color: AppTheme.COURSE_COLORS[0]
        },
        {
            id: 'c2',
            title: '数据库原理',
            teacher: '陈老师',
            location: '博学楼 B105',
            weekday: 1,
            timeRange: '14:30-16:05',
            startSection: 6,
            endSection: 7,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 3,
            color: AppTheme.COURSE_COLORS[1]
        },
        {
            id: 'c3',
            title: '操作系统',
            teacher: '李老师',
            location: '信工楼 A201',
            weekday: 2,
            timeRange: '08:00-09:35',
            startSection: 1,
            endSection: 2,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 4,
            color: AppTheme.COURSE_COLORS[2]
        },
        {
            id: 'c4',
            title: '计算机网络',
            teacher: '王老师',
            location: '博学楼 C203',
            weekday: 2,
            timeRange: '10:00-11:35',
            startSection: 3,
            endSection: 4,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 3,
            color: AppTheme.COURSE_COLORS[3]
        },
        {
            id: 'c5',
            title: '数据结构',
            teacher: '赵老师',
            location: '信工楼 B301',
            weekday: 3,
            timeRange: '08:00-09:35',
            startSection: 1,
            endSection: 2,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 4,
            color: AppTheme.COURSE_COLORS[4]
        },
        {
            id: 'c6',
            title: '软件工程',
            teacher: '孙老师',
            location: '博学楼 A402',
            weekday: 3,
            timeRange: '14:30-16:05',
            startSection: 6,
            endSection: 7,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 3,
            color: AppTheme.COURSE_COLORS[5]
        },
        {
            id: 'c7',
            title: '大学英语',
            teacher: '刘老师',
            location: '外语楼 201',
            weekday: 4,
            timeRange: '10:00-11:35',
            startSection: 3,
            endSection: 4,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 2,
            color: AppTheme.COURSE_COLORS[6]
        },
        {
            id: 'c8',
            title: '高等数学',
            teacher: '周老师',
            location: '数学楼 102',
            weekday: 5,
            timeRange: '08:00-09:35',
            startSection: 1,
            endSection: 2,
            weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
            credit: 4,
            color: AppTheme.COURSE_COLORS[7]
        }
    ];
    static readonly todos: TodoItem[] = [
        { id: 't1', title: '完成 HarmonyOS 课程实验', category: '学习', finished: false, remindTime: '今天 20:00' },
        { id: 't2', title: '领取校园卡', category: '生活', finished: false, remindTime: '明天 10:00' },
        { id: 't3', title: '整理答辩 PPT', category: '学习', finished: true },
        { id: 't4', title: '图书馆还书', category: '生活', finished: false, remindTime: '后天 17:00' },
        { id: 't5', title: '社团活动报名', category: '其他', finished: true }
    ];
    static readonly serviceCards: ServiceCard[] = [
        { id: 'lost', title: '失物招领', subtitle: '发布与检索校园失物信息', accentColor: AppTheme.WARN_ORANGE },
        { id: 'food', title: '校园美食', subtitle: '收藏食堂与校内热门美食', accentColor: AppTheme.BRAND_BLUE },
        { id: 'music', title: '音乐播放', subtitle: '读取本地音频并控制播放进度', accentColor: AppTheme.SUCCESS_GREEN },
        { id: 'tools', title: '校园工具', subtitle: '计算器、倒计时、快递查询', accentColor: AppTheme.BRAND_BLUE }
    ];
    static readonly settings: SettingItem[] = [
        { id: 'notify', title: '通知设置', value: '课程 / 公告 / 待办', type: 'navigate' },
        { id: 'cache', title: '清理缓存', value: '12.6 MB', type: 'action' },
        { id: 'about', title: '关于我们', value: 'V1.0.0', type: 'navigate' }
    ];
    static readonly grades: GradeItem[] = [
        { id: 'g1', courseName: '移动开发技术', score: 92, gpa: 4.2, examTime: '2025-12-20', semester: '2025秋' },
        { id: 'g2', courseName: '数据库原理', score: 88, gpa: 3.9, examTime: '2025-12-22', semester: '2025秋' },
        { id: 'g3', courseName: '操作系统', score: 90, gpa: 4.0, examTime: '2025-12-18', semester: '2025秋' },
        { id: 'g4', courseName: '计算机网络', score: 85, gpa: 3.7, examTime: '2025-12-25', semester: '2025秋' },
        { id: 'g5', courseName: '数据结构', score: 94, gpa: 4.5, examTime: '2025-12-15', semester: '2025秋' },
        { id: 'g6', courseName: '软件工程', score: 87, gpa: 3.8, examTime: '2025-12-28', semester: '2025秋' }
    ];
    static readonly books: BookItem[] = [
        {
            id: 'b1',
            title: '鸿蒙应用开发实战',
            author: '张荣超',
            isbn: '9787115598761',
            publisher: '人民邮电出版社',
            location: '图书馆 3 层 A区',
            remainCount: 4,
            coverColor: '#1677FF',
            favorite: false
        },
        {
            id: 'b2',
            title: '计算机网络',
            author: '谢希仁',
            isbn: '9787115592216',
            publisher: '人民邮电出版社',
            location: '图书馆 2 层 B区',
            remainCount: 2,
            coverColor: '#FF7D00',
            favorite: false
        },
        {
            id: 'b3',
            title: '数据结构与算法分析',
            author: 'Mark Allen Weiss',
            isbn: '9787111571513',
            publisher: '机械工业出版社',
            location: '图书馆 2 层 A区',
            remainCount: 3,
            coverColor: '#00B42A',
            favorite: false
        },
        {
            id: 'b4',
            title: '操作系统概念',
            author: 'Abraham Silberschatz',
            isbn: '9787111604365',
            publisher: '机械工业出版社',
            location: '图书馆 3 层 B区',
            remainCount: 1,
            coverColor: '#722ED1',
            favorite: false
        },
        {
            id: 'b5',
            title: '深入理解计算机系统',
            author: 'Randal E. Bryant',
            isbn: '9787111544937',
            publisher: '机械工业出版社',
            location: '图书馆 2 层 C区',
            remainCount: 0,
            coverColor: '#F53F3F',
            favorite: false
        }
    ];
    static readonly lostFoundItems: LostFoundItem[] = [
        {
            id: 'lf1',
            type: 'lost',
            itemName: '校园卡',
            location: '第一食堂',
            time: '今天 12:30',
            description: '蓝色卡套，上面有钥匙扣，姓名张同学',
            contact: '138****8888',
            category: '校园卡'
        },
        {
            id: 'lf2',
            type: 'found',
            itemName: '苹果耳机',
            location: '图书馆二楼',
            time: '今天 10:00',
            description: '白色AirPods Pro，充电盒有划痕',
            contact: '139****6666',
            category: '电子产品'
        },
        {
            id: 'lf3',
            type: 'lost',
            itemName: '黑色书包',
            location: '教学楼A座',
            time: '昨天 16:00',
            description: 'Nike黑色双肩包，内有课本和笔记本',
            contact: '137****5555',
            category: '书包'
        },
        {
            id: 'lf4',
            type: 'found',
            itemName: '水杯',
            location: '操场',
            time: '昨天 18:30',
            description: '膳魔师保温杯，粉色',
            contact: '136****4444',
            category: '其他'
        },
        {
            id: 'lf5',
            type: 'lost',
            itemName: 'U盘',
            location: '实验室',
            time: '06-30 15:00',
            description: '金士顿32G U盘，蓝色',
            contact: '135****3333',
            category: '电子产品'
        }
    ];
    static readonly foods: FoodItem[] = [
        {
            id: 'f1',
            name: '黄焖鸡米饭',
            shop: '第一食堂 二楼',
            location: '第一食堂',
            rating: 4.5,
            specialDish: '黄焖鸡 + 米饭',
            imageColor: '#FF7D00',
            favorite: false
        },
        {
            id: 'f2',
            name: '兰州拉面',
            shop: '第二食堂 一楼',
            location: '第二食堂',
            rating: 4.3,
            specialDish: '牛肉拉面',
            imageColor: '#F5A94B',
            favorite: false
        },
        {
            id: 'f3',
            name: '麻辣香锅',
            shop: '第一食堂 三楼',
            location: '第一食堂',
            rating: 4.7,
            specialDish: '自选麻辣香锅',
            imageColor: '#F53F3F',
            favorite: false
        },
        {
            id: 'f4',
            name: '沙县小吃',
            shop: '校园南门',
            location: '校外周边',
            rating: 4.2,
            specialDish: '蒸饺 + 拌面',
            imageColor: '#00B42A',
            favorite: false
        },
        {
            id: 'f5',
            name: '蜜雪冰城',
            shop: '商业街',
            location: '校外周边',
            rating: 4.6,
            specialDish: '雪王大圣代',
            imageColor: '#F7BA1E',
            favorite: false
        },
        {
            id: 'f6',
            name: '煎饼果子',
            shop: '早餐部',
            location: '第一食堂',
            rating: 4.4,
            specialDish: '鸡蛋煎饼 + 豆浆',
            imageColor: '#14C9C9',
            favorite: false
        }
    ];
    static readonly musics: MusicItem[] = [
        { id: 'm1', title: '晴天', artist: '周杰伦', album: '叶惠美', duration: '04:29', filePath: '' },
        { id: 'm2', title: '稻香', artist: '周杰伦', album: '魔杰座', duration: '03:43', filePath: '' },
        { id: 'm3', title: '夜曲', artist: '周杰伦', album: '十一月的萧邦', duration: '03:48', filePath: '' },
        { id: 'm4', title: '青花瓷', artist: '周杰伦', album: '我很忙', duration: '03:58', filePath: '' },
        { id: 'm5', title: '七里香', artist: '周杰伦', album: '七里香', duration: '04:59', filePath: '' }
    ];
    static readonly campusBuildings: CampusBuilding[] = [
        { id: 'b1', name: '教学楼A座', description: '主要教学楼，共5层，含多媒体教室', location: '校园中心', x: 30, y: 30 },
        { id: 'b2', name: '教学楼B座', description: '计算机学院专用教学楼', location: '校园东区', x: 60, y: 25 },
        { id: 'b3', name: '图书馆', description: '校图书馆，藏书100万册，共6层', location: '校园南区', x: 45, y: 55 },
        { id: 'b4', name: '第一食堂', description: '学生第一食堂，三层楼', location: '校园西区', x: 15, y: 45 },
        { id: 'b5', name: '第二食堂', description: '学生第二食堂，含清真窗口', location: '校园北区', x: 50, y: 15 },
        { id: 'b6', name: '学生宿舍1号楼', description: '男生宿舍楼', location: '校园西北区', x: 10, y: 20 },
        { id: 'b7', name: '学生宿舍2号楼', description: '女生宿舍楼', location: '校园东北区', x: 70, y: 20 },
        { id: 'b8', name: '操场', description: '标准400米田径场', location: '校园东南区', x: 75, y: 60 },
        { id: 'b9', name: '体育馆', description: '室内体育馆，含篮球场、羽毛球馆', location: '校园南区', x: 20, y: 65 },
        { id: 'b10', name: '行政楼', description: '学校行政办公楼', location: '校园正门', x: 45, y: 10 }
    ];
    static readonly weatherForecast: WeatherItem[] = [
        { date: '今天', temperature: '25℃~32℃', weather: '晴', wind: '微风 2级', icon: '☀️' },
        { date: '明天', temperature: '24℃~31℃', weather: '多云', wind: '东南风 3级', icon: '⛅' },
        { date: '后天', temperature: '22℃~28℃', weather: '小雨', wind: '东风 3级', icon: '🌧️' }
    ];
    static readonly weekdays: string[] = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    static readonly sections: CourseSection[] = [
        { start: '08:00', end: '08:45' },
        { start: '08:55', end: '09:40' },
        { start: '10:00', end: '10:45' },
        { start: '10:55', end: '11:40' },
        { start: '14:00', end: '14:45' },
        { start: '14:55', end: '15:40' },
        { start: '16:00', end: '16:45' },
        { start: '16:55', end: '17:40' },
        { start: '19:00', end: '19:45' },
        { start: '19:55', end: '20:40' }
    ];
}
export class AppState {
    private static instance: AppState | null = null;
    static getInstance(): AppState {
        if (!AppState.instance) {
            AppState.instance = new AppState();
        }
        return AppState.instance;
    }
    static generateId(): string {
        return Date.now().toString(36) + Math.random().toString(36).substring(2, 11);
    }
}
