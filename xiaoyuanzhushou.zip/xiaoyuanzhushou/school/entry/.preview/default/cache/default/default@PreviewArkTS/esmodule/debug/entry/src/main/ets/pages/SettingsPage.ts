if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SettingsPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onBack?: () => void;
    courseReminder?: boolean;
    noticeReminder?: boolean;
    todoReminder?: boolean;
    cacheSize?: string;
    showClearDialog?: boolean;
    showAboutDialog?: boolean;
    showToast?: boolean;
    toastMessage?: string;
    toastTimer?: number;
    fontOptions?: FontOption[];
}
import { PageHeader } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import { PrefKeys, PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
interface FontOption {
    label: string;
    value: number;
}
export class SettingsPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleTwoWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleTwoWayPU(params.fontScale, this, "fontScale");
        this.onBack = undefined;
        this.__courseReminder = new ObservedPropertySimplePU(true, this, "courseReminder");
        this.__noticeReminder = new ObservedPropertySimplePU(true, this, "noticeReminder");
        this.__todoReminder = new ObservedPropertySimplePU(true, this, "todoReminder");
        this.__cacheSize = new ObservedPropertySimplePU('12.6 MB', this, "cacheSize");
        this.__showClearDialog = new ObservedPropertySimplePU(false, this, "showClearDialog");
        this.__showAboutDialog = new ObservedPropertySimplePU(false, this, "showAboutDialog");
        this.__showToast = new ObservedPropertySimplePU(false, this, "showToast");
        this.__toastMessage = new ObservedPropertySimplePU('', this, "toastMessage");
        this.toastTimer = -1;
        this.fontOptions = [
            { label: '小', value: 0.9 },
            { label: '中', value: 1.0 },
            { label: '大', value: 1.15 }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SettingsPage_Params) {
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.courseReminder !== undefined) {
            this.courseReminder = params.courseReminder;
        }
        if (params.noticeReminder !== undefined) {
            this.noticeReminder = params.noticeReminder;
        }
        if (params.todoReminder !== undefined) {
            this.todoReminder = params.todoReminder;
        }
        if (params.cacheSize !== undefined) {
            this.cacheSize = params.cacheSize;
        }
        if (params.showClearDialog !== undefined) {
            this.showClearDialog = params.showClearDialog;
        }
        if (params.showAboutDialog !== undefined) {
            this.showAboutDialog = params.showAboutDialog;
        }
        if (params.showToast !== undefined) {
            this.showToast = params.showToast;
        }
        if (params.toastMessage !== undefined) {
            this.toastMessage = params.toastMessage;
        }
        if (params.toastTimer !== undefined) {
            this.toastTimer = params.toastTimer;
        }
        if (params.fontOptions !== undefined) {
            this.fontOptions = params.fontOptions;
        }
    }
    updateStateVars(params: SettingsPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__courseReminder.purgeDependencyOnElmtId(rmElmtId);
        this.__noticeReminder.purgeDependencyOnElmtId(rmElmtId);
        this.__todoReminder.purgeDependencyOnElmtId(rmElmtId);
        this.__cacheSize.purgeDependencyOnElmtId(rmElmtId);
        this.__showClearDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__showAboutDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__showToast.purgeDependencyOnElmtId(rmElmtId);
        this.__toastMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__courseReminder.aboutToBeDeleted();
        this.__noticeReminder.aboutToBeDeleted();
        this.__todoReminder.aboutToBeDeleted();
        this.__cacheSize.aboutToBeDeleted();
        this.__showClearDialog.aboutToBeDeleted();
        this.__showAboutDialog.aboutToBeDeleted();
        this.__showToast.aboutToBeDeleted();
        this.__toastMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleTwoWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleTwoWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onBack?: () => void;
    private __courseReminder: ObservedPropertySimplePU<boolean>;
    get courseReminder() {
        return this.__courseReminder.get();
    }
    set courseReminder(newValue: boolean) {
        this.__courseReminder.set(newValue);
    }
    private __noticeReminder: ObservedPropertySimplePU<boolean>;
    get noticeReminder() {
        return this.__noticeReminder.get();
    }
    set noticeReminder(newValue: boolean) {
        this.__noticeReminder.set(newValue);
    }
    private __todoReminder: ObservedPropertySimplePU<boolean>;
    get todoReminder() {
        return this.__todoReminder.get();
    }
    set todoReminder(newValue: boolean) {
        this.__todoReminder.set(newValue);
    }
    private __cacheSize: ObservedPropertySimplePU<string>;
    get cacheSize() {
        return this.__cacheSize.get();
    }
    set cacheSize(newValue: string) {
        this.__cacheSize.set(newValue);
    }
    private __showClearDialog: ObservedPropertySimplePU<boolean>;
    get showClearDialog() {
        return this.__showClearDialog.get();
    }
    set showClearDialog(newValue: boolean) {
        this.__showClearDialog.set(newValue);
    }
    private __showAboutDialog: ObservedPropertySimplePU<boolean>;
    get showAboutDialog() {
        return this.__showAboutDialog.get();
    }
    set showAboutDialog(newValue: boolean) {
        this.__showAboutDialog.set(newValue);
    }
    private __showToast: ObservedPropertySimplePU<boolean>;
    get showToast() {
        return this.__showToast.get();
    }
    set showToast(newValue: boolean) {
        this.__showToast.set(newValue);
    }
    private __toastMessage: ObservedPropertySimplePU<string>;
    get toastMessage() {
        return this.__toastMessage.get();
    }
    set toastMessage(newValue: string) {
        this.__toastMessage.set(newValue);
    }
    private toastTimer: number;
    private fontOptions: FontOption[];
    aboutToAppear() {
        this.loadSettings();
    }
    aboutToDisappear() {
        if (this.toastTimer !== -1) {
            clearTimeout(this.toastTimer);
            this.toastTimer = -1;
        }
    }
    private async loadSettings() {
        this.courseReminder = await PreferencesStore.getBoolean(PrefKeys.SETTING_COURSE_REMINDER, true);
        this.noticeReminder = await PreferencesStore.getBoolean(PrefKeys.SETTING_NOTICE_REMINDER, true);
        this.todoReminder = await PreferencesStore.getBoolean(PrefKeys.SETTING_TODO_REMINDER, true);
    }
    private async onDarkModeChange(value: boolean) {
        this.darkMode = value;
        await PreferencesStore.setBoolean(PrefKeys.SETTING_DARK_MODE, value);
    }
    private async onFontScaleChange(value: number) {
        this.fontScale = value;
        await PreferencesStore.setNumber(PrefKeys.SETTING_FONT_SCALE, value);
    }
    private async onCourseReminderChange(value: boolean) {
        this.courseReminder = value;
        await PreferencesStore.setBoolean(PrefKeys.SETTING_COURSE_REMINDER, value);
    }
    private async onNoticeReminderChange(value: boolean) {
        this.noticeReminder = value;
        await PreferencesStore.setBoolean(PrefKeys.SETTING_NOTICE_REMINDER, value);
    }
    private async onTodoReminderChange(value: boolean) {
        this.todoReminder = value;
        await PreferencesStore.setBoolean(PrefKeys.SETTING_TODO_REMINDER, value);
    }
    private showToastMessage(message: string) {
        this.toastMessage = message;
        this.showToast = true;
        if (this.toastTimer !== -1) {
            clearTimeout(this.toastTimer);
        }
        this.toastTimer = setTimeout(() => {
            this.showToast = false;
            this.toastTimer = -1;
        }, 2000);
    }
    private clearCache() {
        this.cacheSize = '0 MB';
        this.showClearDialog = false;
        this.showToastMessage('清理完成');
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/SettingsPage.ets(93:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.alignContent(Alignment.Center);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(94:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '设置',
                        onBack: this.onBack
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/SettingsPage.ets", line: 95, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '设置',
                            onBack: this.onBack
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/SettingsPage.ets(102:9)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(103:11)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 16, bottom: 24 });
        }, Column);
        this.buildGeneralSettings.bind(this)();
        this.buildNotificationSettings.bind(this)();
        this.buildOtherSettings.bind(this)();
        Column.pop();
        Scroll.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showClearDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildConfirmDialog.bind(this)('清理缓存', '确定要清理所有缓存数据吗？', () => { this.clearCache(); }, () => { this.showClearDialog = false; });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showAboutDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildAboutDialog.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showToast) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.toastMessage);
                        Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(132:9)", "entry");
                        Text.fontSize(14 * this.fontScale);
                        Text.fontColor(Color.White);
                        Text.padding({ left: 20, right: 20, top: 12, bottom: 12 });
                        Text.backgroundColor('rgba(0, 0, 0, 0.7)');
                        Text.borderRadius(8);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildGeneralSettings(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(147:5)", "entry");
            Column.width('100%');
        }, Column);
        this.buildSectionTitle.bind(this)('通用设置');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 0 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(149:7)", "entry");
            Column.width('100%');
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(12);
            Column.padding(16);
        }, Column);
        this.buildToggleRow.bind(this)('深色模式', this.darkMode, (value: boolean) => {
            this.onDarkModeChange(value);
        });
        this.buildDivider.bind(this)();
        this.buildFontSizeRow.bind(this)();
        Column.pop();
        Column.pop();
    }
    private buildNotificationSettings(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(166:5)", "entry");
            Column.width('100%');
        }, Column);
        this.buildSectionTitle.bind(this)('通知设置');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 0 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(168:7)", "entry");
            Column.width('100%');
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(12);
            Column.padding(16);
        }, Column);
        this.buildToggleRow.bind(this)('课程提醒', this.courseReminder, (value: boolean) => {
            this.onCourseReminderChange(value);
        });
        this.buildDivider.bind(this)();
        this.buildToggleRow.bind(this)('公告提醒', this.noticeReminder, (value: boolean) => {
            this.onNoticeReminderChange(value);
        });
        this.buildDivider.bind(this)();
        this.buildToggleRow.bind(this)('待办提醒', this.todoReminder, (value: boolean) => {
            this.onTodoReminderChange(value);
        });
        Column.pop();
        Column.pop();
    }
    private buildOtherSettings(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(191:5)", "entry");
            Column.width('100%');
        }, Column);
        this.buildSectionTitle.bind(this)('其他');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 0 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(193:7)", "entry");
            Column.width('100%');
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(12);
            Column.padding(16);
        }, Column);
        this.buildCacheRow.bind(this)();
        this.buildDivider.bind(this)();
        this.buildAboutRow.bind(this)();
        Column.pop();
        Column.pop();
    }
    private buildSectionTitle(title: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(208:5)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.width('100%');
            Text.padding({ left: 4 });
        }, Text);
        Text.pop();
    }
    private buildToggleRow(title: string, value: boolean, onChange: (value: boolean) => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(217:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(218:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/SettingsPage.ets(221:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: value });
            Toggle.debugLine("entry/src/main/ets/pages/SettingsPage.ets(222:7)", "entry");
            Toggle.onChange((isOn: boolean) => {
                onChange(isOn);
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
    }
    private buildFontSizeRow(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(233:5)", "entry");
            Column.width('100%');
            Column.padding({ top: 8, bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(234:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('字体大小');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(235:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/SettingsPage.ets(238:9)", "entry");
        }, Blank);
        Blank.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(242:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Radio.create({ value: item.label, group: 'fontSize' });
                    Radio.debugLine("entry/src/main/ets/pages/SettingsPage.ets(244:11)", "entry");
                    Radio.checked(this.fontScale === item.value);
                    Radio.onChange((isChecked: boolean) => {
                        if (isChecked) {
                            this.onFontScaleChange(item.value);
                        }
                    });
                }, Radio);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.label);
                    Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(251:11)", "entry");
                    Text.fontSize(14 * this.fontScale);
                    Text.fontColor(this.primaryText());
                    Text.margin({ left: 6, right: 16 });
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.fontOptions, forEachItemGenFunction, (item: FontOption) => item.label, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Column.pop();
    }
    private buildCacheRow(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(265:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('清理缓存');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(266:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/SettingsPage.ets(269:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.cacheSize);
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(270:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.margin({ right: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('清理');
            Button.debugLine("entry/src/main/ets/pages/SettingsPage.ets(274:7)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(12 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.height(28);
            Button.padding({ left: 14, right: 14 });
            Button.onClick(() => {
                this.showClearDialog = true;
            });
        }, Button);
        Button.pop();
        Row.pop();
    }
    private buildAboutRow(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(291:5)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
            Row.onClick(() => {
                this.showAboutDialog = true;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('关于我们');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(292:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/SettingsPage.ets(295:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('V1.0.0');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(296:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.margin({ right: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(300:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildDivider(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/SettingsPage.ets(313:5)", "entry");
            Divider.color(this.dividerColor());
            Divider.strokeWidth(1);
            Divider.width('100%');
        }, Divider);
    }
    private buildConfirmDialog(title: string, message: string, onConfirm: () => void, onCancel: () => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/SettingsPage.ets(321:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.alignContent(Alignment.Center);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(322:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0, 0, 0, 0.5)');
            Column.onClick(() => {
                onCancel();
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(331:7)", "entry");
            Column.width(280);
            Column.padding(20);
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(332:9)", "entry");
            Text.fontSize(17 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(message);
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(337:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/SettingsPage.ets(343:9)", "entry");
            Row.width('100%');
            Row.margin({ top: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/SettingsPage.ets(344:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(14 * this.fontScale);
            Button.fontColor(this.primaryText());
            Button.backgroundColor(this.surfaceColor());
            Button.layoutWeight(1);
            Button.height(40);
            Button.onClick(() => {
                onCancel();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('确定');
            Button.debugLine("entry/src/main/ets/pages/SettingsPage.ets(355:11)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(14 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.layoutWeight(1);
            Button.height(40);
            Button.onClick(() => {
                onConfirm();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
        Stack.pop();
    }
    private buildAboutDialog(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/SettingsPage.ets(381:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.alignContent(Alignment.Center);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(382:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0, 0, 0, 0.5)');
            Column.onClick(() => {
                this.showAboutDialog = false;
            });
        }, Column);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(391:7)", "entry");
            Column.width(280);
            Column.padding(20);
            Column.backgroundColor(this.cardBackground());
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🎓');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(392:9)", "entry");
            Text.fontSize(48);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('高校校园助手');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(395:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('V1.0.0');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(400:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/SettingsPage.ets(404:9)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Center);
            Column.margin({ top: 8, bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('一款专为大学生打造的校园生活助手');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(405:11)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('课程表 · 成绩查询 · 校园公告');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(408:11)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('失物招领 · 图书馆 · 美食推荐');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(411:11)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('© 2026 高校校园助手');
            Text.debugLine("entry/src/main/ets/pages/SettingsPage.ets(419:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('我知道了');
            Button.debugLine("entry/src/main/ets/pages/SettingsPage.ets(423:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(14 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.width('100%');
            Button.height(40);
            Button.margin({ top: 8 });
            Button.onClick(() => {
                this.showAboutDialog = false;
            });
        }, Button);
        Button.pop();
        Column.pop();
        Stack.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    private dividerColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.BORDER;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
