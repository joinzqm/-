if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FavoritesPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    noticeList?: NoticeItem[];
    bookList?: BookItem[];
    foodList?: FoodItem[];
    onBack?: () => void;
    currentCategory?: string;
    categories?: string[];
}
import { PageHeader, TagButton, StarRating } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { NoticeItem, BookItem, FoodItem } from '../model/AppModels';
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
interface FavoriteItem {
    type: 'notice' | 'book' | 'food';
    data: NoticeItem | BookItem | FoodItem;
}
export class FavoritesPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__noticeList = new SynchedPropertyObjectOneWayPU(params.noticeList, this, "noticeList");
        this.__bookList = new SynchedPropertyObjectOneWayPU(params.bookList, this, "bookList");
        this.__foodList = new SynchedPropertyObjectOneWayPU(params.foodList, this, "foodList");
        this.onBack = undefined;
        this.__currentCategory = new ObservedPropertySimplePU('全部', this, "currentCategory");
        this.categories = ['全部', '公告', '图书', '美食'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FavoritesPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.noticeList === undefined) {
            this.__noticeList.set([]);
        }
        if (params.bookList === undefined) {
            this.__bookList.set([]);
        }
        if (params.foodList === undefined) {
            this.__foodList.set([]);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.currentCategory !== undefined) {
            this.currentCategory = params.currentCategory;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
    }
    updateStateVars(params: FavoritesPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__noticeList.reset(params.noticeList);
        this.__bookList.reset(params.bookList);
        this.__foodList.reset(params.foodList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__noticeList.purgeDependencyOnElmtId(rmElmtId);
        this.__bookList.purgeDependencyOnElmtId(rmElmtId);
        this.__foodList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentCategory.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__noticeList.aboutToBeDeleted();
        this.__bookList.aboutToBeDeleted();
        this.__foodList.aboutToBeDeleted();
        this.__currentCategory.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __noticeList: SynchedPropertySimpleOneWayPU<NoticeItem[]>;
    get noticeList() {
        return this.__noticeList.get();
    }
    set noticeList(newValue: NoticeItem[]) {
        this.__noticeList.set(newValue);
    }
    private __bookList: SynchedPropertySimpleOneWayPU<BookItem[]>;
    get bookList() {
        return this.__bookList.get();
    }
    set bookList(newValue: BookItem[]) {
        this.__bookList.set(newValue);
    }
    private __foodList: SynchedPropertySimpleOneWayPU<FoodItem[]>;
    get foodList() {
        return this.__foodList.get();
    }
    set foodList(newValue: FoodItem[]) {
        this.__foodList.set(newValue);
    }
    private onBack?: () => void;
    private __currentCategory: ObservedPropertySimplePU<string>;
    get currentCategory() {
        return this.__currentCategory.get();
    }
    set currentCategory(newValue: string) {
        this.__currentCategory.set(newValue);
    }
    private categories: string[];
    private getFavorites(): FavoriteItem[] {
        const result: FavoriteItem[] = [];
        if (this.currentCategory === '全部' || this.currentCategory === '公告') {
            this.noticeList
                .filter((item: NoticeItem) => item.favorite)
                .forEach((item: NoticeItem) => {
                result.push({ type: 'notice', data: item });
            });
        }
        if (this.currentCategory === '全部' || this.currentCategory === '图书') {
            this.bookList
                .filter((item: BookItem) => item.favorite)
                .forEach((item: BookItem) => {
                result.push({ type: 'book', data: item });
            });
        }
        if (this.currentCategory === '全部' || this.currentCategory === '美食') {
            this.foodList
                .filter((item: FoodItem) => item.favorite)
                .forEach((item: FoodItem) => {
                result.push({ type: 'food', data: item });
            });
        }
        return result;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(54:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '我的收藏',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FavoritesPage.ets", line: 55, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '我的收藏',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(66:7)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.padding({ left: 16, right: 16, top: 12, bottom: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.Start });
            Flex.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(67:9)", "entry");
            Flex.width('100%');
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: category,
                                active: this.currentCategory === category,
                                onTap: () => {
                                    this.currentCategory = category;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FavoritesPage.ets", line: 69, col: 13 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: category,
                                    active: this.currentCategory === category,
                                    onTap: () => {
                                        this.currentCategory = category;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (category: string) => category, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.getFavorites().length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(83:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(85:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        If.create();
                                        if (item.type === 'notice') {
                                            this.ifElseBranchUpdateFunction(0, () => {
                                                this.buildNoticeItem.bind(this)(item.data as NoticeItem);
                                            });
                                        }
                                        else if (item.type === 'book') {
                                            this.ifElseBranchUpdateFunction(1, () => {
                                                this.buildBookItem.bind(this)(item.data as BookItem);
                                            });
                                        }
                                        else {
                                            this.ifElseBranchUpdateFunction(2, () => {
                                                this.buildFoodItem.bind(this)(item.data as FoodItem);
                                            });
                                        }
                                    }, If);
                                    If.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.getFavorites(), forEachItemGenFunction, (item: FavoriteItem) => `${item.type}_${item.data.id}`, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.buildEmptyView.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Column.pop();
    }
    private buildNoticeItem(item: NoticeItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(114:5)", "entry");
            Column.width('100%');
            Column.padding(12);
            Column.backgroundColor(this.cardColor());
            Column.borderRadius(12);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(115:7)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📢');
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(116:9)", "entry");
            Text.fontSize(16 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.category);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(119:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
            Text.backgroundColor(this.darkMode ? 'rgba(22,119,255,0.15)' : 'rgba(22,119,255,0.1)');
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(126:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.time);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(128:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(134:7)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.summary);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(142:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.width('100%');
            Text.lineHeight(18);
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildBookItem(item: BookItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(158:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor(this.cardColor());
            Row.borderRadius(12);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(159:7)", "entry");
            Column.width(56);
            Column.height(72);
            Column.backgroundColor(item.coverColor);
            Column.borderRadius(8);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title.charAt(0));
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(160:9)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(171:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(172:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.author);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(178:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.location);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(183:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(192:7)", "entry");
            Column.alignItems(HorizontalAlign.End);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📚');
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(193:9)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`剩余 ${item.remainCount} 本`);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(196:9)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(item.remainCount > 0 ? AppTheme.SUCCESS_GREEN : AppTheme.WARN_ORANGE);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildFoodItem(item: FoodItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(211:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor(this.cardColor());
            Row.borderRadius(12);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(212:7)", "entry");
            Column.width(60);
            Column.height(60);
            Column.backgroundColor(item.imageColor);
            Column.borderRadius(10);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.name.charAt(0));
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(213:9)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(224:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.name);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(225:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 6 });
            Row.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(232:9)", "entry");
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new StarRating(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        rating: item.rating,
                        starSize: 12
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FavoritesPage.ets", line: 233, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            rating: item.rating,
                            starSize: 12
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "StarRating" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.rating.toFixed(1));
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(239:11)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 4 });
            Row.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(244:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📍');
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(245:11)", "entry");
            Text.fontSize(11 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.shop);
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(247:11)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    private buildEmptyView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(265:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('⭐');
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(266:7)", "entry");
            Text.fontSize(60);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('暂无收藏');
            Text.debugLine("entry/src/main/ets/pages/FavoritesPage.ets(268:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? '#101214' : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private primaryText(): string {
        return this.darkMode ? '#F2F3F5' : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? '#C9CDD4' : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
