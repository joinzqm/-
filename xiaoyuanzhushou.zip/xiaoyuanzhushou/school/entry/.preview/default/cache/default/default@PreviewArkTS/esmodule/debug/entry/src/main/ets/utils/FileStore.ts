import type common from "@ohos:app.ability.common";
import fs from "@ohos:file.fs";
import buffer from "@ohos:buffer";
export class FileStore {
    private static context: common.UIAbilityContext | null = null;
    private static readonly TODO_FILE: string = 'todos.json';
    private static readonly COURSES_FILE: string = 'courses.json';
    private static readonly GRADES_FILE: string = 'grades.json';
    private static readonly BOOKS_FILE: string = 'books.json';
    private static readonly LOST_FOUND_FILE: string = 'lost_found.json';
    private static readonly FOODS_FILE: string = 'foods.json';
    private static readonly FAVORITES_FILE: string = 'favorites.json';
    static init(context: common.UIAbilityContext): void {
        FileStore.context = context;
    }
    private static getFilePath(fileName: string): string {
        if (!FileStore.context) {
            return '';
        }
        return `${FileStore.context.filesDir}/${fileName}`;
    }
    static async readJSON<T>(fileName: string, defaultValue: T): Promise<T> {
        try {
            const path: string = FileStore.getFilePath(fileName);
            if (!path) {
                return defaultValue;
            }
            try {
                fs.accessSync(path);
            }
            catch (_) {
                return defaultValue;
            }
            const file: fs.File = fs.openSync(path, fs.OpenMode.READ_ONLY);
            try {
                const stat: fs.Stat = fs.statSync(path);
                const arrayBuffer: ArrayBuffer = new ArrayBuffer(stat.size);
                fs.readSync(file.fd, arrayBuffer);
                const content: string = buffer.from(arrayBuffer).toString('utf-8');
                return JSON.parse(content) as T;
            }
            finally {
                fs.closeSync(file.fd);
            }
        }
        catch (e) {
            console.error(`FileStore readJSON error: ${JSON.stringify(e)}`);
            return defaultValue;
        }
    }
    static async writeJSON(fileName: string, data: object): Promise<boolean> {
        try {
            const path: string = FileStore.getFilePath(fileName);
            if (!path) {
                return false;
            }
            const content: string = JSON.stringify(data);
            const file: fs.File = fs.openSync(path, fs.OpenMode.READ_WRITE | fs.OpenMode.CREATE | fs.OpenMode.TRUNC);
            try {
                fs.writeSync(file.fd, content);
            }
            finally {
                fs.closeSync(file.fd);
            }
            return true;
        }
        catch (e) {
            console.error(`FileStore writeJSON error: ${JSON.stringify(e)}`);
            return false;
        }
    }
    static async getTodos<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.TODO_FILE, defaultValue);
    }
    static async saveTodos(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.TODO_FILE, data);
    }
    static async getCourses<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.COURSES_FILE, defaultValue);
    }
    static async saveCourses(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.COURSES_FILE, data);
    }
    static async getGrades<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.GRADES_FILE, defaultValue);
    }
    static async saveGrades(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.GRADES_FILE, data);
    }
    static async getBooks<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.BOOKS_FILE, defaultValue);
    }
    static async saveBooks(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.BOOKS_FILE, data);
    }
    static async getLostFound<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.LOST_FOUND_FILE, defaultValue);
    }
    static async saveLostFound(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.LOST_FOUND_FILE, data);
    }
    static async getFoods<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.FOODS_FILE, defaultValue);
    }
    static async saveFoods(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.FOODS_FILE, data);
    }
    static async getFavorites<T>(defaultValue: T): Promise<T> {
        return FileStore.readJSON(FileStore.FAVORITES_FILE, defaultValue);
    }
    static async saveFavorites(data: object): Promise<boolean> {
        return FileStore.writeJSON(FileStore.FAVORITES_FILE, data);
    }
    static async clearCache(): Promise<void> {
        const files: string[] = [
            FileStore.TODO_FILE,
            FileStore.COURSES_FILE,
            FileStore.GRADES_FILE,
            FileStore.BOOKS_FILE,
            FileStore.LOST_FOUND_FILE,
            FileStore.FOODS_FILE,
            FileStore.FAVORITES_FILE
        ];
        for (let i: number = 0; i < files.length; i++) {
            const fileName: string = files[i];
            try {
                const path: string = FileStore.getFilePath(fileName);
                if (!path) {
                    continue;
                }
                try {
                    fs.accessSync(path);
                }
                catch (_) {
                    continue;
                }
                fs.unlinkSync(path);
            }
            catch (e) {
                console.error(`FileStore clearCache ${fileName} error: ${JSON.stringify(e)}`);
            }
        }
    }
}
