if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ServicePage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onNavigate?: (page: string) => void;
    selectedId?: string;
}
import { CommonCard } from "@bundle:com.campusassistant.app/entry/ets/components/CommonCard";
import type { ServiceCard } from '../model/AppModels';
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class ServicePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onNavigate = undefined;
        this.__selectedId = new ObservedPropertySimplePU('lost', this, "selectedId");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ServicePage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onNavigate !== undefined) {
            this.onNavigate = params.onNavigate;
        }
        if (params.selectedId !== undefined) {
            this.selectedId = params.selectedId;
        }
    }
    updateStateVars(params: ServicePage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedId.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__selectedId.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onNavigate?: (page: string) => void;
    private __selectedId: ObservedPropertySimplePU<string>;
    get selectedId() {
        return this.__selectedId.get();
    }
    set selectedId(newValue: string) {
        this.__selectedId.set(newValue);
    }
    private getServiceIcon(id: string): string {
        switch (id) {
            case 'lost':
                return '🎒';
            case 'food':
                return '🍜';
            case 'music':
                return '🎵';
            case 'tools':
                return '🔧';
            default:
                return '📋';
        }
    }
    private getSelectedService(): ServiceCard | undefined {
        return AppData.serviceCards.find(item => item.id === this.selectedId);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/ServicePage.ets(33:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding({ left: 20, right: 20, top: 18, bottom: 20 });
            Column.backgroundColor(this.pageBackground());
        }, Column);
        this.buildHeader.bind(this)();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.serviceGridBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ServicePage.ets", line: 36, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.serviceGridBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.selectedInfoBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ServicePage.ets", line: 38, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.selectedInfoBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        Column.pop();
    }
    private buildHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/ServicePage.ets(48:5)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('生活服务');
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(49:7)", "entry");
            Text.fontSize(24 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('失物招领、美食推荐、音乐播放与校园工具');
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(53:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private serviceGridBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('模块入口', '四大服务');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/ServicePage.ets(64:5)", "entry");
            Grid.columnsTemplate('1fr 1fr');
            Grid.rowsTemplate('1fr 1fr');
            Grid.columnsGap(12);
            Grid.rowsGap(12);
            Grid.height(280);
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/pages/ServicePage.ets(66:9)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.buildServiceCard.bind(this)(item);
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, AppData.serviceCards, forEachItemGenFunction, (item: ServiceCard) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
    }
    private buildServiceCard(item: ServiceCard, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/ServicePage.ets(80:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(12);
            Column.borderRadius(12);
            Column.backgroundColor(this.surfaceColor());
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
            Column.onClick(() => {
                this.selectedId = item.id;
                if (this.onNavigate) {
                    this.onNavigate(item.id);
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getServiceIcon(item.id));
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(81:7)", "entry");
            Text.fontSize(36);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(84:7)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.subtitle);
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(89:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.textAlign(TextAlign.Center);
            Text.maxLines(2);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
    }
    private getSelectedServiceTitle(): string {
        const service = this.getSelectedService();
        return service ? service.title : '';
    }
    private getSelectedServiceSubtitle(): string {
        const service = this.getSelectedService();
        return service ? service.subtitle : '';
    }
    private getSelectedServiceId(): string {
        const service = this.getSelectedService();
        return service ? service.id : '';
    }
    private hasSelectedService(): boolean {
        return this.getSelectedService() !== undefined;
    }
    private selectedInfoBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.hasSelectedService()) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 12 });
                        Column.debugLine("entry/src/main/ets/pages/ServicePage.ets(133:7)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.buildSectionHeader.bind(this)(this.getSelectedServiceTitle(), '当前选中');
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 16 });
                        Row.debugLine("entry/src/main/ets/pages/ServicePage.ets(135:9)", "entry");
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.getServiceIcon(this.getSelectedServiceId()));
                        Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(136:11)", "entry");
                        Text.fontSize(48);
                        Text.width(72);
                        Text.height(72);
                        Text.textAlign(TextAlign.Center);
                        Text.backgroundColor(this.surfaceColor());
                        Text.borderRadius(12);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 6 });
                        Column.debugLine("entry/src/main/ets/pages/ServicePage.ets(144:11)", "entry");
                        Column.layoutWeight(1);
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.getSelectedServiceTitle());
                        Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(145:13)", "entry");
                        Text.fontSize(18 * this.fontScale);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(this.primaryText());
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.getSelectedServiceSubtitle());
                        Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(150:13)", "entry");
                        Text.fontSize(13 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                        Text.maxLines(2);
                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                    }, Text);
                    Text.pop();
                    Column.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('点击上方卡片或"进入"按钮可打开对应功能页面');
                        Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(161:9)", "entry");
                        Text.fontSize(12 * this.fontScale);
                        Text.fontColor(this.secondaryText());
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding({ top: 8 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    private buildSectionHeader(title: string, action: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ServicePage.ets(174:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(175:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ServicePage.ets(179:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(action);
            Text.debugLine("entry/src/main/ets/pages/ServicePage.ets(180:7)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.BRAND_BLUE);
        }, Text);
        Text.pop();
        Row.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? '#101214' : AppTheme.PAGE_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? '#1F2329' : '#F7F8FA';
    }
    private primaryText(): string {
        return this.darkMode ? '#F2F3F5' : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? '#C9CDD4' : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
