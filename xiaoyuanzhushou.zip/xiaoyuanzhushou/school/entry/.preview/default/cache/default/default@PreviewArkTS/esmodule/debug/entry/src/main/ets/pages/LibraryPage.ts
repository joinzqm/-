if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LibraryPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    bookList?: BookItem[];
    onBack?: () => void;
    onBooksChange?: (list: BookItem[]) => void;
    searchText?: string;
    filteredList?: BookItem[];
}
import { PageHeader, SearchBar } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { BookItem } from '../model/AppModels';
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
export class LibraryPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.__bookList = new SynchedPropertyObjectOneWayPU(params.bookList, this, "bookList");
        this.onBack = undefined;
        this.onBooksChange = undefined;
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__filteredList = new ObservedPropertyObjectPU([], this, "filteredList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LibraryPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.bookList === undefined) {
            this.__bookList.set([]);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.onBooksChange !== undefined) {
            this.onBooksChange = params.onBooksChange;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.filteredList !== undefined) {
            this.filteredList = params.filteredList;
        }
    }
    updateStateVars(params: LibraryPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
        this.__bookList.reset(params.bookList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__bookList.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__filteredList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__bookList.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__filteredList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __bookList: SynchedPropertySimpleOneWayPU<BookItem[]>;
    get bookList() {
        return this.__bookList.get();
    }
    set bookList(newValue: BookItem[]) {
        this.__bookList.set(newValue);
    }
    private onBack?: () => void;
    private onBooksChange?: (list: BookItem[]) => void;
    private __searchText: ObservedPropertySimplePU<string>;
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue: string) {
        this.__searchText.set(newValue);
    }
    private __filteredList: ObservedPropertyObjectPU<BookItem[]>;
    get filteredList() {
        return this.__filteredList.get();
    }
    set filteredList(newValue: BookItem[]) {
        this.__filteredList.set(newValue);
    }
    aboutToAppear() {
        this.filteredList = this.bookList.slice();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(21:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '图书馆检索',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LibraryPage.ets", line: 22, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '图书馆检索',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(33:7)", "entry");
            Column.width('100%');
            Column.layoutWeight(1);
            Column.padding({ left: 16, right: 16, top: 12, bottom: 16 });
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SearchBar(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        placeholder: '搜索书名/作者/ISBN',
                        searchText: this.__searchText,
                        onSearch: () => {
                            this.filterBooks();
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LibraryPage.ets", line: 34, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            placeholder: '搜索书名/作者/ISBN',
                            searchText: this.searchText,
                            onSearch: () => {
                                this.filterBooks();
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "SearchBar" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.filteredList.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/LibraryPage.ets(45:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/LibraryPage.ets(47:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildBookItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.filteredList, forEachItemGenFunction, (item: BookItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.buildEmptyView.bind(this)();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Column.pop();
    }
    private buildBookItem(item: BookItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/LibraryPage.ets(70:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.backgroundColor(this.cardColor());
            Row.borderRadius(12);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(71:7)", "entry");
            Column.width(56);
            Column.height(72);
            Column.backgroundColor(item.coverColor);
            Column.borderRadius(8);
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title.charAt(0));
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(72:9)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(83:7)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(84:9)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.author);
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(90:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.publisher);
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(95:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(104:7)", "entry");
            Column.alignItems(HorizontalAlign.End);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.location);
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(105:9)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`剩余 ${item.remainCount} 本`);
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(109:9)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(item.remainCount > 0 ? AppTheme.SUCCESS_GREEN : AppTheme.WARN_ORANGE);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.favorite ? '♥' : '♡');
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(113:9)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.fontColor(item.favorite ? '#F53F3F' : this.secondaryText());
            Text.textAlign(TextAlign.End);
            Text.onClick(() => {
                this.toggleFavorite(item.id);
            });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private buildEmptyView(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/LibraryPage.ets(131:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📚');
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(132:7)", "entry");
            Text.fontSize(60);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('暂无图书');
            Text.debugLine("entry/src/main/ets/pages/LibraryPage.ets(134:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
    }
    private filterBooks() {
        if (!this.searchText || this.searchText.trim().length === 0) {
            this.filteredList = this.bookList;
        }
        else {
            const keyword = this.searchText.trim().toLowerCase();
            this.filteredList = this.bookList.filter((book: BookItem) => {
                return book.title.toLowerCase().includes(keyword)
                    || book.author.toLowerCase().includes(keyword)
                    || book.isbn.toLowerCase().includes(keyword);
            });
        }
    }
    private toggleFavorite(bookId: string) {
        const index = this.bookList.findIndex((b: BookItem) => b.id === bookId);
        if (index !== -1) {
            this.bookList = this.bookList.map((b: BookItem, i: number) => {
                if (i === index) {
                    const newBook: BookItem = {
                        id: b.id,
                        title: b.title,
                        author: b.author,
                        isbn: b.isbn,
                        publisher: b.publisher,
                        location: b.location,
                        remainCount: b.remainCount,
                        coverColor: b.coverColor,
                        favorite: !b.favorite
                    };
                    return newBook;
                }
                return b;
            });
            this.filterBooks();
            if (this.onBooksChange) {
                this.onBooksChange(this.bookList);
            }
        }
    }
    private pageBackground(): string {
        return this.darkMode ? '#101214' : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private primaryText(): string {
        return this.darkMode ? '#F2F3F5' : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? '#C9CDD4' : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
