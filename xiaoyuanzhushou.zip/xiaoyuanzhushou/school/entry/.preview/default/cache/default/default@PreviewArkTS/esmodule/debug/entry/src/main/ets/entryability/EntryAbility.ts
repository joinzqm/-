import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import UIAbility from "@ohos:app.ability.UIAbility";
import type Want from "@ohos:app.ability.Want";
import type window from "@ohos:window";
import { PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
import { FileStore } from "@bundle:com.campusassistant.app/entry/ets/utils/FileStore";
export default class EntryAbility extends UIAbility {
    onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
        // 在 Ability 创建阶段初始化本地存储，context 即 UIAbilityContext
        PreferencesStore.init(this.context);
        FileStore.init(this.context);
        console.info('Campus assistant ability created.');
    }
    onWindowStageCreate(windowStage: window.WindowStage): void {
        // 设置沉浸式状态栏
        windowStage.getMainWindow().then((mainWindow) => {
            mainWindow.setWindowLayoutFullScreen(true).catch((err: Error) => {
                console.error(`setWindowLayoutFullScreen failed: ${JSON.stringify(err)}`);
            });
        }).catch((err: Error) => {
            console.error(`getMainWindow failed: ${JSON.stringify(err)}`);
        });
        windowStage.loadContent('pages/Index', (err) => {
            if (err.code) {
                console.error(`Failed to load the content. Cause: ${JSON.stringify(err)}`);
                return;
            }
            console.info('Campus assistant home loaded.');
        });
    }
    onWindowStageDestroy(): void {
        console.info('Campus assistant window stage destroyed.');
    }
    onForeground(): void {
        console.info('Campus assistant on foreground.');
    }
    onBackground(): void {
        console.info('Campus assistant on background.');
    }
}
