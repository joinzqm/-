if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProfilePage_Params {
    isLoggedIn?: boolean;
    darkMode?: boolean;
    fontScale?: number;
    todoList?: TodoItem[];
    onNavigate?: (page: string) => void;
    onLogout?: () => void;
    nickname?: string;
    studentId?: string;
    college?: string;
    major?: string;
    avatarColor?: string;
    cacheSize?: string;
    featureItems?: FeatureItem[];
}
import { CommonCard } from "@bundle:com.campusassistant.app/entry/ets/components/CommonCard";
import type { TodoItem } from '../model/AppModels';
import { AppTheme } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import { PrefKeys, PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
interface FeatureItem {
    id: string;
    title: string;
    icon: string;
}
export class ProfilePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isLoggedIn = new SynchedPropertySimpleTwoWayPU(params.isLoggedIn, this, "isLoggedIn");
        this.__darkMode = new SynchedPropertySimpleTwoWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleTwoWayPU(params.fontScale, this, "fontScale");
        this.__todoList = new SynchedPropertyObjectOneWayPU(params.todoList, this, "todoList");
        this.onNavigate = undefined;
        this.onLogout = undefined;
        this.__nickname = new ObservedPropertySimplePU('同学', this, "nickname");
        this.__studentId = new ObservedPropertySimplePU('', this, "studentId");
        this.__college = new ObservedPropertySimplePU('', this, "college");
        this.__major = new ObservedPropertySimplePU('', this, "major");
        this.__avatarColor = new ObservedPropertySimplePU('#1677FF', this, "avatarColor");
        this.__cacheSize = new ObservedPropertySimplePU('12.6 MB', this, "cacheSize");
        this.featureItems = [
            { id: 'favorites', title: '我的收藏', icon: '⭐' },
            { id: 'todo', title: '我的待办', icon: '📝' },
            { id: 'course', title: '我的课程', icon: '📚' },
            { id: 'grade', title: '我的成绩', icon: '📊' },
            { id: 'lost', title: '失物发布', icon: '🎒' },
            { id: 'help', title: '帮助中心', icon: '❓' },
            { id: 'feedback', title: '意见反馈', icon: '💬' }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProfilePage_Params) {
        if (params.todoList === undefined) {
            this.__todoList.set([]);
        }
        if (params.onNavigate !== undefined) {
            this.onNavigate = params.onNavigate;
        }
        if (params.onLogout !== undefined) {
            this.onLogout = params.onLogout;
        }
        if (params.nickname !== undefined) {
            this.nickname = params.nickname;
        }
        if (params.studentId !== undefined) {
            this.studentId = params.studentId;
        }
        if (params.college !== undefined) {
            this.college = params.college;
        }
        if (params.major !== undefined) {
            this.major = params.major;
        }
        if (params.avatarColor !== undefined) {
            this.avatarColor = params.avatarColor;
        }
        if (params.cacheSize !== undefined) {
            this.cacheSize = params.cacheSize;
        }
        if (params.featureItems !== undefined) {
            this.featureItems = params.featureItems;
        }
    }
    updateStateVars(params: ProfilePage_Params) {
        this.__todoList.reset(params.todoList);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
        this.__nickname.purgeDependencyOnElmtId(rmElmtId);
        this.__studentId.purgeDependencyOnElmtId(rmElmtId);
        this.__college.purgeDependencyOnElmtId(rmElmtId);
        this.__major.purgeDependencyOnElmtId(rmElmtId);
        this.__avatarColor.purgeDependencyOnElmtId(rmElmtId);
        this.__cacheSize.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isLoggedIn.aboutToBeDeleted();
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__todoList.aboutToBeDeleted();
        this.__nickname.aboutToBeDeleted();
        this.__studentId.aboutToBeDeleted();
        this.__college.aboutToBeDeleted();
        this.__major.aboutToBeDeleted();
        this.__avatarColor.aboutToBeDeleted();
        this.__cacheSize.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isLoggedIn: SynchedPropertySimpleTwoWayPU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __darkMode: SynchedPropertySimpleTwoWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleTwoWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __todoList: SynchedPropertySimpleOneWayPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    private onNavigate?: (page: string) => void;
    private onLogout?: () => void;
    private __nickname: ObservedPropertySimplePU<string>;
    get nickname() {
        return this.__nickname.get();
    }
    set nickname(newValue: string) {
        this.__nickname.set(newValue);
    }
    private __studentId: ObservedPropertySimplePU<string>;
    get studentId() {
        return this.__studentId.get();
    }
    set studentId(newValue: string) {
        this.__studentId.set(newValue);
    }
    private __college: ObservedPropertySimplePU<string>;
    get college() {
        return this.__college.get();
    }
    set college(newValue: string) {
        this.__college.set(newValue);
    }
    private __major: ObservedPropertySimplePU<string>;
    get major() {
        return this.__major.get();
    }
    set major(newValue: string) {
        this.__major.set(newValue);
    }
    private __avatarColor: ObservedPropertySimplePU<string>;
    get avatarColor() {
        return this.__avatarColor.get();
    }
    set avatarColor(newValue: string) {
        this.__avatarColor.set(newValue);
    }
    private __cacheSize: ObservedPropertySimplePU<string>;
    get cacheSize() {
        return this.__cacheSize.get();
    }
    set cacheSize(newValue: string) {
        this.__cacheSize.set(newValue);
    }
    private featureItems: FeatureItem[];
    aboutToAppear() {
        this.loadUserInfo();
    }
    private async loadUserInfo(): Promise<void> {
        this.nickname = await PreferencesStore.getString(PrefKeys.USER_NICKNAME, '同学');
        this.studentId = await PreferencesStore.getString(PrefKeys.USER_STUDENT_ID, '');
        this.college = await PreferencesStore.getString(PrefKeys.USER_COLLEGE, '');
        this.major = await PreferencesStore.getString(PrefKeys.USER_MAJOR, '');
        const color = await PreferencesStore.getString(PrefKeys.USER_AVATAR_COLOR, '');
        if (color.length > 0) {
            this.avatarColor = color;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ProfilePage.ets(73:5)", "entry");
            Scroll.width('100%');
            Scroll.height('100%');
            Scroll.backgroundColor(this.pageBackground());
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(74:7)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 18, bottom: 20 });
        }, Column);
        this.buildHeader.bind(this)();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.profileBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 76, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.profileBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.featureListBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 77, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.featureListBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.settingBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 78, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.settingBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.todoBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 79, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.todoBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new CommonCard(this, { darkMode: this.darkMode, content: this.aboutBuilder }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 80, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            content: this.aboutBuilder
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode
                    });
                }
            }, { name: "CommonCard" });
        }
        Column.pop();
        Scroll.pop();
    }
    private buildHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(93:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(94:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(95:9)", "entry");
            Text.fontSize(24 * this.fontScale);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('个人信息、设置与待办管理');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(99:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(104:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(105:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('⚙️');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(106:9)", "entry");
            Text.fontSize(20 * this.fontScale);
            Text.onClick(() => {
                if (this.onNavigate) {
                    this.onNavigate('settings');
                }
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('退出');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(113:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(AppTheme.WARN_ORANGE);
            Text.padding({ left: 10, right: 10, top: 6, bottom: 6 });
            Text.backgroundColor(this.surfaceColor());
            Text.borderRadius(12);
            Text.onClick(() => {
                if (this.onLogout) {
                    this.onLogout();
                }
            });
        }, Text);
        Text.pop();
        Row.pop();
        Row.pop();
    }
    private profileBuilder(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 14 });
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(131:5)", "entry");
            Row.width('100%');
            Row.onClick(() => {
                if (this.onNavigate) {
                    this.onNavigate('profileEdit');
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.displayInitial);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(132:7)", "entry");
            Text.width(56);
            Text.height(56);
            Text.borderRadius(28);
            Text.textAlign(TextAlign.Center);
            Text.fontSize(20 * this.fontScale);
            Text.fontColor(Color.White);
            Text.backgroundColor(this.avatarColor);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(140:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.displayName);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(141:9)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.displayStudentId);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(145:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.displayCollegeMajor);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(148:9)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(154:7)", "entry");
            Text.fontSize(16 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
    }
    private featureListBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('功能列表', '');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ wrap: FlexWrap.Wrap, justifyContent: FlexAlign.SpaceBetween });
            Flex.debugLine("entry/src/main/ets/pages/ProfilePage.ets(169:5)", "entry");
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 8 });
                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(171:9)", "entry");
                    Column.width('25%');
                    Column.margin({ bottom: 16 });
                    Column.onClick(() => {
                        if (this.onNavigate) {
                            this.onNavigate(item.id);
                        }
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.icon);
                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(172:11)", "entry");
                    Text.width(44);
                    Text.height(44);
                    Text.borderRadius(22);
                    Text.textAlign(TextAlign.Center);
                    Text.fontSize(22 * this.fontScale);
                    Text.backgroundColor(this.surfaceColor());
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(179:11)", "entry");
                    Text.fontSize(12 * this.fontScale);
                    Text.fontColor(this.primaryText());
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.featureItems, forEachItemGenFunction, (item: FeatureItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        Flex.pop();
    }
    private settingBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('设置', '');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(197:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(198:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.darkMode ? '☀️ 浅色模式' : '🌙 深色模式');
            Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(199:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(12 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.layoutWeight(1);
            Button.onClick(async () => {
                this.darkMode = !this.darkMode;
                await PreferencesStore.setBoolean(PrefKeys.SETTING_DARK_MODE, this.darkMode);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(`字号 ${this.fontScale.toFixed(2)}`);
            Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(210:9)", "entry");
            Button.type(ButtonType.Capsule);
            Button.fontSize(12 * this.fontScale);
            Button.fontColor(Color.White);
            Button.backgroundColor(AppTheme.WARN_ORANGE);
            Button.layoutWeight(1);
            Button.onClick(async () => {
                this.fontScale = this.fontScale >= 1.15 ? 1 : this.fontScale + 0.05;
                await PreferencesStore.setNumber(PrefKeys.SETTING_FONT_SCALE, this.fontScale);
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.buildSettingRow.bind(this)('通知设置', '课程 / 公告 / 待办', () => {
            if (this.onNavigate) {
                this.onNavigate('notifySettings');
            }
        });
        this.buildSettingRow.bind(this)('清理缓存', this.cacheSize, () => {
            this.cacheSize = '0 MB';
        });
        Column.pop();
    }
    private buildSettingRow(title: string, value: string, onClick: () => void, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(236:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
            Row.onClick(() => {
                onClick();
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(237:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(240:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(241:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('>');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(244:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
    }
    private todoBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('我的待办', '全部');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(261:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.buildTodoRow.bind(this)(item);
            };
            this.forEachUpdateFunction(elmtId, this.todoList.slice(0, 3), forEachItemGenFunction, (item: TodoItem) => item.id, false, false);
        }, ForEach);
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.todoList.length > 3) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('查看全部待办');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(267:9)", "entry");
                        Text.fontSize(13 * this.fontScale);
                        Text.fontColor(AppTheme.BRAND_BLUE);
                        Text.width('100%');
                        Text.textAlign(TextAlign.Center);
                        Text.padding({ top: 8 });
                        Text.onClick(() => {
                            if (this.onNavigate) {
                                this.onNavigate('todo');
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private buildTodoRow(item: TodoItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(284:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.finished ? '✓' : '○');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(285:7)", "entry");
            Text.width(28);
            Text.height(28);
            Text.borderRadius(14);
            Text.textAlign(TextAlign.Center);
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(Color.White);
            Text.backgroundColor(item.finished ? AppTheme.SUCCESS_GREEN : AppTheme.WARN_ORANGE);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 2 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(293:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(294:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(item.finished ? this.secondaryText() : this.primaryText());
            Text.decoration({ type: item.finished ? TextDecorationType.LineThrough : TextDecorationType.None });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.category);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(298:9)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
    }
    private aboutBuilder(parent = null) {
        this.buildSectionHeader.bind(this)('关于', '');
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(313:5)", "entry");
        }, Column);
        this.buildAboutRow.bind(this)('版本号', 'V1.0.0');
        this.buildAboutRow.bind(this)('开发团队', '校园助手开发团队');
        this.buildAboutRow.bind(this)('版权信息', '© 2026 高校校园助手');
        Column.pop();
    }
    private buildAboutRow(label: string, value: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(322:5)", "entry");
            Row.width('100%');
            Row.padding(12);
            Row.borderRadius(12);
            Row.backgroundColor(this.surfaceColor());
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(label);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(323:7)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(326:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(327:7)", "entry");
            Text.fontSize(13 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
    }
    private buildSectionHeader(title: string, action: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(339:5)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(340:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(344:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (action.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(action);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(346:9)", "entry");
                        Text.fontSize(12 * this.fontScale);
                        Text.fontColor(AppTheme.BRAND_BLUE);
                        Text.onClick(() => {
                            if (title === '我的待办' && this.onNavigate) {
                                this.onNavigate('todo');
                            }
                        });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
