if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LostFoundPage_Params {
    darkMode?: boolean;
    fontScale?: number;
    onBack?: () => void;
    currentCategory?: string;
    searchText?: string;
    itemList?: LostFoundItem[];
    showPublishSheet?: boolean;
    publishType?: 'lost' | 'found';
    publishItemName?: string;
    publishLocation?: string;
    publishDescription?: string;
    publishContact?: string;
    categories?: string[];
}
import { PageHeader, TagButton, SearchBar, EmptyView } from "@bundle:com.campusassistant.app/entry/ets/components/CommonComponents";
import type { LostFoundItem } from '../model/AppModels';
import { AppTheme, AppData, AppState } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import { FileStore } from "@bundle:com.campusassistant.app/entry/ets/utils/FileStore";
export class LostFoundPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__darkMode = new SynchedPropertySimpleOneWayPU(params.darkMode, this, "darkMode");
        this.__fontScale = new SynchedPropertySimpleOneWayPU(params.fontScale, this, "fontScale");
        this.onBack = undefined;
        this.__currentCategory = new ObservedPropertySimplePU('全部', this, "currentCategory");
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__itemList = new ObservedPropertyObjectPU([], this, "itemList");
        this.__showPublishSheet = new ObservedPropertySimplePU(false, this, "showPublishSheet");
        this.__publishType = new ObservedPropertySimplePU('lost', this, "publishType");
        this.__publishItemName = new ObservedPropertySimplePU('', this, "publishItemName");
        this.__publishLocation = new ObservedPropertySimplePU('', this, "publishLocation");
        this.__publishDescription = new ObservedPropertySimplePU('', this, "publishDescription");
        this.__publishContact = new ObservedPropertySimplePU('', this, "publishContact");
        this.categories = ['全部', '失物', '拾物', '校园卡', '电子产品', '书包', '其他'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LostFoundPage_Params) {
        if (params.darkMode === undefined) {
            this.__darkMode.set(false);
        }
        if (params.fontScale === undefined) {
            this.__fontScale.set(1);
        }
        if (params.onBack !== undefined) {
            this.onBack = params.onBack;
        }
        if (params.currentCategory !== undefined) {
            this.currentCategory = params.currentCategory;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.itemList !== undefined) {
            this.itemList = params.itemList;
        }
        if (params.showPublishSheet !== undefined) {
            this.showPublishSheet = params.showPublishSheet;
        }
        if (params.publishType !== undefined) {
            this.publishType = params.publishType;
        }
        if (params.publishItemName !== undefined) {
            this.publishItemName = params.publishItemName;
        }
        if (params.publishLocation !== undefined) {
            this.publishLocation = params.publishLocation;
        }
        if (params.publishDescription !== undefined) {
            this.publishDescription = params.publishDescription;
        }
        if (params.publishContact !== undefined) {
            this.publishContact = params.publishContact;
        }
        if (params.categories !== undefined) {
            this.categories = params.categories;
        }
    }
    updateStateVars(params: LostFoundPage_Params) {
        this.__darkMode.reset(params.darkMode);
        this.__fontScale.reset(params.fontScale);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__currentCategory.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__itemList.purgeDependencyOnElmtId(rmElmtId);
        this.__showPublishSheet.purgeDependencyOnElmtId(rmElmtId);
        this.__publishType.purgeDependencyOnElmtId(rmElmtId);
        this.__publishItemName.purgeDependencyOnElmtId(rmElmtId);
        this.__publishLocation.purgeDependencyOnElmtId(rmElmtId);
        this.__publishDescription.purgeDependencyOnElmtId(rmElmtId);
        this.__publishContact.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__currentCategory.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__itemList.aboutToBeDeleted();
        this.__showPublishSheet.aboutToBeDeleted();
        this.__publishType.aboutToBeDeleted();
        this.__publishItemName.aboutToBeDeleted();
        this.__publishLocation.aboutToBeDeleted();
        this.__publishDescription.aboutToBeDeleted();
        this.__publishContact.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __darkMode: SynchedPropertySimpleOneWayPU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: SynchedPropertySimpleOneWayPU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private onBack?: () => void;
    private __currentCategory: ObservedPropertySimplePU<string>;
    get currentCategory() {
        return this.__currentCategory.get();
    }
    set currentCategory(newValue: string) {
        this.__currentCategory.set(newValue);
    }
    private __searchText: ObservedPropertySimplePU<string>;
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue: string) {
        this.__searchText.set(newValue);
    }
    private __itemList: ObservedPropertyObjectPU<LostFoundItem[]>;
    get itemList() {
        return this.__itemList.get();
    }
    set itemList(newValue: LostFoundItem[]) {
        this.__itemList.set(newValue);
    }
    private __showPublishSheet: ObservedPropertySimplePU<boolean>;
    get showPublishSheet() {
        return this.__showPublishSheet.get();
    }
    set showPublishSheet(newValue: boolean) {
        this.__showPublishSheet.set(newValue);
    }
    private __publishType: ObservedPropertySimplePU<'lost' | 'found'>;
    get publishType() {
        return this.__publishType.get();
    }
    set publishType(newValue: 'lost' | 'found') {
        this.__publishType.set(newValue);
    }
    private __publishItemName: ObservedPropertySimplePU<string>;
    get publishItemName() {
        return this.__publishItemName.get();
    }
    set publishItemName(newValue: string) {
        this.__publishItemName.set(newValue);
    }
    private __publishLocation: ObservedPropertySimplePU<string>;
    get publishLocation() {
        return this.__publishLocation.get();
    }
    set publishLocation(newValue: string) {
        this.__publishLocation.set(newValue);
    }
    private __publishDescription: ObservedPropertySimplePU<string>;
    get publishDescription() {
        return this.__publishDescription.get();
    }
    set publishDescription(newValue: string) {
        this.__publishDescription.set(newValue);
    }
    private __publishContact: ObservedPropertySimplePU<string>;
    get publishContact() {
        return this.__publishContact.get();
    }
    set publishContact(newValue: string) {
        this.__publishContact.set(newValue);
    }
    private categories: string[];
    aboutToAppear() {
        this.loadData();
    }
    private async loadData(): Promise<void> {
        const saved = await FileStore.getLostFound<LostFoundItem[]>([]);
        this.itemList = saved.length > 0 ? saved : AppData.lostFoundItems.slice();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(54:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(55:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new PageHeader(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        title: '失物招领',
                        rightAction: '发布',
                        onBack: () => {
                            if (this.onBack) {
                                this.onBack();
                            }
                        },
                        onRightAction: () => {
                            this.resetPublishForm();
                            this.showPublishSheet = true;
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 56, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            title: '失物招领',
                            rightAction: '发布',
                            onBack: () => {
                                if (this.onBack) {
                                    this.onBack();
                                }
                            },
                            onRightAction: () => {
                                this.resetPublishForm();
                                this.showPublishSheet = true;
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "PageHeader" });
        }
        this.buildSearchBar.bind(this)();
        this.buildCategoryTabs.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.filteredItems.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new EmptyView(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    icon: '🔍',
                                    text: '暂无信息'
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 77, col: 11 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        icon: '🔍',
                                        text: '暂无信息'
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "EmptyView" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 10 });
                        List.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(84:11)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, top: 12, bottom: 12 });
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(86:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.buildListItem.bind(this)(item);
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.filteredItems, forEachItemGenFunction, (item: LostFoundItem) => item.id, false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showPublishSheet) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.buildDialogMask.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private buildDialogMask(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(110:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(111:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('rgba(0, 0, 0, 0.5)');
            Column.onClick(() => {
                this.showPublishSheet = false;
                this.resetPublishForm();
            });
        }, Column);
        Column.pop();
        this.buildPublishSheet.bind(this)();
        Stack.pop();
    }
    private buildSearchBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.margin({ left: 16, right: 16, top: 12 });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new SearchBar(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        placeholder: '搜索物品名称、地点',
                        searchText: this.__searchText
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 129, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            placeholder: '搜索物品名称、地点',
                            searchText: this.searchText
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "SearchBar" });
        }
        __Common__.pop();
    }
    private buildCategoryTabs(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(140:5)", "entry");
            Scroll.width('100%');
            Scroll.scrollable(ScrollDirection.Horizontal);
            Scroll.scrollBar(BarState.Off);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(141:7)", "entry");
            Row.padding({ left: 16, right: 16, top: 12, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const category = _item;
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new TagButton(this, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale,
                                label: category,
                                active: this.currentCategory === category,
                                onTap: () => {
                                    this.currentCategory = category;
                                }
                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 143, col: 11 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    label: category,
                                    active: this.currentCategory === category,
                                    onTap: () => {
                                        this.currentCategory = category;
                                    }
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                darkMode: this.darkMode,
                                fontScale: this.fontScale
                            });
                        }
                    }, { name: "TagButton" });
                }
            };
            this.forEachUpdateFunction(elmtId, this.categories, forEachItemGenFunction, (category: string) => category, false, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        Scroll.pop();
    }
    private buildListItem(item: LostFoundItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(163:5)", "entry");
            Row.width('100%');
            Row.padding(14);
            Row.backgroundColor(this.cardBackground());
            Row.borderRadius(12);
        }, Row);
        this.buildItemImage.bind(this)(item);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(166:7)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(167:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.itemName);
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(168:11)", "entry");
            Text.fontSize(15 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.buildTypeTag.bind(this)(item.type);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 6 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(180:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📍');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(181:11)", "entry");
            Text.fontSize(12 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.location);
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(183:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 6 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(190:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🕐');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(191:11)", "entry");
            Text.fontSize(12 * this.fontScale);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.time);
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(193:11)", "entry");
            Text.fontSize(12 * this.fontScale);
            Text.fontColor(this.secondaryText());
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    private buildItemImage(item: LostFoundItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(209:5)", "entry");
            Column.width(56);
            Column.height(56);
            Column.borderRadius(10);
            Column.backgroundColor(this.getCategoryColor(item.category, item.type));
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getCategoryIcon(item.category));
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(210:7)", "entry");
            Text.fontSize(28);
        }, Text);
        Text.pop();
        Column.pop();
    }
    private buildTypeTag(type: 'lost' | 'found', parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(type === 'lost' ? '失物' : '拾物');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(222:5)", "entry");
            Text.fontSize(11 * this.fontScale);
            Text.fontColor(Color.White);
            Text.padding({ left: 8, right: 8, top: 3, bottom: 3 });
            Text.backgroundColor(type === 'lost' ? AppTheme.WARN_ORANGE : AppTheme.SUCCESS_GREEN);
            Text.borderRadius(4);
        }, Text);
        Text.pop();
    }
    private buildPublishSheet(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(232:5)", "entry");
            Column.width('100%');
            Column.padding({ left: 20, right: 20, top: 16, bottom: 16 });
            Column.backgroundColor(this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG);
            Column.borderRadius({ topLeft: 16, topRight: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('发布信息');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(233:7)", "entry");
            Text.fontSize(18 * this.fontScale);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(this.primaryText());
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(241:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('信息类型');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(242:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(246:9)", "entry");
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TagButton(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        label: '失物',
                        active: this.publishType === 'lost',
                        activeColor: AppTheme.WARN_ORANGE,
                        onTap: () => {
                            this.publishType = 'lost';
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 247, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            label: '失物',
                            active: this.publishType === 'lost',
                            activeColor: AppTheme.WARN_ORANGE,
                            onTap: () => {
                                this.publishType = 'lost';
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "TagButton" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TagButton(this, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale,
                        label: '拾物',
                        active: this.publishType === 'found',
                        activeColor: AppTheme.SUCCESS_GREEN,
                        onTap: () => {
                            this.publishType = 'found';
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/LostFoundPage.ets", line: 257, col: 11 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            darkMode: this.darkMode,
                            fontScale: this.fontScale,
                            label: '拾物',
                            active: this.publishType === 'found',
                            activeColor: AppTheme.SUCCESS_GREEN,
                            onTap: () => {
                                this.publishType = 'found';
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        darkMode: this.darkMode,
                        fontScale: this.fontScale
                    });
                }
            }, { name: "TagButton" });
        }
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(272:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('物品名称');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(273:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入物品名称', text: this.publishItemName });
            TextInput.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(277:9)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => {
                this.publishItemName = value;
            });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(293:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('地点');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(294:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入丢失/拾到地点', text: this.publishLocation });
            TextInput.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(298:9)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.onChange((value: string) => {
                this.publishLocation = value;
            });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(314:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('描述');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(315:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '请输入物品详细描述', text: this.publishDescription });
            TextArea.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(319:9)", "entry");
            TextArea.width('100%');
            TextArea.height(80);
            TextArea.fontSize(14 * this.fontScale);
            TextArea.fontColor(this.primaryText());
            TextArea.placeholderColor(this.secondaryText());
            TextArea.backgroundColor(this.surfaceColor());
            TextArea.borderRadius(8);
            TextArea.padding(12);
            TextArea.onChange((value: string) => {
                this.publishDescription = value;
            });
        }, TextArea);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(335:7)", "entry");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('联系电话');
            Text.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(336:9)", "entry");
            Text.fontSize(14 * this.fontScale);
            Text.fontColor(this.primaryText());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入联系电话', text: this.publishContact });
            TextInput.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(340:9)", "entry");
            TextInput.width('100%');
            TextInput.height(44);
            TextInput.fontSize(14 * this.fontScale);
            TextInput.fontColor(this.primaryText());
            TextInput.placeholderColor(this.secondaryText());
            TextInput.backgroundColor(this.surfaceColor());
            TextInput.borderRadius(8);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.type(InputType.PhoneNumber);
            TextInput.onChange((value: string) => {
                this.publishContact = value;
            });
        }, TextInput);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(357:7)", "entry");
            Row.width('100%');
            Row.margin({ top: 4, bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(358:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(this.surfaceColor());
            Button.fontColor(this.primaryText());
            Button.borderRadius(22);
            Button.onClick(() => {
                this.showPublishSheet = false;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('发布');
            Button.debugLine("entry/src/main/ets/pages/LostFoundPage.ets(369:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(15 * this.fontScale);
            Button.backgroundColor(AppTheme.BRAND_BLUE);
            Button.fontColor(Color.White);
            Button.borderRadius(22);
            Button.onClick(() => {
                this.publishItem();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    private getCategoryIcon(category: string): string {
        switch (category) {
            case '校园卡':
                return '💳';
            case '电子产品':
                return '📱';
            case '书包':
                return '🎒';
            default:
                return '📦';
        }
    }
    private getCategoryColor(category: string, type: 'lost' | 'found'): string {
        const baseColor = type === 'lost' ? '#FFF7E8' : '#E8FFEE';
        const darkBaseColor = type === 'lost' ? '#3D2E14' : '#143D22';
        return this.darkMode ? darkBaseColor : baseColor;
    }
    private resetPublishForm(): void {
        this.publishType = 'lost';
        this.publishItemName = '';
        this.publishLocation = '';
        this.publishDescription = '';
        this.publishContact = '';
    }
    private publishItem(): void {
        if (!this.publishItemName.trim() || !this.publishLocation.trim() || !this.publishContact.trim()) {
            return;
        }
        const newItem: LostFoundItem = {
            id: AppState.generateId(),
            type: this.publishType,
            itemName: this.publishItemName.trim(),
            location: this.publishLocation.trim(),
            time: '刚刚',
            description: this.publishDescription.trim(),
            contact: this.publishContact.trim(),
            category: this.guessCategory(this.publishItemName.trim())
        };
        this.itemList = [newItem].concat(this.itemList);
        FileStore.saveLostFound(this.itemList).catch((e: Error) => console.error(`saveLostFound: ${JSON.stringify(e)}`));
        this.showPublishSheet = false;
        this.resetPublishForm();
    }
    private guessCategory(name: string): string {
        const lower = name.toLowerCase();
        if (lower.includes('卡') || lower.includes('校园卡') || lower.includes('学生证')) {
            return '校园卡';
        }
        if (lower.includes('手机') || lower.includes('耳机') || lower.includes('电脑') || lower.includes('u盘') || lower.includes('电子')) {
            return '电子产品';
        }
        if (lower.includes('书包') || lower.includes('背包') || lower.includes('包')) {
            return '书包';
        }
        return '其他';
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardBackground(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private surfaceColor(): string {
        return this.darkMode ? AppTheme.DARK_SURFACE : AppTheme.SURFACE;
    }
    private primaryText(): string {
        return this.darkMode ? AppTheme.DARK_PRIMARY_TEXT : AppTheme.PRIMARY_TEXT;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
