if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    currentTab?: number;
    darkMode?: boolean;
    fontScale?: number;
    isLoggedIn?: boolean;
    isBootstrapped?: boolean;
    showSplash?: boolean;
    isFirstLaunch?: boolean;
    currentPage?: PageType;
    subPage?: SubPageType;
    pageParams?: PageParams;
    context?: common.UIAbilityContext;
    todoList?: TodoItem[];
    noticeList?: NoticeItem[];
    courseList?: CourseItem[];
    bookList?: BookItem[];
    foodList?: FoodItem[];
    tabTitles?: string[];
    tabIcons?: string[];
}
import { AppTheme, AppData } from "@bundle:com.campusassistant.app/entry/ets/viewmodel/AppViewModel";
import type common from "@ohos:app.ability.common";
import { CampusPage } from "@bundle:com.campusassistant.app/entry/ets/pages/CampusPage";
import { HomePage } from "@bundle:com.campusassistant.app/entry/ets/pages/HomePage";
import { LoginPage } from "@bundle:com.campusassistant.app/entry/ets/pages/LoginPage";
import { ProfilePage } from "@bundle:com.campusassistant.app/entry/ets/pages/ProfilePage";
import { ServicePage } from "@bundle:com.campusassistant.app/entry/ets/pages/ServicePage";
import { StudyPage } from "@bundle:com.campusassistant.app/entry/ets/pages/StudyPage";
import { SplashPage } from "@bundle:com.campusassistant.app/entry/ets/pages/SplashPage";
import { GuidePage } from "@bundle:com.campusassistant.app/entry/ets/pages/GuidePage";
import { NoticeDetailPage } from "@bundle:com.campusassistant.app/entry/ets/pages/NoticeDetailPage";
import { TodoPage } from "@bundle:com.campusassistant.app/entry/ets/pages/TodoPage";
import { CourseEditPage } from "@bundle:com.campusassistant.app/entry/ets/pages/CourseEditPage";
import { LibraryPage } from "@bundle:com.campusassistant.app/entry/ets/pages/LibraryPage";
import { LostFoundPage } from "@bundle:com.campusassistant.app/entry/ets/pages/LostFoundPage";
import { FoodPage } from "@bundle:com.campusassistant.app/entry/ets/pages/FoodPage";
import { MusicPage } from "@bundle:com.campusassistant.app/entry/ets/pages/MusicPage";
import { MapPage } from "@bundle:com.campusassistant.app/entry/ets/pages/MapPage";
import { ProfileEditPage } from "@bundle:com.campusassistant.app/entry/ets/pages/ProfileEditPage";
import { FavoritesPage } from "@bundle:com.campusassistant.app/entry/ets/pages/FavoritesPage";
import { SettingsPage } from "@bundle:com.campusassistant.app/entry/ets/pages/SettingsPage";
import { PrefKeys, PreferencesStore } from "@bundle:com.campusassistant.app/entry/ets/utils/PreferencesStore";
import { FileStore } from "@bundle:com.campusassistant.app/entry/ets/utils/FileStore";
import type { NoticeItem, TodoItem, CourseItem, BookItem, FoodItem } from '../model/AppModels';
type PageType = 'splash' | 'guide' | 'login' | 'main';
type SubPageType = 'none' | 'noticeDetail' | 'todo' | 'courseEdit' | 'library' | 'lostFound' | 'food' | 'music' | 'map' | 'profileEdit' | 'favorites' | 'settings';
interface PageParams {
    notice?: NoticeItem;
    course?: CourseItem;
    tab?: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentTab = new ObservedPropertySimplePU(0, this, "currentTab");
        this.__darkMode = new ObservedPropertySimplePU(false, this, "darkMode");
        this.__fontScale = new ObservedPropertySimplePU(1, this, "fontScale");
        this.__isLoggedIn = this.createStorageLink('isLoggedIn', false, "isLoggedIn");
        this.__isBootstrapped = new ObservedPropertySimplePU(false, this, "isBootstrapped");
        this.__showSplash = new ObservedPropertySimplePU(true, this, "showSplash");
        this.__isFirstLaunch = new ObservedPropertySimplePU(true, this, "isFirstLaunch");
        this.__currentPage = new ObservedPropertySimplePU('splash', this, "currentPage");
        this.__subPage = new ObservedPropertySimplePU('none', this, "subPage");
        this.__pageParams = new ObservedPropertyObjectPU({}, this, "pageParams");
        this.context = getContext(this) as common.UIAbilityContext;
        this.__todoList = new ObservedPropertyObjectPU([], this, "todoList");
        this.__noticeList = new ObservedPropertyObjectPU([], this, "noticeList");
        this.__courseList = new ObservedPropertyObjectPU([], this, "courseList");
        this.__bookList = new ObservedPropertyObjectPU([], this, "bookList");
        this.__foodList = new ObservedPropertyObjectPU([], this, "foodList");
        this.tabTitles = ['首页', '校园信息', '学习助手', '生活服务', '我的'];
        this.tabIcons = ['🏠', '🏫', '📚', '🛎️', '👤'];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
        if (params.darkMode !== undefined) {
            this.darkMode = params.darkMode;
        }
        if (params.fontScale !== undefined) {
            this.fontScale = params.fontScale;
        }
        if (params.isBootstrapped !== undefined) {
            this.isBootstrapped = params.isBootstrapped;
        }
        if (params.showSplash !== undefined) {
            this.showSplash = params.showSplash;
        }
        if (params.isFirstLaunch !== undefined) {
            this.isFirstLaunch = params.isFirstLaunch;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.subPage !== undefined) {
            this.subPage = params.subPage;
        }
        if (params.pageParams !== undefined) {
            this.pageParams = params.pageParams;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.todoList !== undefined) {
            this.todoList = params.todoList;
        }
        if (params.noticeList !== undefined) {
            this.noticeList = params.noticeList;
        }
        if (params.courseList !== undefined) {
            this.courseList = params.courseList;
        }
        if (params.bookList !== undefined) {
            this.bookList = params.bookList;
        }
        if (params.foodList !== undefined) {
            this.foodList = params.foodList;
        }
        if (params.tabTitles !== undefined) {
            this.tabTitles = params.tabTitles;
        }
        if (params.tabIcons !== undefined) {
            this.tabIcons = params.tabIcons;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
        this.__darkMode.purgeDependencyOnElmtId(rmElmtId);
        this.__fontScale.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__isBootstrapped.purgeDependencyOnElmtId(rmElmtId);
        this.__showSplash.purgeDependencyOnElmtId(rmElmtId);
        this.__isFirstLaunch.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__subPage.purgeDependencyOnElmtId(rmElmtId);
        this.__pageParams.purgeDependencyOnElmtId(rmElmtId);
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
        this.__noticeList.purgeDependencyOnElmtId(rmElmtId);
        this.__courseList.purgeDependencyOnElmtId(rmElmtId);
        this.__bookList.purgeDependencyOnElmtId(rmElmtId);
        this.__foodList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentTab.aboutToBeDeleted();
        this.__darkMode.aboutToBeDeleted();
        this.__fontScale.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__isBootstrapped.aboutToBeDeleted();
        this.__showSplash.aboutToBeDeleted();
        this.__isFirstLaunch.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__subPage.aboutToBeDeleted();
        this.__pageParams.aboutToBeDeleted();
        this.__todoList.aboutToBeDeleted();
        this.__noticeList.aboutToBeDeleted();
        this.__courseList.aboutToBeDeleted();
        this.__bookList.aboutToBeDeleted();
        this.__foodList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentTab: ObservedPropertySimplePU<number>;
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: number) {
        this.__currentTab.set(newValue);
    }
    private __darkMode: ObservedPropertySimplePU<boolean>;
    get darkMode() {
        return this.__darkMode.get();
    }
    set darkMode(newValue: boolean) {
        this.__darkMode.set(newValue);
    }
    private __fontScale: ObservedPropertySimplePU<number>;
    get fontScale() {
        return this.__fontScale.get();
    }
    set fontScale(newValue: number) {
        this.__fontScale.set(newValue);
    }
    private __isLoggedIn: ObservedPropertyAbstractPU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __isBootstrapped: ObservedPropertySimplePU<boolean>;
    get isBootstrapped() {
        return this.__isBootstrapped.get();
    }
    set isBootstrapped(newValue: boolean) {
        this.__isBootstrapped.set(newValue);
    }
    private __showSplash: ObservedPropertySimplePU<boolean>;
    get showSplash() {
        return this.__showSplash.get();
    }
    set showSplash(newValue: boolean) {
        this.__showSplash.set(newValue);
    }
    private __isFirstLaunch: ObservedPropertySimplePU<boolean>;
    get isFirstLaunch() {
        return this.__isFirstLaunch.get();
    }
    set isFirstLaunch(newValue: boolean) {
        this.__isFirstLaunch.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<PageType>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: PageType) {
        this.__currentPage.set(newValue);
    }
    private __subPage: ObservedPropertySimplePU<SubPageType>;
    get subPage() {
        return this.__subPage.get();
    }
    set subPage(newValue: SubPageType) {
        this.__subPage.set(newValue);
    }
    private __pageParams: ObservedPropertyObjectPU<PageParams>;
    get pageParams() {
        return this.__pageParams.get();
    }
    set pageParams(newValue: PageParams) {
        this.__pageParams.set(newValue);
    }
    private context: common.UIAbilityContext;
    private __todoList: ObservedPropertyObjectPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    private __noticeList: ObservedPropertyObjectPU<NoticeItem[]>;
    get noticeList() {
        return this.__noticeList.get();
    }
    set noticeList(newValue: NoticeItem[]) {
        this.__noticeList.set(newValue);
    }
    private __courseList: ObservedPropertyObjectPU<CourseItem[]>;
    get courseList() {
        return this.__courseList.get();
    }
    set courseList(newValue: CourseItem[]) {
        this.__courseList.set(newValue);
    }
    private __bookList: ObservedPropertyObjectPU<BookItem[]>;
    get bookList() {
        return this.__bookList.get();
    }
    set bookList(newValue: BookItem[]) {
        this.__bookList.set(newValue);
    }
    private __foodList: ObservedPropertyObjectPU<FoodItem[]>;
    get foodList() {
        return this.__foodList.get();
    }
    set foodList(newValue: FoodItem[]) {
        this.__foodList.set(newValue);
    }
    private readonly tabTitles: string[];
    private readonly tabIcons: string[];
    aboutToAppear(): void {
        AppStorage.setOrCreate<boolean>('isLoggedIn', false);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(65:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
            Stack.onAppear(async () => {
                await this.bootstrap();
            });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isBootstrapped) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(67:9)", "entry");
                        Column.width('100%');
                        Column.height('100%');
                        Column.backgroundColor(this.pageBackground());
                    }, Column);
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.currentPage === 'splash') {
                            this.ifElseBranchUpdateFunction(0, () => {
                                {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        if (isInitialRender) {
                                            let componentCall = new SplashPage(this, {
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale,
                                                onFinish: () => this.handleSplashFinish()
                                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 74, col: 11 });
                                            ViewPU.create(componentCall);
                                            let paramsLambda = () => {
                                                return {
                                                    darkMode: this.darkMode,
                                                    fontScale: this.fontScale,
                                                    onFinish: () => this.handleSplashFinish()
                                                };
                                            };
                                            componentCall.paramsGenerator_ = paramsLambda;
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale
                                            });
                                        }
                                    }, { name: "SplashPage" });
                                }
                            });
                        }
                        else if (this.currentPage === 'guide') {
                            this.ifElseBranchUpdateFunction(1, () => {
                                {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        if (isInitialRender) {
                                            let componentCall = new GuidePage(this, {
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale,
                                                onFinish: () => this.handleGuideFinish()
                                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 80, col: 11 });
                                            ViewPU.create(componentCall);
                                            let paramsLambda = () => {
                                                return {
                                                    darkMode: this.darkMode,
                                                    fontScale: this.fontScale,
                                                    onFinish: () => this.handleGuideFinish()
                                                };
                                            };
                                            componentCall.paramsGenerator_ = paramsLambda;
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale
                                            });
                                        }
                                    }, { name: "GuidePage" });
                                }
                            });
                        }
                        else if (this.currentPage === 'login') {
                            this.ifElseBranchUpdateFunction(2, () => {
                                {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        if (isInitialRender) {
                                            let componentCall = new LoginPage(this, {
                                                isLoggedIn: this.__isLoggedIn,
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale,
                                                onLoginSuccess: () => this.handleLoginSuccess()
                                            }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 86, col: 11 });
                                            ViewPU.create(componentCall);
                                            let paramsLambda = () => {
                                                return {
                                                    isLoggedIn: this.isLoggedIn,
                                                    darkMode: this.darkMode,
                                                    fontScale: this.fontScale,
                                                    onLoginSuccess: () => this.handleLoginSuccess()
                                                };
                                            };
                                            componentCall.paramsGenerator_ = paramsLambda;
                                        }
                                        else {
                                            this.updateStateVarsOfChildByElmtId(elmtId, {
                                                darkMode: this.darkMode,
                                                fontScale: this.fontScale
                                            });
                                        }
                                    }, { name: "LoginPage" });
                                }
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(3, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/Index.ets(93:11)", "entry");
                                    Column.width('100%');
                                    Column.height('100%');
                                    Column.backgroundColor(this.pageBackground());
                                }, Column);
                                this.buildPageContent.bind(this)();
                                this.buildTabBar.bind(this)();
                                Column.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.subPage !== 'none') {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.buildSubPage.bind(this)();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    private async bootstrap(): Promise<void> {
        if (this.isBootstrapped) {
            return;
        }
        await PreferencesStore.init(this.context);
        FileStore.init(this.context);
        this.darkMode = await PreferencesStore.getBoolean(PrefKeys.SETTING_DARK_MODE, false);
        const savedScale = await PreferencesStore.getNumber(PrefKeys.SETTING_FONT_SCALE, 1);
        this.fontScale = savedScale > 0 ? savedScale : 1;
        const loggedIn = await PreferencesStore.getBoolean(PrefKeys.AUTH_LOGGED_IN, false);
        this.isLoggedIn = loggedIn;
        AppStorage.setOrCreate<boolean>('isLoggedIn', loggedIn);
        this.isFirstLaunch = await PreferencesStore.getBoolean(PrefKeys.FIRST_LAUNCH, true);
        // 优先从本地文件读取持久化数据，缺失则使用模拟数据
        const savedTodos = await FileStore.getTodos<TodoItem[]>([]);
        this.todoList = savedTodos.length > 0 ? savedTodos : AppData.todos.slice();
        const savedCourses = await FileStore.getCourses<CourseItem[]>([]);
        this.courseList = savedCourses.length > 0 ? savedCourses : AppData.courses.slice();
        const savedBooks = await FileStore.getBooks<BookItem[]>([]);
        this.bookList = savedBooks.length > 0 ? savedBooks : AppData.books.slice();
        const savedFoods = await FileStore.getFoods<FoodItem[]>([]);
        this.foodList = savedFoods.length > 0 ? savedFoods : AppData.foods.slice();
        this.noticeList = AppData.notices.slice();
        this.isBootstrapped = true;
    }
    private handleSplashFinish(): void {
        if (this.isFirstLaunch) {
            this.currentPage = 'guide';
        }
        else if (!this.isLoggedIn) {
            this.currentPage = 'login';
        }
        else {
            this.currentPage = 'main';
        }
    }
    private handleGuideFinish(): void {
        PreferencesStore.setBoolean(PrefKeys.FIRST_LAUNCH, false);
        this.isFirstLaunch = false;
        this.currentPage = 'login';
    }
    private handleLoginSuccess(): void {
        PreferencesStore.setBoolean(PrefKeys.AUTH_LOGGED_IN, true);
        this.isLoggedIn = true;
        AppStorage.setOrCreate<boolean>('isLoggedIn', true);
        this.currentPage = 'main';
    }
    navigateTo(subPage: SubPageType, params?: PageParams): void {
        if (params) {
            this.pageParams = params;
        }
        this.subPage = subPage;
    }
    goBack(): void {
        this.subPage = 'none';
        this.pageParams = {};
    }
    private buildPageContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentTab === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new HomePage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    todoList: this.todoList,
                                    courseList: this.courseList,
                                    noticeList: this.noticeList,
                                    onNavigate: (page: string) => this.handleHomeNavigate(page),
                                    onNoticeClick: (notice: NoticeItem) => this.navigateTo('noticeDetail', { notice })
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 187, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        todoList: this.todoList,
                                        courseList: this.courseList,
                                        noticeList: this.noticeList,
                                        onNavigate: (page: string) => this.handleHomeNavigate(page),
                                        onNoticeClick: (notice: NoticeItem) => this.navigateTo('noticeDetail', { notice })
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    todoList: this.todoList,
                                    courseList: this.courseList,
                                    noticeList: this.noticeList
                                });
                            }
                        }, { name: "HomePage" });
                    }
                });
            }
            else if (this.currentTab === 1) {
                this.ifElseBranchUpdateFunction(1, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new CampusPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    noticeList: this.noticeList,
                                    onNoticeClick: (notice: NoticeItem) => this.navigateTo('noticeDetail', { notice }),
                                    onNavigate: (page: string) => this.handleCampusNavigate(page)
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 197, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        noticeList: this.noticeList,
                                        onNoticeClick: (notice: NoticeItem) => this.navigateTo('noticeDetail', { notice }),
                                        onNavigate: (page: string) => this.handleCampusNavigate(page)
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    noticeList: this.noticeList
                                });
                            }
                        }, { name: "CampusPage" });
                    }
                });
            }
            else if (this.currentTab === 2) {
                this.ifElseBranchUpdateFunction(2, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new StudyPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    courseList: this.courseList,
                                    onNavigate: (page: string) => this.handleStudyNavigate(page)
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 205, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        courseList: this.courseList,
                                        onNavigate: (page: string) => this.handleStudyNavigate(page)
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    courseList: this.courseList
                                });
                            }
                        }, { name: "StudyPage" });
                    }
                });
            }
            else if (this.currentTab === 3) {
                this.ifElseBranchUpdateFunction(3, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new ServicePage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    onNavigate: (page: string) => this.handleServiceNavigate(page)
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 212, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onNavigate: (page: string) => this.handleServiceNavigate(page)
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "ServicePage" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(4, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new ProfilePage(this, {
                                    isLoggedIn: this.__isLoggedIn,
                                    darkMode: this.__darkMode,
                                    fontScale: this.__fontScale,
                                    todoList: this.todoList,
                                    onNavigate: (page: string) => this.handleProfileNavigate(page),
                                    onLogout: () => this.handleLogout()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 218, col: 7 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        isLoggedIn: this.isLoggedIn,
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        todoList: this.todoList,
                                        onNavigate: (page: string) => this.handleProfileNavigate(page),
                                        onLogout: () => this.handleLogout()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    todoList: this.todoList
                                });
                            }
                        }, { name: "ProfilePage" });
                    }
                });
            }
        }, If);
        If.pop();
    }
    private handleHomeNavigate(page: string): void {
        switch (page) {
            case 'todo':
                this.navigateTo('todo');
                break;
            case 'notice':
                this.currentTab = 1;
                break;
            case 'schedule':
                this.currentTab = 2;
                break;
            case 'grade':
                this.currentTab = 2;
                break;
            case 'library':
                this.navigateTo('library');
                break;
            case 'lost':
                this.navigateTo('lostFound');
                break;
            case 'map':
                this.navigateTo('map');
                break;
            case 'food':
                this.navigateTo('food');
                break;
            case 'music':
                this.navigateTo('music');
                break;
            case 'more':
                this.currentTab = 3;
                break;
        }
    }
    private handleCampusNavigate(page: string): void {
        if (page === 'map') {
            this.navigateTo('map');
        }
    }
    private handleStudyNavigate(page: string): void {
        switch (page) {
            case 'courseEdit':
                this.navigateTo('courseEdit');
                break;
            case 'library':
                this.navigateTo('library');
                break;
        }
    }
    private handleServiceNavigate(page: string): void {
        switch (page) {
            case 'lost':
                this.navigateTo('lostFound');
                break;
            case 'food':
                this.navigateTo('food');
                break;
            case 'music':
                this.navigateTo('music');
                break;
            case 'tools':
                // 校园工具暂未实现独立页，回到首页
                this.currentTab = 0;
                break;
        }
    }
    private handleProfileNavigate(page: string): void {
        switch (page) {
            case 'profileEdit':
                this.navigateTo('profileEdit');
                break;
            case 'favorites':
                this.navigateTo('favorites');
                break;
            case 'todo':
                this.navigateTo('todo');
                break;
            case 'settings':
            case 'notifySettings':
            case 'about':
            case 'help':
            case 'feedback':
                this.navigateTo('settings');
                break;
            case 'course':
            case 'grade':
                this.currentTab = 2;
                break;
            case 'lost':
                this.navigateTo('lostFound');
                break;
        }
    }
    private handleLogout(): void {
        PreferencesStore.setBoolean(PrefKeys.AUTH_LOGGED_IN, false);
        this.isLoggedIn = false;
        AppStorage.setOrCreate<boolean>('isLoggedIn', false);
        this.currentPage = 'login';
        this.currentTab = 0;
    }
    private buildSubPage(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(337:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(this.pageBackground());
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.subPage === 'noticeDetail' && this.pageParams.notice) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new NoticeDetailPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    notice: this.pageParams.notice,
                                    onBack: () => this.goBack(),
                                    onFavoriteChange: (notice: NoticeItem) => this.handleNoticeFavoriteChange(notice)
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 339, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        notice: this.pageParams.notice,
                                        onBack: () => this.goBack(),
                                        onFavoriteChange: (notice: NoticeItem) => this.handleNoticeFavoriteChange(notice)
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "NoticeDetailPage" });
                    }
                });
            }
            else if (this.subPage === 'todo') {
                this.ifElseBranchUpdateFunction(1, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new TodoPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    todoList: this.todoList,
                                    onBack: () => this.goBack(),
                                    onTodoChange: (list: TodoItem[]) => { this.handleTodoChange(list); }
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 347, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        todoList: this.todoList,
                                        onBack: () => this.goBack(),
                                        onTodoChange: (list: TodoItem[]) => { this.handleTodoChange(list); }
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    todoList: this.todoList
                                });
                            }
                        }, { name: "TodoPage" });
                    }
                });
            }
            else if (this.subPage === 'courseEdit') {
                this.ifElseBranchUpdateFunction(2, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new CourseEditPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    courseList: this.courseList,
                                    onBack: () => this.goBack(),
                                    onCoursesChange: (list: CourseItem[]) => { this.handleCoursesChange(list); }
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 355, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        courseList: this.courseList,
                                        onBack: () => this.goBack(),
                                        onCoursesChange: (list: CourseItem[]) => { this.handleCoursesChange(list); }
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    courseList: this.courseList
                                });
                            }
                        }, { name: "CourseEditPage" });
                    }
                });
            }
            else if (this.subPage === 'library') {
                this.ifElseBranchUpdateFunction(3, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new LibraryPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    bookList: this.bookList,
                                    onBack: () => this.goBack(),
                                    onBooksChange: (list: BookItem[]) => { this.handleBooksChange(list); }
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 363, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        bookList: this.bookList,
                                        onBack: () => this.goBack(),
                                        onBooksChange: (list: BookItem[]) => { this.handleBooksChange(list); }
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    bookList: this.bookList
                                });
                            }
                        }, { name: "LibraryPage" });
                    }
                });
            }
            else if (this.subPage === 'lostFound') {
                this.ifElseBranchUpdateFunction(4, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new LostFoundPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 371, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "LostFoundPage" });
                    }
                });
            }
            else if (this.subPage === 'food') {
                this.ifElseBranchUpdateFunction(5, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new FoodPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    foodList: this.foodList,
                                    onBack: () => this.goBack(),
                                    onFoodsChange: (list: FoodItem[]) => { this.handleFoodsChange(list); }
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 377, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        foodList: this.foodList,
                                        onBack: () => this.goBack(),
                                        onFoodsChange: (list: FoodItem[]) => { this.handleFoodsChange(list); }
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    foodList: this.foodList
                                });
                            }
                        }, { name: "FoodPage" });
                    }
                });
            }
            else if (this.subPage === 'music') {
                this.ifElseBranchUpdateFunction(6, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new MusicPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 385, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "MusicPage" });
                    }
                });
            }
            else if (this.subPage === 'map') {
                this.ifElseBranchUpdateFunction(7, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new MapPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 391, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "MapPage" });
                    }
                });
            }
            else if (this.subPage === 'profileEdit') {
                this.ifElseBranchUpdateFunction(8, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new ProfileEditPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 397, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale
                                });
                            }
                        }, { name: "ProfileEditPage" });
                    }
                });
            }
            else if (this.subPage === 'favorites') {
                this.ifElseBranchUpdateFunction(9, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new FavoritesPage(this, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    noticeList: this.noticeList,
                                    bookList: this.bookList,
                                    foodList: this.foodList,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 403, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        noticeList: this.noticeList,
                                        bookList: this.bookList,
                                        foodList: this.foodList,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                    darkMode: this.darkMode,
                                    fontScale: this.fontScale,
                                    noticeList: this.noticeList,
                                    bookList: this.bookList,
                                    foodList: this.foodList
                                });
                            }
                        }, { name: "FavoritesPage" });
                    }
                });
            }
            else if (this.subPage === 'settings') {
                this.ifElseBranchUpdateFunction(10, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new SettingsPage(this, {
                                    darkMode: this.__darkMode,
                                    fontScale: this.__fontScale,
                                    onBack: () => this.goBack()
                                }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 412, col: 9 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {
                                        darkMode: this.darkMode,
                                        fontScale: this.fontScale,
                                        onBack: () => this.goBack()
                                    };
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "SettingsPage" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(11, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    private handleTodoChange(list: TodoItem[]): void {
        this.todoList = list.slice();
        FileStore.saveTodos(list).catch((e: Error) => console.error(`saveTodos: ${JSON.stringify(e)}`));
    }
    private handleCoursesChange(list: CourseItem[]): void {
        this.courseList = list.slice();
        FileStore.saveCourses(list).catch((e: Error) => console.error(`saveCourses: ${JSON.stringify(e)}`));
    }
    private handleBooksChange(list: BookItem[]): void {
        this.bookList = list.slice();
        FileStore.saveBooks(list).catch((e: Error) => console.error(`saveBooks: ${JSON.stringify(e)}`));
    }
    private handleFoodsChange(list: FoodItem[]): void {
        this.foodList = list.slice();
        FileStore.saveFoods(list).catch((e: Error) => console.error(`saveFoods: ${JSON.stringify(e)}`));
    }
    private handleNoticeFavoriteChange(notice: NoticeItem): void {
        const idx = this.noticeList.findIndex(n => n.id === notice.id);
        if (idx >= 0) {
            const newList: NoticeItem[] = this.noticeList.slice();
            const item: NoticeItem = newList[idx];
            const newItem: NoticeItem = {
                id: item.id,
                title: item.title,
                summary: item.summary,
                content: item.content,
                time: item.time,
                category: item.category,
                favorite: notice.favorite
            };
            newList[idx] = newItem;
            this.noticeList = newList;
        }
    }
    private buildTabBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(465:5)", "entry");
            Row.width('100%');
            Row.backgroundColor(this.cardColor());
            Row.border({
                width: { top: 1 },
                color: AppTheme.BORDER
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 4 });
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(467:9)", "entry");
                    Column.layoutWeight(1);
                    Column.padding({ top: 8, bottom: 10 });
                    Column.onClick(() => {
                        this.currentTab = index;
                    });
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(this.tabIcons[index]);
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(468:11)", "entry");
                    Text.fontSize(20 * this.fontScale);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item);
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(470:11)", "entry");
                    Text.fontSize(11 * this.fontScale);
                    Text.fontColor(this.currentTab === index ? AppTheme.BRAND_BLUE : this.secondaryText());
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabTitles, forEachItemGenFunction, (item: string) => item, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
    }
    private pageBackground(): string {
        return this.darkMode ? AppTheme.DARK_PAGE_BG : AppTheme.PAGE_BG;
    }
    private cardColor(): string {
        return this.darkMode ? AppTheme.DARK_CARD_BG : AppTheme.CARD_BG;
    }
    private secondaryText(): string {
        return this.darkMode ? AppTheme.DARK_SECONDARY_TEXT : AppTheme.SECONDARY_TEXT;
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.campusassistant.app", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
