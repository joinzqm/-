# 高校校园助手

基于 HarmonyOS NEXT / ArkTS / ArkUI 的校园助手项目初始骨架，按照“首页、校园信息、学习助手、生活服务、我的”五大模块搭建。

## 当前已创建内容

- HarmonyOS NEXT Stage 模型工程基础文件
- `EntryAbility` 主入口
- `Index.ets` 应用壳层，负责登录态切换与底部 Tab
- 已拆分独立页面：`LoginPage`、`HomePage`、`CampusPage`、`StudyPage`、`ServicePage`、`ProfilePage`
- 主题常量、示例数据模型、公共卡片组件
- 资源文件：应用名称、启动背景色、占位图标

## 目录结构

```text
/workspace
├── AppScope
├── entry
│   └── src/main
│       ├── ets
│       │   ├── components
│       │   ├── entryability
│       │   ├── model
│       │   ├── pages
│       │   └── viewmodel
│       └── resources
├── hvigor
├── build-profile.json5
├── hvigorfile.ts
└── oh-package.json5
```

## 现阶段说明

- 当前版本重点是“把系统搭起来”，便于三人并行开发。
- 页面内容以演示骨架和模拟数据为主，已完成模块级页面拆分，后续可继续接入真实路由与子页面。
- 数据层暂时使用内存中的示例数据，后续建议接入 `Preferences + JSON 文件存储`。

## 建议下一步

1. 将登录页接入真实路由跳转与登录态持久化。
2. 接入课程表、待办、收藏、用户信息的本地持久化。
3. 增加公告详情、课程编辑、失物发布、音乐播放器等子页面。
4. 由三位成员分别接入各自主责模块并进行联调。

## 登录态持久化

- 登录成功后写入本地键值存储：`auth_logged_in`
- 启动时自动读取登录态：已登录直接进入主壳层
- “我的”页右上角“退出”：清除登录态并回到登录页
