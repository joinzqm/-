# 高校校园助手 - 项目配置规范与错误处理流程

## 一、版本规范

### 1.1 版本一致性要求

| 文件 | 字段 | 值 | 说明 |
|------|------|-----|------|
| 根目录 oh-package.json5 | modelVersion | 6.0.2 | 开发态版本号，必须与 DevEco Studio 版本对齐 |
| hvigor/hvigor-config.json5 | modelVersion | 6.0.2 | 必须与根目录 oh-package.json5 一致 |
| build-profile.json5 | compatibleSdkVersion | "6.0.2(22)" | HarmonyOS NEXT SDK 版本，字符串格式 |
| build-profile.json5 | targetSdkVersion | "6.0.2(22)" | 必须与 compatibleSdkVersion 一致 |
| build-profile.json5 | runtimeOS | "HarmonyOS" | 运行时系统 |

### 1.2 版本格式规范

- **modelVersion**: 仅使用主版本号，格式为 `X.Y.Z`（如 `6.0.2`）
- **SDK版本**: HarmonyOS 使用 `"X.Y.Z(XX)"` 字符串格式（如 `"6.0.2(22)"`）
- **版本号一致性**: 所有配置文件的版本号必须保持一致，禁止混合使用不同版本

### 1.3 禁止操作

- ❌ 禁止在未确认当前 DevEco Studio 版本的情况下修改 modelVersion
- ❌ 禁止同时在 app 和 products 中设置 SDK 版本字段（必须只在 products 中设置）
- ❌ 禁止使用 caret 范围（如 `^6.3.0`）来声明构建工具依赖版本

---

## 二、配置文件规范

### 2.1 hvigorfile.ts 规范

**根目录 hvigorfile.ts**:
```typescript
export default {
  system: 'app'
}
```

**模块级 hvigorfile.ts**（entry 模块）:
```typescript
export default {
  system: 'hap'
}
```

**规则**:
- ✅ 只声明 `system` 字段，不声明 `plugins` 数组
- ✅ `@ohos/hvigor-ohos-plugin` 是系统内置插件，由 hvigor 自动加载
- ❌ 禁止手动 import 和声明插件函数

### 2.2 oh-package.json5 规范

**根目录**:
```json5
{
  "modelVersion": "6.0.2",
  "name": "campus-assistant",
  "version": "1.0.0",
  "description": "HarmonyOS NEXT campus assistant",
  "main": "",
  "author": "campus-team",
  "license": "Apache-2.0",
  "devDependencies": {}
}
```

**模块级**:
```json5
{
  "name": "entry",
  "version": "1.0.0",
  "description": "Entry module",
  "main": "",
  "author": "campus-team",
  "license": "Apache-2.0",
  "dependencies": {}
}
```

**规则**:
- ✅ 根目录必须包含 `modelVersion`
- ✅ 模块级不需要 `modelVersion`
- ❌ 禁止在 devDependencies 中声明 `@ohos/hvigor` 和 `@ohos/hvigor-ohos-plugin`
- ❌ 禁止使用 `file:` 协议引用本地路径

### 2.3 hvigor-config.json5 规范

```json5
{
  "modelVersion": "6.0.2",
  "dependencies": {},
  "execution": {
    "analyze": "normal",
    "daemon": true,
    "incremental": true,
    "parallel": true
  },
  "logging": {
    "level": "info"
  }
}
```

**规则**:
- ✅ `dependencies` 使用空对象 `{}`，不声明构建工具依赖
- ✅ `analyze` 使用 `"normal"`（`"default"` 已废弃）
- ❌ 禁止将 `dependencies` 声明为数组

---

## 三、错误处理流程

### 3.1 通用错误处理步骤

```
1. 读取错误日志，提取关键信息
   → 错误类型（Script Error / Configuration Error / Schema Validate Error）
   → 指向文件（文件路径 + 行号）
   → 具体错误信息

2. 定位问题文件，读取当前内容
   → 使用 Read 工具读取完整文件内容
   → 确认错误位置的上下文

3. 对照版本规范和 schema 要求
   → 检查字段名是否在 allowedValues 中
   → 检查字段类型是否正确（object/array/string/number）
   → 检查字段位置是否正确（根节点/app/modules/products）

4. 执行最小差异修复
   → 只修改被报错点名的字段
   → 不在同一轮中同时修改多个字段
   → 保持其他字段不变

5. 验证修复结果
   → 执行构建命令验证
   → 检查是否有新的错误或警告
   → 确认退出码为 0

6. 记录修复过程
   → 在 PROJECT_RULES.md 中更新规范
   → 添加新的检查项到检查清单
```

### 3.2 常见错误处理指南

| 错误类型 | 错误信息 | 处理方法 |
|----------|----------|----------|
| Schema Validate Error | "类型不兼容" | 检查字段类型（object/array/string），对照 schema 要求修改 |
| Schema Validate Error | "不在 allowedValues 中" | 只使用日志中给出的允许值 |
| Script Error | "Cannot read properties of undefined" | 检查 hvigorfile.ts 中插件调用是否正确，确保不手动声明系统插件 |
| Script Error | "Invalid exports, no system plugins were found" | 简化 hvigorfile.ts，只保留 system 字段 |
| Configuration Error | "Missing file oh-package.json5" | 在缺失目录创建 oh-package.json5 |
| Configuration Error | "Hvigorfile not found" | 在模块根目录创建 hvigorfile.ts |
| Fetch Source Code Failed | "E:\DevEco Studio\tools\hvigor\...\oh-package.json5 does not exist" | 从 oh-package.json5 中移除 file: 协议的本地依赖引用 |

### 3.3 配置文件编辑规范

```
所有配置文件编辑必须遵循：

1. 先 Read 后 Edit
   → 必须先读取文件完整内容
   → 确认要修改的精确片段（包括上下文缩进和逗号）
   → 确保 old_string 在文件中唯一

2. 最小差异修改
   → 只修改必要的字段
   → 保持文件其他部分不变
   → 使用 Edit 工具的精确替换功能

3. 版本一致性检查
   → 修改版本相关字段时，同步更新所有相关文件
   → 修改后验证所有配置文件的版本一致性

4. 验证后再提交
   → 修改完成后执行构建命令验证
   → 确认没有新的错误或警告
   → 记录修改内容和验证结果
```

---

## 四、检查清单

### 4.1 构建前检查

| 检查项 | 检查内容 | 状态 |
|--------|----------|------|
| 根目录配置 | oh-package.json5 存在且包含 modelVersion | ✅ |
| 根目录配置 | hvigorfile.ts 只声明 system: 'app' | ✅ |
| 根目录配置 | hvigor-config.json5 analyze 使用 'normal' | ✅ |
| 根目录配置 | build-profile.json5 SDK 版本正确 | ✅ |
| entry 模块 | oh-package.json5 存在 | ✅ |
| entry 模块 | hvigorfile.ts 只声明 system: 'hap' | ✅ |
| entry 模块 | module.json5 格式正确 | ✅ |
| AppScope | app.json5 存在 | ✅ |
| 资源文件 | string.json、color.json、main_pages.json 完整 | ✅ |
| 依赖配置 | 无 file: 协议的本地依赖引用 | ✅ |

### 4.2 构建命令验证

```powershell
# 1. 依赖安装
ohpm install --all --registry https://ohpm.openharmony.cn/ohpm/ --strict_ssl true

# 2. 项目同步
& "E:\DevEco Studio\tools\node\node.exe" "E:\DevEco Studio\tools\hvigor\bin\hvigorw.js" --sync -p product=default --analyze=normal --parallel --incremental --no-daemon

# 3. 构建 HAP
& "E:\DevEco Studio\tools\node\node.exe" "E:\DevEco Studio\tools\hvigor\bin\hvigorw.js" --mode project -p product=default assembleHap --no-daemon
```

---

## 五、环境要求

| 环境项 | 版本 | 说明 |
|--------|------|------|
| DevEco Studio | 6.0.2 Release | 开发 IDE |
| HarmonyOS SDK | 6.0.2(22) | API Version 22 |
| Node.js | v18.x | DevEco Studio 内置 |
| ohpm | 随 DevEco Studio 安装 | 包管理工具 |
| Hvigor | 随 DevEco Studio 安装 | 构建工具 |

---

## 六、历史修复记录

| 日期 | 问题描述 | 修复内容 | 验证结果 |
|------|----------|----------|----------|
| 2026-07-04 | ohpm install 报 Missing file "oh-package.json5" | 在 entry 目录创建 oh-package.json5 | ✅ |
| 2026-07-04 | ohpm 报 Fetch Source Code Failed（file: 协议引用） | 从根目录 oh-package.json5 移除本地依赖引用 | ✅ |
| 2026-07-04 | hvigor-config.json5 dependencies 类型不兼容（array vs object） | 将 dependencies 从数组改为空对象 {} | ✅ |
| 2026-07-04 | hvigorfile.ts 报 Cannot read properties of undefined (reading 'getName') | 简化 hvigorfile.ts，只保留 system 字段 | ✅ |
| 2026-07-04 | hvigor-config.json5 analyze: "default" 已废弃 | 改为 "normal" | ✅ |
| 2026-07-04 | DevEco Studio 同步失败（activeProduct is null） | 在 build-profile.json5 中添加 project 字段 | ✅ |
| 2026-07-04 | DevEco Studio 提示 Configure targetSdkVersion | 在 build-profile.json5 的 project 级别添加 targetSdkVersion | ✅ |
